# Krokiet Folder Compare v15 – macOS ARM64 (Test-Build)

Basis: Krokiet/Czkawka 12.0.2, Erweiterung von v14. **Dies ist Quellcode, keine kompilierte App.**

## Wesentliche Änderungen

- Symmetrisch identische Zwillingsordner werden in der Trefferliste zu einem repräsentativen Treffer zusammengefasst. Bei mehr als zwei identischen Ordnern wird weiterhin die Gruppengröße angezeigt.
- Bei einem konkreten A/B-Paar steht die **Dateiabdeckung in beide Richtungen**: „A in B“ und „B in A“ mit Dateizahlen. Diese Zahl ist nicht die globale Abdeckung über verstreute Archive.
- In der Vergleichstabelle gibt es eine zusätzliche Aktion **Konflikte prüfen**. Sie vergleicht alle bislang unklaren Pfadpaare A/B frisch byteweise. Danach steht „Identisch“ oder „Verschieden“; „Ungeprüft“ ist bewusst keine Behauptung unterschiedlicher Inhalte.
- „A/B tauschen“ wechselt über die vorhandenen Indexdaten die Richtung des Paares. Die Aktion „Kopieren nach B“ kann so für beide Richtungen verwendet werden. Sind eigene, nicht indexierte Pfade ausgewählt, ist gegebenenfalls „Neu prüfen“ nötig.
- **Keine starre Grenze von 200 Dateien** bei ausdrücklichen Mehrfachaktionen. Dateien werden vor dem Papierkorb einzeln geprüft, danach mit einem **einzigen `trash::delete_all`** an das Betriebssystem übergeben. Die Aktion selbst ist nach dem Start nicht abbrechbar; ein Fehler kann eine teilweise Ausführung bedeuten. Die Ergebnisse werden anhand der verbleibenden Originalpfade abgeglichen.
- Das Kopieren verwendet weiterhin `create_new(true)` und überschreibt keine Dateien. Kopien werden byteweise überprüft.

## Bedienung

1. Regulären Duplikatscan mit Hash-Prüfung starten und **Ordner vergleichen** öffnen.
2. Links ein Ordnerpaar auswählen. Rechts erscheint die **unverifizierte Index-Vorschau**, ohne erneuten gesamten Datenträger-Scan.
3. Für problematische Fälle **Konflikte prüfen** wählen, um gleichnamige Dateien aktuell byteweise nachzuprüfen. Über **Neu prüfen** ist weiterhin ein vollständiger Audit möglich.
4. „A/B tauschen“ entscheidet, welcher Ordner das Kopierziel B ist; „Nur A“ zeigt kopierbare Dateien. Die Bestätigung für Kopieren ist separat.
5. Für identische Dateipaare ist „Optional: Byteprüfung“ nur eine zusätzliche Vorabprüfung. Vor einer ausdrücklich bestätigten Papierkorbaktion wird der Inhalt **immer** aktuell nachgeprüft.
6. Bei Dateien in externen Projekten, Ressourcen-Forks und Dateien mit AppleDouble-`._`-Metadaten manuell kontrollieren. Die Anwendung kennt keine externen Projektverweise.

## Datenschutz und Sicherheitsgrenzen

- Kein automatisches Entfernen ganzer Ordner, keine permanente Löschung.
- Dateifilter können Inhalte verdecken. Für Archiventscheidungen Filter deaktivieren und den gesamten A/B-Bestand ansehen.
- Die Papierkorb-API macht auf macOS nach Möglichkeit einen einzigen Systemaufruf. **Ob macOS tatsächlich nur eine Freigabe abfragt, kann nicht garantiert werden**: Zugriffsrechte, TCC und externe Volumes können weitere Dialoge auslösen. Niemals Rechte pauschal auf allen Dateien ändern, um Dialoge zu umgehen.
- Auch ein erfolgreiches `cargo test` ist keine Zertifizierung gegen alle Datenverlustfälle. Erst auf Testordnern und mit wiederherstellbaren Kopien prüfen.

## GitHub-Build

ZIP ins Repo-Hauptverzeichnis hochladen: `krokiet_folder_compare_patch_12.0.2_v15.zip`.
Workflow: `.github/workflows/build-krokiet-v15.yml` mit der beigefügten YAML erstellen.

Der Workflow klont Krokiet 12.0.2, wendet `apply_patch.py` an (einschließlich einer **direkten, auf die vorhandene Cargo.lock-Version festgelegten `trash`-Abhängigkeit**), führt die Tests mit `--locked` aus und erstellt das ad-hoc signierte ARM64-App-Bundle.

**Vor dem Build:** Der Patch wurde hier statisch geprüft und mit Python-Tests getestet. Rust-/Slint- und macOS-Dateisystem-Tests müssen in GitHub Actions bzw. auf dem Mac erfolgen.
