//! Read-only, content-based comparison of two complete folder trees.
//!
//! This reuses Czkawka's duplicate hashing pipeline. Krokiet normally exposes
//! only duplicate groups; we also walk both roots to inventory the unique files.
//! The verdict is conservative: warnings, unreadable/special files, cancellation,
//! or changing files never lead to a successful containment verdict.
//!
//! Scope (by design): only file CONTENT is compared. Metadata (dates, ACLs,
//! extended attributes, resource forks), hardlink topology and references inside
//! project files are NOT checked. Symlinks are never followed; they are checked
//! for (a) links in B that point into A (deleting A would break them) and
//! (b) links in A that have no equivalent in B. The report states all of this.

use std::collections::{BTreeMap, BTreeSet};
use std::fs;
use std::path::{Component, Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::SystemTime;

use crossbeam_channel::Sender;
use czkawka_core::common::model::{CheckingMethod, HashType};
use czkawka_core::common::progress_data::ProgressData;
use czkawka_core::common::tool_data::CommonData;
use czkawka_core::common::traits::Search;
use czkawka_core::tools::duplicate::{DuplicateEntry, DuplicateFinder, DuplicateFinderParameters};
use rfd::FileDialog;
use slint::ComponentHandle;

use crate::MainWindow;
use crate::connect_rfd::{hide_file_dialog_overlay, show_file_dialog_overlay};

#[path = "folder_audit_actions.rs"]
mod audit_actions;

/// Maximum number of lines per list shown inside the popup. The saved report is always complete.
const UI_LIST_LIMIT: usize = 1500;

/// Known system junk. Files matching ONLY these patterns may be ignored without weakening the verdict.
const DEFAULT_IGNORE_PATTERNS: &str = ".DS_Store, ._*, Thumbs.db, desktop.ini, .localized";

// ---- PURE-BEGIN (no Czkawka, no Slint: extracted and tested separately) ----

#[derive(Debug, Clone, PartialEq, Eq)]
struct Stamp {
    bytes: u64,
    modified: Option<SystemTime>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct LinkInfo {
    // Link target exactly as stored (never followed during the audit).
    target: PathBuf,
    // Fully resolved location at scan time (None for dangling links).
    canonical: Option<PathBuf>,
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
struct Inventory {
    files: BTreeMap<PathBuf, Stamp>,
    dirs: BTreeSet<PathBuf>,
    symlinks: BTreeMap<PathBuf, LinkInfo>,
    // Sockets, devices, FIFOs etc.: cannot be compared, therefore block the verdict if in A.
    special: BTreeSet<PathBuf>,
    // REGULAR FILES skipped because their NAME matched an ignore pattern (path -> size).
    // Directories are never ignored: their contents are always compared.
    ignored: BTreeMap<PathBuf, u64>,
}

/// Case-insensitive glob match with `*` as the only wildcard (macOS volumes are usually case-insensitive).
fn glob_match(pattern: &str, name: &str) -> bool {
    let p: Vec<char> = pattern.to_lowercase().chars().collect();
    let n: Vec<char> = name.to_lowercase().chars().collect();
    let (mut pi, mut ni) = (0usize, 0usize);
    let mut star: Option<usize> = None;
    let mut mark = 0usize;
    while ni < n.len() {
        let pc = p.get(pi).copied();
        if pc == Some('*') {
            star = Some(pi);
            mark = ni;
            pi += 1;
        } else if pc.is_some() && pc == n.get(ni).copied() {
            pi += 1;
            ni += 1;
        } else if let Some(s) = star {
            pi = s + 1;
            mark += 1;
            ni = mark;
        } else {
            return false;
        }
    }
    while p.get(pi).copied() == Some('*') {
        pi += 1;
    }
    pi == p.len()
}

fn is_ignored(name: &str, patterns: &[String]) -> bool {
    patterns.iter().any(|p| glob_match(p, name))
}

/// Parses a comma/newline separated list of NAME patterns. Rejects patterns that could hide everything.
fn parse_patterns(raw: &str) -> Result<Vec<String>, String> {
    let mut result = Vec::new();
    for item in raw.split([',', '\n']).map(str::trim).filter(|s| !s.is_empty()) {
        if item.contains('/') || item.contains('\\') {
            return Err(format!("Ignore pattern '{item}' must be a file NAME, not a path."));
        }
        if item.chars().all(|c| c == '*') {
            return Err(format!("Ignore pattern '{item}' would ignore everything."));
        }
        result.push(item.to_owned());
    }
    Ok(result)
}

fn default_patterns() -> Vec<String> {
    parse_patterns(DEFAULT_IGNORE_PATTERNS).unwrap_or_default()
}

fn inventory(root: &Path, ignore: &[String], cancelled: &AtomicBool) -> Result<Inventory, String> {
    let mut result = Inventory::default();
    let mut dirs = vec![root.to_path_buf()];
    while let Some(dir) = dirs.pop() {
        if cancelled.load(Ordering::Relaxed) {
            return Err("Scan cancelled: no containment verdict.".to_owned());
        }
        let entries = fs::read_dir(&dir).map_err(|e| format!("Cannot list {}: {e}", dir.display()))?;
        for entry in entries {
            if cancelled.load(Ordering::Relaxed) {
                return Err("Scan cancelled: no containment verdict.".to_owned());
            }
            let entry = entry.map_err(|e| format!("Cannot read entry in {}: {e}", dir.display()))?;
            let path = entry.path();
            let metadata = fs::symlink_metadata(&path).map_err(|e| format!("Cannot stat {}: {e}", path.display()))?;
            let kind = metadata.file_type();
            if kind.is_dir() {
                result.dirs.insert(path.clone());
                dirs.push(path);
            } else if kind.is_file() {
                // Only regular FILES can be ignored, by name. Never directories, never links.
                if is_ignored(&entry.file_name().to_string_lossy(), ignore) {
                    result.ignored.insert(path, metadata.len());
                    continue;
                }
                if path.to_str().is_none() {
                    return Err(format!("Path is not valid UTF-8 (unsupported by Czkawka scanner): {}", path.display()));
                }
                result.files.insert(path, Stamp { bytes: metadata.len(), modified: metadata.modified().ok() });
            } else if kind.is_symlink() {
                let target = fs::read_link(&path).map_err(|e| format!("Cannot read link {}: {e}", path.display()))?;
                let canonical = fs::canonicalize(&path).ok();
                result.symlinks.insert(path, LinkInfo { target, canonical });
            } else {
                result.special.insert(path);
            }
        }
    }
    Ok(result)
}

/// Lexical normalisation (no filesystem access): removes `.` and resolves `..`.
fn normalize(path: &Path) -> PathBuf {
    let mut out = PathBuf::new();
    for component in path.components() {
        match component {
            Component::CurDir => {}
            Component::ParentDir => {
                out.pop();
            }
            other => out.push(other.as_os_str()),
        }
    }
    out
}

/// Where a link points to, derived from its stored target and its own location.
fn resolve_target(link: &Path, target: &Path) -> PathBuf {
    if target.is_absolute() {
        normalize(target)
    } else {
        normalize(&link.parent().unwrap_or_else(|| Path::new("/")).join(target))
    }
}

/// Case-insensitive component-wise "starts with" (deliberately over-cautious on case-sensitive volumes).
fn starts_with_ci(path: &Path, root: &Path) -> bool {
    let lower = |p: &Path| p.components().map(|c| c.as_os_str().to_string_lossy().to_lowercase()).collect::<Vec<_>>();
    let (p, r) = (lower(path), lower(root));
    p.len() >= r.len() && r.iter().zip(p.iter()).all(|(x, y)| x == y)
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
enum LinkKey {
    /// Target lies inside the link's own tree: position relative to that tree's root.
    Inside(PathBuf),
    /// Target lies somewhere else: absolute location.
    Outside(PathBuf),
}

fn link_key(link: &Path, info: &LinkInfo, root: &Path) -> LinkKey {
    let resolved = resolve_target(link, &info.target);
    match resolved.strip_prefix(root) {
        Ok(rel) => LinkKey::Inside(rel.to_path_buf()),
        Err(_) => LinkKey::Outside(resolved),
    }
}

fn exists_in(inv: &Inventory, root: &Path, rel: &Path) -> bool {
    if rel.as_os_str().is_empty() {
        return true;
    }
    let p = root.join(rel);
    inv.files.contains_key(&p) || inv.dirs.contains(&p) || inv.symlinks.contains_key(&p) || inv.ignored.contains_key(&p) || inv.special.contains(&p)
}

/// Symlinks of A that have no equivalent in B. Equivalent means the links RESOLVE to the same place:
/// both inside their own tree at the same relative position (and that position exists in B), or both to the
/// same outside location. Different relative depths (`../x`) that resolve differently are therefore not equal.
fn missing_links(a: &Path, b: &Path, ia: &Inventory, ib: &Inventory) -> Vec<(PathBuf, PathBuf)> {
    let mut available: BTreeMap<LinkKey, usize> = BTreeMap::new();
    for (link, info) in &ib.symlinks {
        *available.entry(link_key(link, info, b)).or_insert(0) += 1;
    }
    let mut missing = Vec::new();
    for (link, info) in &ia.symlinks {
        let key = link_key(link, info, a);
        let usable = available.get(&key).is_some_and(|n| *n > 0)
            && match &key {
                LinkKey::Inside(rel) => exists_in(ib, b, rel),
                LinkKey::Outside(_) => true,
            };
        if usable {
            if let Some(n) = available.get_mut(&key) {
                *n -= 1;
            }
        } else {
            missing.push((link.clone(), info.target.clone()));
        }
    }
    missing
}

/// Symlinks in B whose target lies inside A (stored target OR fully resolved location). They would break if A is deleted.
fn links_into_a(a: &Path, ib: &Inventory) -> Vec<(PathBuf, PathBuf)> {
    ib.symlinks
        .iter()
        .filter(|(link, info)| starts_with_ci(&resolve_target(link, &info.target), a) || info.canonical.as_deref().is_some_and(|c| starts_with_ci(c, a)))
        .map(|(link, info)| (link.clone(), info.target.clone()))
        .collect()
}

#[derive(Debug, Clone)]
struct Audit {
    files_a: usize,
    files_b: usize,
    // Each file in A consumes at most one matching file in B.
    pairs: BTreeMap<PathBuf, PathBuf>,
    missing_a: Vec<PathBuf>,
    extra_b: Vec<PathBuf>,
    links_a: usize,
    links_b: usize,
    // Symlinks of A without an equivalent link in B: (link, stored target).
    missing_links_a: Vec<(PathBuf, PathBuf)>,
    // Symlinks of B pointing into A: (link, stored target).
    links_b_into_a: Vec<(PathBuf, PathBuf)>,
    special_a: BTreeSet<PathBuf>,
    special_b: usize,
    ignored_a: BTreeMap<PathBuf, u64>,
    ignored_b: BTreeMap<PathBuf, u64>,
    // Ignored files of A that are NOT default system junk (matched only because the user added patterns).
    custom_ignored_a: usize,
    patterns: Vec<String>,
}

fn pair_group(a: Vec<PathBuf>, b: Vec<PathBuf>, pairs: &mut BTreeMap<PathBuf, PathBuf>) {
    // Same-hash files are already proven content-identical by the core. Keep a
    // strict one-to-one mapping, so two A copies need two B copies.
    for (source, destination) in a.into_iter().zip(b) {
        pairs.insert(source, destination);
    }
}

fn choose_from_group(
    entries: &[DuplicateEntry],
    a: &Path,
    b: &Path,
    files_a: &BTreeMap<PathBuf, Stamp>,
    files_b: &BTreeMap<PathBuf, Stamp>,
    pairs: &mut BTreeMap<PathBuf, PathBuf>,
) {
    // Only paths that are part of the audited inventory count. This keeps ignored
    // files (e.g. .DS_Store) from ever being used as a match.
    let mut group_a: Vec<PathBuf> = entries.iter().filter(|f| f.path.starts_with(a) && files_a.contains_key(&f.path)).map(|f| f.path.clone()).collect();
    let mut group_b: Vec<PathBuf> = entries.iter().filter(|f| f.path.starts_with(b) && files_b.contains_key(&f.path)).map(|f| f.path.clone()).collect();
    group_a.sort();
    group_b.sort();
    pair_group(group_a, group_b, pairs);
}

fn audit_from_groups<'a>(
    a: &Path,
    b: &Path,
    ia: &Inventory,
    ib: &Inventory,
    patterns: &[String],
    groups: impl IntoIterator<Item = &'a [DuplicateEntry]>,
) -> Audit {
    let mut pairs = BTreeMap::new();
    for group in groups {
        choose_from_group(group, a, b, &ia.files, &ib.files, &mut pairs);
    }

    // Czkawka excludes zero-byte files from its duplicate hashing scan.
    // Their contents are trivially identical, so compare their quantities.
    let empty_a = ia.files.iter().filter(|(_, s)| s.bytes == 0).map(|(p, _)| p.clone()).collect();
    let empty_b = ib.files.iter().filter(|(_, s)| s.bytes == 0).map(|(p, _)| p.clone()).collect();
    pair_group(empty_a, empty_b, &mut pairs);

    let used_b: BTreeSet<&PathBuf> = pairs.values().collect();
    let missing_a = ia.files.keys().filter(|p| !pairs.contains_key(*p)).cloned().collect();
    let extra_b = ib.files.keys().filter(|p| !used_b.contains(p)).cloned().collect();
    // v6 strict rule: ANY ignored file in A weakens a positive verdict, including .DS_Store and AppleDouble.
    let custom_ignored_a = ia.ignored.len();
    Audit {
        files_a: ia.files.len(),
        files_b: ib.files.len(),
        missing_a,
        extra_b,
        links_a: ia.symlinks.len(),
        links_b: ib.symlinks.len(),
        missing_links_a: missing_links(a, b, ia, ib),
        links_b_into_a: links_into_a(a, ib),
        special_a: ia.special.clone(),
        special_b: ib.special.len(),
        ignored_a: ia.ignored.clone(),
        ignored_b: ib.ignored.clone(),
        custom_ignored_a,
        patterns: patterns.to_vec(),
        pairs,
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Verdict {
    /// Every regular file of A is represented in B. Symlinks in A always prevent a positive verdict.
    Confirmed,
    /// As Confirmed, but files of A were skipped by user-added ignore patterns and therefore NOT compared.
    ConfirmedExceptIgnored,
    /// No missing files, but something in A could not be compared (symlink without equivalent, special file).
    Inconclusive,
    /// Symlinks in B point into A: they would break when A is deleted.
    DependencyOnA,
    /// At least one regular file of A has no identical-content counterpart in B.
    NotComplete,
}

fn verdict(audit: &Audit) -> Verdict {
    if !audit.missing_a.is_empty() {
        Verdict::NotComplete
    } else if !audit.links_b_into_a.is_empty() {
        Verdict::DependencyOnA
    } else if audit.links_a > 0 || !audit.missing_links_a.is_empty() || !audit.special_a.is_empty() {
        Verdict::Inconclusive
    } else if audit.custom_ignored_a > 0 {
        Verdict::ConfirmedExceptIgnored
    } else {
        Verdict::Confirmed
    }
}

fn rel(path: &Path, root: &Path) -> String {
    path.strip_prefix(root).unwrap_or(path).display().to_string()
}

fn push_list(lines: &mut Vec<String>, items: Vec<String>, limit: Option<usize>) {
    let total = items.len();
    let shown = limit.map_or(total, |l| l.min(total));
    for item in items.into_iter().take(shown) {
        lines.push(format!("  {item}"));
    }
    if shown < total {
        lines.push(format!("  ... {} more entries: use \"Save report\" for the complete list", total - shown));
    }
}

fn render_report(audit: &Audit, a: &Path, b: &Path, limit: Option<usize>) -> String {
    let ignored_bytes_a: u64 = audit.ignored_a.values().sum();
    let mut lines = vec![
        "CONTENT-BASED FOLDER AUDIT (scan only; manual file actions are separate)".to_owned(),
        format!("A (source / older folder): {}", a.display()),
        format!("B (folder to keep):      {}", b.display()),
        String::new(),
        format!("A: {} regular files, {} symlinks", audit.files_a, audit.links_a),
        format!("B: {} regular files, {} symlinks", audit.files_b, audit.links_b),
        format!("Matched one-to-one by content, despite names/paths: {}", audit.pairs.len()),
        format!("A files not represented in B: {}", audit.missing_a.len()),
        format!("Additional files in B (not needed for A): {}", audit.extra_b.len()),
        format!(
            "Ignored files by name (A / B): {} / {}   ({} bytes in A, {} of them from user-added patterns)   patterns: {}",
            audit.ignored_a.len(),
            audit.ignored_b.len(),
            ignored_bytes_a,
            audit.custom_ignored_a,
            audit.patterns.join(", ")
        ),
        String::new(),
    ];
    match verdict(audit) {
        Verdict::Confirmed => {
            lines.push("RESULT: CONTENT CONTAINMENT CONFIRMED".to_owned());
            lines.push("Every regular file of A has its own identical-content copy in B (multiplicities included); no symlinks in A were accepted as proven equivalent.".to_owned());
        }
        Verdict::ConfirmedExceptIgnored => {
            lines.push("RESULT: CONFIRMED EXCEPT IGNORED FILES - not a full confirmation".to_owned());
            lines.push(format!("All compared files are in B, but {} files of A matched ignore patterns you added and were NOT compared. Review the list \"IGNORED IN A\" before deleting A.", audit.custom_ignored_a));
        }
        Verdict::Inconclusive => lines.push("RESULT: INCONCLUSIVE - all regular files are in B, but entries listed below could not be compared. Review them before deleting A.".to_owned()),
        Verdict::DependencyOnA => lines.push("RESULT: DO NOT DELETE A - symlinks in B point into A and would break.".to_owned()),
        Verdict::NotComplete => lines.push("RESULT: NOT COMPLETE - do not delete A. Files below exist only in A.".to_owned()),
    }
    lines.push("Scope: file CONTENT only (BLAKE3). NOT checked: metadata (dates, ACLs, extended attributes, resource forks), hardlink topology, references inside project files, Finder aliases, links or aliases elsewhere on the disk that point into A.".to_owned());
    lines.push("Valid only for the state at scan time. Repeat the audit if anything may have changed.".to_owned());
    if audit.special_b > 0 {
        lines.push(format!("Note: B contains {} special entries (sockets, devices, FIFOs); they do not affect the verdict.", audit.special_b));
    }

    if !audit.missing_a.is_empty() {
        lines.push(String::new());
        lines.push("FILES FROM A NOT FOUND IN B:".to_owned());
        push_list(&mut lines, audit.missing_a.iter().map(|p| rel(p, a)).collect(), limit);
    }
    if !audit.links_b_into_a.is_empty() {
        lines.push(String::new());
        lines.push("SYMLINKS IN B POINTING INTO A (link => stored target):".to_owned());
        push_list(&mut lines, audit.links_b_into_a.iter().map(|(l, t)| format!("{} => {}", rel(l, b), t.display())).collect(), limit);
    }
    if !audit.missing_links_a.is_empty() {
        lines.push(String::new());
        lines.push("SYMLINKS IN A WITHOUT AN EQUIVALENT LINK IN B (link => stored target):".to_owned());
        push_list(&mut lines, audit.missing_links_a.iter().map(|(l, t)| format!("{} => {}", rel(l, a), t.display())).collect(), limit);
    }
    if !audit.special_a.is_empty() {
        lines.push(String::new());
        lines.push("SPECIAL ENTRIES IN A (sockets, devices, FIFOs; cannot be compared):".to_owned());
        push_list(&mut lines, audit.special_a.iter().map(|p| rel(p, a)).collect(), limit);
    }
    if !audit.ignored_a.is_empty() {
        lines.push(String::new());
        lines.push("IGNORED IN A (file name matched an ignore pattern, not compared):".to_owned());
        push_list(&mut lines, audit.ignored_a.iter().map(|(p, size)| format!("{} ({} bytes)", rel(p, a), size)).collect(), limit);
    }
    if !audit.pairs.is_empty() {
        lines.push(String::new());
        lines.push("MATCHED FILES A => B (paths may differ):".to_owned());
        push_list(&mut lines, audit.pairs.iter().map(|(s, d)| format!("{} => {}", rel(s, a), rel(d, b))).collect(), limit);
    }
    lines.join("\n")
}

// ---- PURE-END ----

fn send_status(status: &Sender<String>, text: &str) {
    let _ = status.send(text.to_owned());
}

fn analyze(a_input: &Path, b_input: &Path, ignore: &[String], cancelled: &Arc<AtomicBool>, status: &Sender<String>) -> Result<(Audit, PathBuf, PathBuf), String> {
    analyze_full(a_input, b_input, ignore, cancelled, status).map(|(audit, a, b, _, _)| (audit, a, b))
}

/// Wie `analyze`, liefert zusätzlich die Inventare von A und B zum Zeitpunkt der Prüfung (für die spätere Änderungskontrolle).
fn analyze_full(a_input: &Path, b_input: &Path, ignore: &[String], cancelled: &Arc<AtomicBool>, status: &Sender<String>) -> Result<(Audit, PathBuf, PathBuf, Inventory, Inventory), String> {
    let a = fs::canonicalize(a_input).map_err(|e| format!("Cannot access A: {e}"))?;
    let b = fs::canonicalize(b_input).map_err(|e| format!("Cannot access B: {e}"))?;
    if !a.is_dir() || !b.is_dir() {
        return Err("A and B must both be directories.".to_owned());
    }
    // Containment within itself is a misleading success and can confuse the
    // duplicate scanner's deduplication of overlapping scan roots.
    if a.starts_with(&b) || b.starts_with(&a) {
        return Err("A and B must be separate, non-nested directories.".to_owned());
    }

    send_status(status, "Step 1 of 3: reading both folder trees ...");
    let before_a = inventory(&a, ignore, cancelled)?;
    let before_b = inventory(&b, ignore, cancelled)?;

    send_status(status, "Step 2 of 3: comparing file contents (hashing) ...");
    let params = DuplicateFinderParameters::new(CheckingMethod::Hash, HashType::Blake3, false, 0, 0, false);
    let mut scanner = DuplicateFinder::new(params);
    scanner.set_included_paths(vec![a.clone(), b.clone()]);
    scanner.set_recursive_search(true);
    scanner.set_minimal_file_size(1); // Krokiet core normalizes 0 -> 1; handle empty files in audit_from_groups.
    scanner.set_maximal_file_size(u64::MAX);
    scanner.set_use_cache(false); // For this audit, never rely on an old hash cache.
    scanner.set_hide_hard_links(false);
    scanner.set_dry_run(true);

    // Progress: the core sends ProgressData while hashing. The receiver thread ends by itself
    // once every sender is dropped, so it is deliberately not joined (cannot block this audit).
    let (progress_tx, progress_rx) = crossbeam_channel::unbounded::<ProgressData>();
    let status_for_progress = status.clone();
    thread::spawn(move || {
        while let Ok(data) = progress_rx.recv() {
            let display = data.to_display();
            let percent = display.current_progress.filter(|p| *p >= 0).map(|p| format!(" ({p}%)")).unwrap_or_default();
            let _ = status_for_progress.send(format!("Step 2 of 3: comparing file contents (hashing) ...\n{}{}", display.label, percent));
        }
    });
    scanner.search(cancelled, Some(&progress_tx));
    drop(progress_tx);

    if scanner.get_stopped_search() || cancelled.load(Ordering::Relaxed) {
        return Err("Scan cancelled or incomplete: no containment verdict.".to_owned());
    }
    let messages = scanner.get_text_messages();
    if let Some(err) = &messages.critical {
        return Err(format!("Scanner failed: {err}"));
    }
    if !messages.errors.is_empty() || !messages.warnings.is_empty() {
        let details = messages.errors.iter().chain(messages.warnings.iter()).take(10).cloned().collect::<Vec<_>>().join("\n");
        return Err(format!("Scanner reported warnings/errors; result is inconclusive:\n{details}"));
    }

    // Another traversal detects changes during hashing, unreadable directories,
    // file deletion/creation, and newly appearing special files or symlinks.
    send_status(status, "Step 3 of 3: verifying that nothing changed during the scan ...");
    let after_a = inventory(&a, ignore, cancelled)?;
    let after_b = inventory(&b, ignore, cancelled)?;
    if before_a != after_a || before_b != after_b {
        return Err("Files changed while scanning. Repeat the audit after writes have stopped.".to_owned());
    }

    let groups = scanner.get_files_sorted_by_hash().values().flatten().map(Vec::as_slice);
    let audit = audit_from_groups(&a, &b, &before_a, &before_b, ignore, groups);
    Ok((audit, a, b, before_a, before_b))
}

fn choose_folder(app: &MainWindow, left: bool) {
    // Same pattern as the rest of Krokiet: native dialog in its own thread, with the overlay shown.
    show_file_dialog_overlay(app);
    let weak = app.as_weak();
    thread::spawn(move || {
        let folder = FileDialog::new().pick_folder();
        hide_file_dialog_overlay(&weak);
        if let Some(path) = folder {
            let text = path.to_string_lossy().into_owned();
            let _ = weak.upgrade_in_event_loop(move |app| {
                if left {
                    app.set_folder_compare_left_path(text.into());
                } else {
                    app.set_folder_compare_right_path(text.into());
                }
            });
        }
    });
}

pub(crate) fn connect_folder_compare(app: &MainWindow) {
    // Vorbelegt mit Systemmüll. Jede ignorierte Datei in A schwächt das Urteil zu "BESTÄTIGT AUSSER IGNORIERTEN".
    // Vorbelegt mit Systemmüll (.DS_Store, ._* usw.). Diese Dateien erscheinen nicht in der Tabelle und werden nie kopiert.
    // Leeres Feld = völlig streng.
    app.set_folder_compare_ignore_patterns(DEFAULT_IGNORE_PATTERNS.into());
    audit_actions::connect(app);
    let weak = app.as_weak();
    app.on_folder_compare_preview(move |a, b| {
        let Some(app) = weak.upgrade() else { return; };
        if app.get_folder_compare_busy() { return; }
        let left = PathBuf::from(a.as_str());
        let right = PathBuf::from(b.as_str());
        let patterns = match parse_patterns(app.get_folder_compare_ignore_patterns().as_str()) {
            Ok(p) => p,
            Err(e) => { app.set_folder_compare_status(e.into()); return; }
        };
        // The index is held in memory; no filesystem reading or hashing occurs.
        match crate::folder_relations::index_pair_preview(&left, &right) {
            Ok((files_a, files_b, message)) => {
                let (rows, info) = audit_actions::prepare_index_preview(&left, &right, files_a, files_b, patterns);
                app.set_folder_audit_rows(audit_actions::to_model(rows));
                audit_actions::update_metrics(&app);
                app.set_folder_audit_page_info(info.into());
                app.set_folder_audit_selected(-1);
                app.set_folder_compare_status(message.clone().into());
                app.set_folder_compare_output(message.into());
                app.set_folder_compare_has_report(true);
            }
            Err(error) => {
                audit_actions::reset();
                audit_actions::update_metrics(&app);
                app.set_folder_compare_has_report(false);
                app.set_folder_audit_rows(audit_actions::to_model(Vec::new()));
                app.set_folder_audit_page_info("Keine Index-Vorschau".into());
                app.set_folder_compare_status(format!("Vorschau nicht möglich: {error}. Für einen vollständigen Vergleich 'Neu prüfen' wählen.").into());
            }
        }
    });

    let weak = app.as_weak();
    app.on_folder_compare_choose_left(move || {
        if let Some(app) = weak.upgrade() {
            choose_folder(&app, true);
        }
    });

    let weak = app.as_weak();
    app.on_folder_compare_choose_right(move || {
        if let Some(app) = weak.upgrade() {
            choose_folder(&app, false);
        }
    });

    let stop = Arc::new(AtomicBool::new(false));
    let stop_for_cancel = Arc::clone(&stop);
    app.on_folder_compare_cancel(move || {
        stop_for_cancel.store(true, Ordering::Relaxed);
        audit_actions::cancel_batch();
    });

    // The complete report of the last run (the popup shows a shortened version for very long lists).
    let report = Arc::new(Mutex::new(String::new()));

    let weak = app.as_weak();
    let report_for_save = Arc::clone(&report);
    app.on_folder_compare_save_report(move || {
        let Some(app) = weak.upgrade() else { return };
        let text = audit_actions::index_preview_report()
            .unwrap_or_else(|| report_for_save.lock().map(|guard| guard.clone()).unwrap_or_default());
        if text.is_empty() {
            return;
        }
        show_file_dialog_overlay(&app);
        let weak = app.as_weak();
        thread::spawn(move || {
            let target = FileDialog::new().set_file_name("folder_compare_report.txt").save_file();
            hide_file_dialog_overlay(&weak);
            let Some(path) = target else { return };
            let message = match fs::write(&path, text) {
                Ok(()) => format!("Report saved: {}", path.display()),
                Err(e) => format!("Saving the report failed: {e}"),
            };
            let _ = weak.upgrade_in_event_loop(move |app| app.set_folder_compare_status(message.into()));
        });
    });

    let weak = app.as_weak();
    app.on_folder_compare_start(move |a, b, patterns| {
        let Some(app) = weak.upgrade() else { return };
        if app.get_folder_compare_busy() {
            return;
        }
        let ignore = match parse_patterns(patterns.as_str()) {
            Ok(list) => list,
            Err(error) => {
                app.set_folder_compare_output(format!("INCONCLUSIVE - NO DELETION ADVISED\n{error}").into());
                return;
            }
        };
        stop.store(false, Ordering::Relaxed);
        audit_actions::reset();
        audit_actions::update_metrics(&app);
        app.set_folder_audit_rows(audit_actions::to_model(Vec::new()));
        app.set_folder_audit_page_info("Audit läuft ...".into());
        app.set_folder_audit_selected(-1);
        app.set_folder_compare_busy(true);
        app.set_folder_compare_has_report(false);
        app.set_folder_compare_status("".into());
        app.set_folder_compare_output("Starting ...".into());

        // Status lines are forwarded to the UI by a small thread that owns the window handle.
        // Late lines are dropped once the audit is no longer busy, so they never overwrite the result.
        let (status_tx, status_rx) = crossbeam_channel::unbounded::<String>();
        let ui = app.as_weak();
        thread::spawn(move || {
            while let Ok(text) = status_rx.recv() {
                let _ = ui.upgrade_in_event_loop(move |app| {
                    if app.get_folder_compare_busy() {
                        app.set_folder_compare_output(text.into());
                    }
                });
            }
        });

        let weak = app.as_weak();
        let stop = Arc::clone(&stop);
        let report = Arc::clone(&report);
        thread::spawn(move || {
            let result = analyze(Path::new(a.as_str()), Path::new(b.as_str()), &ignore, &stop, &status_tx);
            drop(status_tx);
            let (shown, full, audit_table) = match result {
                Ok((audit, a, b)) => {
                    let table = audit_actions::prepare(&audit, &a, &b);
                    (render_report(&audit, &a, &b, Some(UI_LIST_LIMIT)), render_report(&audit, &a, &b, None), Some(table))
                }
                Err(error) => {
                    let text = format!("INCONCLUSIVE - NO DELETION ADVISED\n{error}");
                    (text.clone(), text, None)
                }
            };
            if let Ok(mut guard) = report.lock() {
                *guard = full;
            }
            let has_audit = audit_table.is_some();
            let _ = weak.upgrade_in_event_loop(move |app| {
                app.set_folder_compare_output(shown.into());
                if let Some((rows, page_info)) = audit_table {
                    app.set_folder_audit_rows(audit_actions::to_model(rows));
                audit_actions::update_metrics(&app);
                    app.set_folder_audit_page_info(page_info.into());
                } else {
                    app.set_folder_audit_rows(audit_actions::to_model(Vec::new()));
                    audit_actions::update_metrics(&app);
                    app.set_folder_audit_page_info("Audit fehlgeschlagen".into());
                }
                app.set_folder_compare_has_report(has_audit);
                app.set_folder_compare_busy(false);
            });
        });
    });
}

#[cfg(test)]
mod tests {
    use std::time::{SystemTime, UNIX_EPOCH};

    use super::*;

    struct Fixture(PathBuf);
    impl Fixture {
        fn new() -> Self {
            let id = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
            let dir = std::env::temp_dir().join(format!("krokiet_folder_compare_{}_{}", std::process::id(), id));
            fs::create_dir_all(dir.join("A")).unwrap();
            fs::create_dir_all(dir.join("B")).unwrap();
            Self(dir)
        }
        fn a(&self) -> PathBuf {
            self.0.join("A")
        }
        fn b(&self) -> PathBuf {
            self.0.join("B")
        }
    }
    impl Drop for Fixture {
        fn drop(&mut self) {
            // Restore permissions so that cleanup also works after permission tests.
            #[cfg(unix)]
            {
                use std::os::unix::fs::PermissionsExt;
                if let Ok(entries) = fs::read_dir(self.a()) {
                    for e in entries.flatten() {
                        let _ = fs::set_permissions(e.path(), fs::Permissions::from_mode(0o755));
                    }
                }
            }
            let _ = fs::remove_dir_all(&self.0);
        }
    }
    fn run_with(f: &Fixture, patterns: &str) -> Audit {
        let (status, _keep) = crossbeam_channel::unbounded();
        let ignore = parse_patterns(patterns).unwrap();
        analyze(&f.a(), &f.b(), &ignore, &Arc::new(AtomicBool::new(false)), &status).unwrap().0
    }
    fn run(f: &Fixture) -> Audit {
        run_with(f, "")
    }

    #[test]
    fn renamed_nested_files_and_extra_are_supported() {
        let f = Fixture::new();
        fs::create_dir_all(f.a().join("nested")).unwrap();
        fs::create_dir_all(f.b().join("other")).unwrap();
        fs::write(f.a().join("nested/old.bin"), b"file contents").unwrap();
        fs::write(f.b().join("other/renamed.bin"), b"file contents").unwrap();
        fs::write(f.b().join("new.bin"), b"more content").unwrap();
        let report = run(&f);
        assert_eq!(report.pairs.len(), 1);
        assert!(report.missing_a.is_empty());
        assert_eq!(report.extra_b.len(), 1);
        assert_eq!(verdict(&report), Verdict::Confirmed);
    }
    #[test]
    fn duplicate_multiplicity_is_respected() {
        let f = Fixture::new();
        fs::write(f.a().join("one.txt"), b"identical").unwrap();
        fs::write(f.a().join("two.txt"), b"identical").unwrap();
        fs::write(f.b().join("one.txt"), b"identical").unwrap();
        let report = run(&f);
        assert_eq!(report.pairs.len(), 1);
        assert_eq!(report.missing_a.len(), 1);
        assert_eq!(verdict(&report), Verdict::NotComplete);
    }
    #[test]
    fn empty_files_are_compared_including_multiplicity() {
        let f = Fixture::new();
        fs::write(f.a().join("one"), b"").unwrap();
        fs::write(f.a().join("two"), b"").unwrap();
        fs::write(f.b().join("renamed"), b"").unwrap();
        let report = run(&f);
        assert_eq!(report.pairs.len(), 1);
        assert_eq!(report.missing_a.len(), 1);
    }
    #[test]
    fn differing_content_is_not_matched() {
        let f = Fixture::new();
        fs::write(f.a().join("file.bin"), b"111").unwrap();
        fs::write(f.b().join("file.bin"), b"222").unwrap();
        let report = run(&f);
        assert_eq!(report.pairs.len(), 0);
        assert_eq!(report.missing_a.len(), 1);
    }
    #[test]
    fn nested_roots_are_rejected() {
        let f = Fixture::new();
        let (status, _keep) = crossbeam_channel::unbounded();
        assert!(analyze(&f.a(), &f.a(), &[], &Arc::new(AtomicBool::new(false)), &status).is_err());
    }
    #[test]
    fn cancelled_scan_gives_no_verdict() {
        let f = Fixture::new();
        fs::write(f.a().join("x"), b"x").unwrap();
        fs::write(f.b().join("x"), b"x").unwrap();
        let (status, _keep) = crossbeam_channel::unbounded();
        let result = analyze(&f.a(), &f.b(), &[], &Arc::new(AtomicBool::new(true)), &status);
        assert!(result.is_err());
    }
    #[test]
    fn ds_store_in_a_is_junk_and_does_not_weaken_the_verdict() {
        let f = Fixture::new();
        fs::write(f.a().join("doc.txt"), b"same").unwrap();
        fs::write(f.b().join("doc.txt"), b"same").unwrap();
        fs::write(f.a().join(".DS_Store"), b"finder junk A").unwrap();
        fs::write(f.a().join("._doc.txt"), b"apple double").unwrap();
        assert_eq!(verdict(&run(&f)), Verdict::NotComplete); // without ignore list the junk is "missing"
        let ignored = run_with(&f, DEFAULT_IGNORE_PATTERNS);
        assert_eq!(verdict(&ignored), Verdict::ConfirmedExceptIgnored);
        assert_eq!(ignored.ignored_a.len(), 2);
    }
    #[test]
    fn user_added_patterns_never_give_a_plain_confirmation() {
        let f = Fixture::new();
        fs::write(f.a().join("doc.txt"), b"same").unwrap();
        fs::write(f.b().join("doc.txt"), b"same").unwrap();
        fs::write(f.a().join("precious.mov"), b"only in A").unwrap();
        let report = run_with(&f, "*.mov");
        assert_eq!(verdict(&report), Verdict::ConfirmedExceptIgnored);
        assert_eq!(report.custom_ignored_a, 1);
    }
    #[test]
    fn directories_are_never_ignored_even_if_the_name_matches() {
        let f = Fixture::new();
        fs::create_dir_all(f.a().join("Thumbs.db")).unwrap();
        fs::write(f.a().join("Thumbs.db/important.txt"), b"data").unwrap();
        let report = run_with(&f, DEFAULT_IGNORE_PATTERNS);
        assert_eq!(report.missing_a.len(), 1);
        assert_eq!(verdict(&report), Verdict::NotComplete);
    }
    #[test]
    fn ignored_file_is_never_used_as_a_match() {
        let f = Fixture::new();
        fs::write(f.a().join("real.bin"), b"payload").unwrap();
        fs::write(f.b().join(".DS_Store"), b"payload").unwrap(); // identical content, but ignored
        let report = run_with(&f, ".DS_Store");
        assert_eq!(report.missing_a.len(), 1);
        assert_eq!(verdict(&report), Verdict::NotComplete);
    }
    #[test]
    fn glob_and_pattern_parsing() {
        assert!(glob_match("._*", "._photo.jpg"));
        assert!(glob_match(".ds_store", ".DS_Store"));
        assert!(glob_match("*.tmp", "a.TMP"));
        assert!(!glob_match("._*", "photo._x"));
        assert!(glob_match("a*b*c", "aXXbYYc"));
        assert!(!glob_match("a*b*c", "aXXbYY"));
        assert!(parse_patterns("*").is_err());
        assert!(parse_patterns("dir/file").is_err());
        assert_eq!(parse_patterns(" .DS_Store ,\n._* ,,").unwrap(), vec![".DS_Store".to_owned(), "._*".to_owned()]);
    }
    #[test]
    fn link_resolution_is_lexical_and_depth_aware() {
        assert_eq!(resolve_target(Path::new("/r/A/d/l"), Path::new("../x")), PathBuf::from("/r/A/x"));
        assert_eq!(resolve_target(Path::new("/r/A/l"), Path::new("../x")), PathBuf::from("/r/x"));
        assert_eq!(resolve_target(Path::new("/r/A/l"), Path::new("/abs/./y/../z")), PathBuf::from("/abs/z"));
        assert!(starts_with_ci(Path::new("/R/a/Sub"), Path::new("/r/A")));
        assert!(!starts_with_ci(Path::new("/r/AB"), Path::new("/r/A")));
    }
    #[cfg(unix)]
    #[test]
    fn symlink_in_b_pointing_into_a_blocks_deletion() {
        let f = Fixture::new();
        fs::write(f.a().join("a.txt"), b"data").unwrap();
        fs::write(f.b().join("a.txt"), b"data").unwrap();
        std::os::unix::fs::symlink(f.a().join("a.txt"), f.b().join("abs_link")).unwrap(); // absolute into A
        let report = run(&f);
        assert_eq!(verdict(&report), Verdict::DependencyOnA);
        assert_eq!(report.links_b_into_a.len(), 1);
    }
    #[cfg(unix)]
    #[test]
    fn relative_symlink_in_b_reaching_into_a_blocks_deletion() {
        let f = Fixture::new();
        fs::write(f.a().join("a.txt"), b"data").unwrap();
        fs::write(f.b().join("a.txt"), b"data").unwrap();
        std::os::unix::fs::symlink("../A/a.txt", f.b().join("rel_link")).unwrap();
        assert_eq!(verdict(&run(&f)), Verdict::DependencyOnA);
    }
    #[cfg(unix)]
    #[test]
    fn harmless_symlink_in_b_does_not_block() {
        let f = Fixture::new();
        fs::write(f.a().join("a.txt"), b"data").unwrap();
        fs::write(f.b().join("a.txt"), b"data").unwrap();
        std::os::unix::fs::symlink("a.txt", f.b().join("link")).unwrap();
        let report = run(&f);
        assert_eq!(verdict(&report), Verdict::Confirmed);
        assert_eq!(report.links_b, 1);
    }
    #[cfg(unix)]
    #[test]
    fn symlink_in_a_needs_an_equivalent_that_resolves_the_same() {
        let f = Fixture::new();
        fs::create_dir_all(f.a().join("d")).unwrap();
        fs::create_dir_all(f.b().join("d")).unwrap();
        fs::write(f.a().join("a.txt"), b"data").unwrap();
        fs::write(f.b().join("a.txt"), b"data").unwrap();
        // A: d/link -> ../a.txt  (resolves to A/a.txt, inside A)
        std::os::unix::fs::symlink("../a.txt", f.a().join("d/link")).unwrap();
        assert_eq!(verdict(&run(&f)), Verdict::Inconclusive); // B has no link at all
        // B: same stored text one level higher resolves outside B, so it is NOT equivalent
        std::os::unix::fs::symlink("../a.txt", f.b().join("link")).unwrap();
        assert_eq!(verdict(&run(&f)), Verdict::Inconclusive);
        // B: d/link -> ../a.txt resolves to B/a.txt which exists: equivalent
        std::os::unix::fs::symlink("../a.txt", f.b().join("d/link")).unwrap();
        let report = run(&f);
        assert!(report.missing_links_a.is_empty());
        assert_eq!(verdict(&report), Verdict::Inconclusive); // Links are NOT verified by target content
    }
    #[cfg(unix)]
    #[test]
    fn matching_symlink_text_with_different_target_contents_is_inconclusive() {
        let f = Fixture::new();
        fs::write(f.a().join("old"), b"A").unwrap();
        fs::write(f.b().join("renamed"), b"A").unwrap();
        fs::write(f.b().join("old"), b"B").unwrap();
        std::os::unix::fs::symlink("old", f.a().join("link")).unwrap();
        std::os::unix::fs::symlink("old", f.b().join("link")).unwrap();
        assert_eq!(verdict(&run(&f)), Verdict::Inconclusive);
    }
    #[cfg(unix)]
    #[test]
    fn unreadable_directory_gives_no_verdict() {
        use std::os::unix::fs::PermissionsExt;
        let f = Fixture::new();
        fs::create_dir_all(f.a().join("locked")).unwrap();
        fs::write(f.a().join("locked/secret"), b"x").unwrap();
        fs::set_permissions(f.a().join("locked"), fs::Permissions::from_mode(0o000)).unwrap();
        if fs::read_dir(f.a().join("locked")).is_ok() {
            fs::set_permissions(f.a().join("locked"), fs::Permissions::from_mode(0o755)).unwrap();
            return; // running as root: permissions are not enforced, nothing to test
        }
        let (status, _keep) = crossbeam_channel::unbounded();
        let result = analyze(&f.a(), &f.b(), &[], &Arc::new(AtomicBool::new(false)), &status);
        fs::set_permissions(f.a().join("locked"), fs::Permissions::from_mode(0o755)).unwrap();
        assert!(result.is_err());
    }
    #[cfg(unix)]
    #[test]
    fn unreadable_file_gives_no_verdict() {
        use std::os::unix::fs::PermissionsExt;
        let f = Fixture::new();
        fs::write(f.a().join("secret"), b"same-size-1").unwrap();
        fs::write(f.b().join("secret"), b"same-size-1").unwrap();
        fs::set_permissions(f.a().join("secret"), fs::Permissions::from_mode(0o000)).unwrap();
        if fs::File::open(f.a().join("secret")).is_ok() {
            return; // running as root
        }
        let (status, _keep) = crossbeam_channel::unbounded();
        let result = analyze(&f.a(), &f.b(), &[], &Arc::new(AtomicBool::new(false)), &status);
        fs::set_permissions(f.a().join("secret"), fs::Permissions::from_mode(0o644)).unwrap();
        assert!(result.is_err(), "a file that cannot be read must never lead to a verdict");
    }

    /// Headless run on REAL folders, without the GUI:
    /// FC_A=/Volumes/Disk/a FC_B=/Volumes/Disk/b [FC_IGNORE=""] \
    ///   cargo test -p krokiet folder_compare::tests::real_folders --release -- --ignored --nocapture
    #[test]
    #[ignore = "needs FC_A and FC_B pointing at real folders"]
    fn real_folders() {
        let (Ok(a), Ok(b)) = (std::env::var("FC_A"), std::env::var("FC_B")) else {
            panic!("set FC_A and FC_B");
        };
        let ignore = parse_patterns(&std::env::var("FC_IGNORE").unwrap_or_default()).unwrap();
        let (status, rx) = crossbeam_channel::unbounded();
        thread::spawn(move || {
            while let Ok(line) = rx.recv() {
                eprintln!("{line}");
            }
        });
        match analyze(Path::new(&a), Path::new(&b), &ignore, &Arc::new(AtomicBool::new(false)), &status) {
            Ok((audit, a, b)) => println!("{}", render_report(&audit, &a, &b, None)),
            Err(error) => println!("INCONCLUSIVE - NO DELETION ADVISED\n{error}"),
        }
    }


}
