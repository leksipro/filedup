# Krokiet Folder Compare – v22.5: Stability & Performance (Build 225)

Basis: Original Krokiet/Czkawka 12.0.2 + Patch v22.4. Quellcode-Patch, keine vorkompilierte App.

## Was geändert wurde

- Nach erfolgreichem Kopieren, Verschieben, Löschen oder einem abgebrochenen Auftrag mit Teilerfolgen: **kein automatischer globaler Index-Neuaufbau**. Der aktive Vergleich bleibt lokal aktualisiert; bekannte erfolgreiche Änderungen werden im Arbeitsspeicher vorgemerkt. Auch nur kopierte Dateien zählen als Kopien. Die bisherige Dateioperations- und ACL-Engine bleibt erhalten.
- Die globale Ordnerübersicht wird bis zur Aktualisierung geleert und als aktualisierungsbedürftig beschriftet. Mit **Ordnerindex aktualisieren** (oder Reiterwechsel in der Ordnerübersicht) werden die vorgemerkten Änderungen gesammelt übernommen. Kein neuer vollständiger Festplattenscan oder Hash-Scan nötig, sofern die Änderungen noch nachvollziehbar sind. Ein frischer Audit des ausgewählten Ordnerpaares bleibt möglich. Ein neuer Index-Vorschauvergleich wird blockiert, solange die alte globale Grundlage nicht aktualisiert ist.
- Der verzögerte Abgleich speichert bei erfolgreicher Übertragung Größen, präzise Änderungszeiten, unter Unix Geräte-/Inode- und ctime-Informationen. Bei mehreren Aufträgen werden die Änderungen in Reihenfolge angewandt und nur der Endzustand der betroffenen Pfade überprüft (z.B. Kopie und anschließende Entfernung der Quelle). Bei unerwarteten Änderungen wird die globale Ansicht als unsicher gekennzeichnet; neuer Scan empfohlen. Kein schneller Löschbeweis aus einem unsicheren Index. Neue oder durch lokale Dateiaktionen berührte Pfade bekommen aus dem verzögert rekonstruierten Index keine erneuerte Fast-Proof-Autorisierung; bei ihnen Hash oder Bytes wählen. Unveränderte Dateien mit gültigem Scanbeweis behalten Schnell (Index). Bestehende Sicherheitsprüfungen werden nicht gelockert.
- Beim expliziten globalen Neuaufbau werden nur betroffene Pfade in einer zusätzlichen BTreeMap gehalten. Unveränderte Dateien gehen direkt in den Inventarvektor. Der alte globale Index, View und Analyse-Cache werden vor dem Aufbau des neuen Indexes freigegeben, soweit keine weiteren Leser darauf zugreifen. Generationsprüfung verhindert veraltete GUI-Publikation. Analyseaufrufe werden serialisiert; Dateiaktionen und explizite globale Analyse können nicht gleichzeitig über die Oberfläche gestartet werden.
- Filterindizes werden für die aktuelle Filter-/Scope-Kombination zwischengespeichert. Zähler werden bei Datenänderungen invalidiert und neu berechnet, nicht bei jedem bloßen Auswahlwechsel. Die teurere Cache-Erneuerung nach Sammelaktionen wird im Hintergrund vorbereitet. Kein vollständig inkrementeller Index. Erster Filterwechsel kann weiterhin alle Einträge durchlaufen.
- Slint: bestehende `VecModel`-Instanzen werden, soweit möglich, weiterverwendet; geänderte Zellen werden einzeln gesetzt. Ordnergruppen werden jetzt serverseitig auf 40 pro Seite begrenzt, Dateiliste weiterhin 120 und Ordnerpaare 40. Seiten-/Zeilenzuordnung und globale Auswahl bleiben erhalten. Fehlerpanel als permanent erzeugte, nur bei Fehlern sichtbare Überlagerung; Buttons bleiben instanziiert und werden passend aktiviert/deaktiviert. Fortschritt, Status und Dateioperationsbericht erhalten feste Layoutzeilen.
- Neuer lokaler Stabilitätsbericht: `~/Library/Logs/Krokiet Folder Compare/stability-<Zeit>-<PID>.txt`. Zeit, Thread, Rust-/Slint-Version, wesentliche Index-/GUI- und Dateioperationsphasen, RSS in KiB an größeren Verarbeitungsschritten sowie bestmögliche Rust-Panic-Meldung/Backtrace. Der Panic-Hook kann bei direkten Speicherallokationsabbrüchen ausfallen; die bis dahin geschriebenen Zeilen und macOS-.ips-Berichte bleiben relevant. Kein Hintergrundmonitoring, keine Übertragung von Protokollen.
- Slint bleibt auf dem vom Original gepinnten Stand; kein ungezieltes Dependency-Update. Upstream Changelog nennt 1.17.0 für 12.0.2; GitHub-Workflow liest die tatsächliche Version aus Cargo.lock und bettet sie zusammen mit rustc --version in die Stabilitätsprotokollierung ein. Cache und gemeinsames Release-Profil aus v22.4 bleiben erhalten.

## Bedienung und Grenzen

1. Im bestehenden Ordnervergleich wie zuvor kopieren, verschieben oder löschen; ACL-Aufhebung bleibt explizit optional. Bei einem Fehler sind Überspringen, Finder-Wiederholung und Stop wie zuvor verfügbar.
2. Nach einer Dateioperation kannst du im selben Vergleich weiterarbeiten. Die globale Übersicht bleibt bewusst leer bis zur nächsten Aktualisierung.
3. Wenn du andere globale Ordnerpaare sehen möchtest, klicke auf „Ordnerindex aktualisieren“. Dabei wird der Index noch einmal vollständig aus dem bisherigen Inventar plus Änderungen rekonstruiert; er ist nicht dauerhaft inkrementell. Die vorgemerkten Änderungen sind nur in dieser Sitzung verfügbar. Der alte persistente Snapshot wird bei Änderungen verworfen. Bei Neustart vor der Aktualisierung ist ggf. ein neuer Scan erforderlich; das Dateioperationsprotokoll bleibt erhalten. Kein automatisches Replay von Löschaktionen.
4. Bei erneutem Absturz bitte die neueste `stability-…txt`, `operation-…txt` und `.ips` mit identischer PID bereitstellen. Teste erst mit entbehrlichen Dateien und einem kleinen Auftrag, inklusive Fehlerdialog/Stop. Danach einen großen Vergleich/Filterwechsel testen.

Nicht umgesetzt: vollständig inkrementeller globaler Index, inkrementelle Zähler pro einzelner Datei, lazy B-only-Einträge, vollständige GUI-Render-/Millionen-Dateien-Belastungstests und Slint-Upgrade. Die konkrete Panic-Ursache ist weiterhin nicht bewiesen. Die Optimierungen sind durch vorhandene Codepfade begründet; Laufzeiten und tatsächliche Stabilität müssen auf dem Ziel-Mac gemessen werden.

## Installation und Validierung

Patch `krokiet_folder_compare_patch_12.0.2_v22-5.zip` ins Repo-Hauptverzeichnis, Workflow `build-krokiet-v22-5.yml` nach `.github/workflows/`. Artifact `krokiet-v22-5-macos-arm64-app`; macOS ARM64 ab 13.0, Build 225, unveränderte Bundle-ID `local.krokiet.foldercompare.v22`. Das äußere Komplettpaket nur lokal entpacken.

69 Python-/Strukturtests lokal bestanden; YAML und Shell-Syntax geprüft. Neue Rust-Tests für geordnete Journal-Wiedergabe (Kopie + Löschen), Ablehnung späterer Änderungen, fachliche Übereinstimmung nach Löschung und Cache-/Seitengrenzen sind im Patch enthalten. Rust/Slint/Swift-Kompilierung und native ACL-/GUI-Laufzeittests müssen im macOS-Workflow bzw. auf dem Mac ausgeführt werden. Die Python-Tests sind kein Nachweis für die Rust-Kompilierung oder Absturzfreiheit.

---

## Historie (v22.4 und früher)

# Krokiet Folder Compare – v22.4: Stabilere Listen und Verschieben mit ACL-Aufhebung

## Aktueller Stand (v22.4 / Build 224)

- Drei virtualisierte ListViews des tatsächlich eingebundenen Konsolidierungsfensters durch ScrollView/VerticalLayout ersetzt. 40 Ordnerpaare (bestehende Seitengröße), bis zu 40 dargestellte Unterordner, 120 Dateien je Seite. Globale Auswahl bleibt erhalten. Vorwärts/Rückwärts benutzen dieselbe Seitenabbildung wie Auswahl, Preview und Finder. Der zugrunde liegende Dateiindex und das vollständige Gruppenmodell bleiben erhalten; dies ist keine generelle Speicherlimitierung.
- Auslöser des Workarounds: zwei macOS-Absturzberichte mit SIGABRT in Slints `ensure_updated_listview`/`RepeaterInstanceOps::splice`. Behebung des konkreten Absturzes muss am Ziel-Mac bestätigt werden; keine Änderung an Slint-Abhängigkeiten.
- In beiden Verschieberichtungen explizite Option „ACL-Löschschutz der Quelle aufheben (dauerhaft, Admin)“. Vorabprüfung und gemeinsame Bestätigung verwenden die tatsächliche Quelle; kein zusätzlicher B→A-Batch-Klon. Nur explizite everyone-Löschverbote im freigegebenen Quellbereich werden entfernt. Nicht ausgewählte Kinder können durch Eltern-ACL-Änderung ebenfalls löschbar werden. Rechte bleiben bei späterem Abbruch geändert. Keine pauschale Rekursion, kein Löschen als root, Hardlink-/Symlink-/Scope-Schutz bleiben erhalten.
- Einzigartige Quelldateien haben noch kein Gegenstück; vor ACL-Änderung werden Quelle, Linkgrenzen und geplanter (fehlender) Zielpfad geprüft. Nach Übertragung wird die tatsächliche Kopie weiterhin byteweise und auf sichtbare macOS-xattrs geprüft. Die freie Wahl von Index, Hash und Bytevergleich bei Duplikat-Löschungen bleibt unverändert. Kein ungeprüftes Entfernen einer einzigartigen Quelle.
- Nach fehlgeschlagener Quellenentfernung: Finder-Wiederholung nach erneuter Prüfung, oder überspringen/stoppen. Bericht dokumentiert BEGIN mit beiden Pfaden, ZIEL VERIFIZIERT vor Quellenentfernung beim Kopierpfad, OK mit Zielpfad sowie Teilkopien. Bei Bericht-Schreibfehler vor Entfernung bleibt die Quelle bestehen. Der gleichvolumige Hardlink-Pfad behält das bisherige Verhalten (Entfernung des alten Links erst nach Identitätsprüfung).
- Nach abgebrochenem Auftrag zuerst Bericht prüfen und betroffene Ordner frisch vergleichen. Der Filter „Gleicher Pfad“ zeigt nur als identisch eingestufte Paare am gleichen relativen Pfad. Berichtete Teilkopien gezielt auswählen und Quelle über den normalen Löschdialog entfernen (bei B als Quelle A/B tauschen). Frischen Hash oder Byteprüfung wählen. Kein automatischer Replay und kein automatisches Löschen anhand alter Berichte.
- Bestehende Ordnerstruktur und Zielkonfliktschutz bleiben erhalten. Leere Ordner, Strukturmodus und Ordner-Metadatenübernahme sind nicht neu implementiert. macOS cp -p übernimmt weiterhin die übrigen ACLs und xattrs; keine automatische Bereinigung der Zieldatei. Quelle kann nach Fehler weiterhin bestehen.
- Build: `cargo test -p krokiet --locked --release --target aarch64-apple-darwin` und `cargo build -p krokiet --release --locked --target aarch64-apple-darwin` nutzen dasselbe Release-Profil. Kein Löschen der Build-Artefakte zwischen Test und Build. Swatinem/rust-cache@v2 mit festem, versionsübergreifendem shared-key für 12.0.2/ARM64/Release; Cache berücksichtigt Toolchain/Lockfile. Zwei Cargo-Jobs bleiben bewusst unverändert. Erster Lauf hat evtl. noch keinen Cache; genaue Zeitersparnis erst nach GitHub-Lauf messbar. Alle Python-, Rust-, macOS-ACL- und Swift-Helfer-Prüfungen bleiben verpflichtend.

## Installation v22.4

Patch `krokiet_folder_compare_patch_12.0.2_v22-4.zip` ins Repo-Hauptverzeichnis. Workflow `.github/workflows/build-krokiet-v22-4.yml`. Artifact `krokiet-v22-4-macos-arm64-app`. Buildnummer 224, Bundle-ID `local.krokiet.foldercompare.v22`, macOS 13.0 ARM64. Kein Upload des äußeren GitHub-Pakets selbst. Zuerst Testdaten oder wenige verifizierte, entbehrliche Dateien verwenden.

## Historie (vorherige Releases)

# Krokiet Folder Compare – v22.3: Unabhängige Prüfmodi und ACL-Aufhebung

Basis: Czkawka/Krokiet 12.0.2, Patch v22.2. Quellcode-Patch, keine kompilierte App.

## Änderungen und Bedienung

- Prüfmethode und Löschmethode sind unabhängig. Bei `Papierkorb`, `ACL-Löschschutz aufheben + Papierkorb`, `Finder (ggf. Admin, 1 Datei)` und `Force Delete (endgültig)` stehen Schnell (Index), Aktueller Hash (BLAKE3) und Bytevergleich zur Verfügung. Standard bleibt Aktueller Hash. Der schnelle Modus setzt einen gültigen früheren Inhaltsnachweis und unveränderte gespeicherte Größen/Änderungszeiten voraus; er liest die regulären Dateiinhalte nicht erneut und ist schwächer. Keine stillschweigende Umstellung auf Bytevergleich. Force Delete ist endgültig und fordert selbst keine Adminrechte an. Eine Wiederholung über Finder behält den gewählten Modus bei.
- Die ACL-Erkennung benötigt weder den Ordnernamen `_CCC SafetyNet` noch Time-Machine-xattrs. Erkannt werden nur die expliziten `everyone deny delete` (Datei) bzw. `everyone deny delete_child` (Elternordner) ACL-Rechte. Rechtekorrektur nur im ausgewählten A-Baum, innerhalb eines Volumes unter `/Volumes` oder in gewöhnlichen Datenordnern des angemeldeten Konsolenbenutzers unter `/Users/<Benutzer>`. Volume-/Home-Wurzeln, Systempfade, bekannte Papierkorb-/Backup-Systemordner, versteckte Volume-Namen, `~/Library` und versteckte Home-Hauptordner sind von der privilegierten Änderung ausgeschlossen. Nicht auf aktiven Time-Machine-Backups oder gleichzeitig veränderten Daten verwenden; keine umfassende automatische Erkennung sämtlicher aktiver Backup-Volumes.
- Die ausgewählte Prüfmethode wird bei der Planung geschützter Dateien und unmittelbar vor dem Löschen erneut angewendet. Hash/Byte können daher für betroffene Dateien zwei vollständige Lesedurchgänge je Seite verursachen; Schnell (Index) vermeidet diese regulären Inhaltslesevorgänge. Resource Fork und FinderInfo werden in allen Modi weiterhin verglichen. Es gibt keine neue Performance-Messung auf dem Mac.
- ACL-Prüfung und tatsächliche Änderung akzeptieren `Icon` mit Carriage Return im Pfad: `/bin/ls -blde` escaped Steuerzeichen für die ACL-Auswertung; Originalpfad wird nicht verändert. Nicht-UTF-8-Pfade und Pfade mit LF bleiben in der ACL-Korrektur ausgeschlossen.
- Dateien, die während der ACL-Planung abgelehnt werden, werden aus dem laufenden Auftrag entfernt, im Bericht erfasst und gezählt. Nicht automatisch als normale Papierkorbdatei weiterverarbeiten. Bei unvollständiger Admin-Phase werden die noch nicht aufgehobenen bzw. nicht prüfbaren geplanten ACLs nachgeprüft und betroffene Dateien ausgeschlossen. Der Benutzer entscheidet, ob die übrigen verarbeitet werden sollen. Einzelne Laufzeitfehler bleiben separat bearbeitbar.
- Eigener Bestätigungsbutton „ACL ändern + fortfahren“; „Weitere Fehler überspringen“ ist während dieser Bestätigung nicht verfügbar. Ein gemeinsamer Admin-Aufruf für die ACL-Phase; keine permanente Root-Freigabe. Wie bisher sind Änderungen dauerhaft, auch wenn die anschließende Löschung fehlschlägt oder abgebrochen wird. Elternordner-Änderungen können auch die Löschbarkeit nicht ausgewählter unmittelbarer Kinder beeinflussen. Keine rekursiven chmod-Aktionen, keine Änderung der Vergleichsdateien in B, keine Root-Löschung. Link-, Geräte- und Inode-Prüfungen bleiben erhalten (nicht atomar; gleichzeitige Änderungen vermeiden).
- Der Dateioperationsbericht enthält jetzt zusätzlich den ausdrücklich gewählten Prüfmodus, ACL-Planungsausschlüsse und die nach einer unvollständigen Admin-Phase weiterhin geschützten Dateien. Bundle-ID bleibt `local.krokiet.foldercompare.v22`, Buildnummer 223.

## Tests und Build

ZIP `krokiet_folder_compare_patch_12.0.2_v22-3.zip`, Workflow `.github/workflows/build-krokiet-v22-3.yml`, Artifact `krokiet-v22-3-macos-arm64-app`. macOS ARM64, Deployment Target 13.0. Die macOS-CI-Teststruktur prüft ACL-Korrektur ohne Backup-Namen/xattrs, CR-Dateinamen, unveränderte unselektierte Dateien, Hardlink-/Symlink-/Scope-Ausschlüsse und unprivilegiertes Entfernen künstlicher Testdateien nach Korrektur. Der native Papierkorb auf dem externen Datenträger und der reale AppleScript-Admin-Dialog müssen separat am Ziel-Mac getestet werden. Das bekannte Slint-Listenproblem ist nicht als behoben ausgewiesen.

---

## Historie: v22.2 (alte Einschränkungen, durch v22.3 überholt)

# Krokiet Folder Compare – v22.2: Gezielte Backup-ACL-Aufhebung

## Neu in v22.2

- Neue explizite Löschmethode „Backup-Löschschutz aufheben + Papierkorb“. Nur für externe, kopierte `_CCC SafetyNet`-Archive unter `/Volumes`. Nicht auf aktiven Time-Machine-Backups verwenden.
- Vorabprüfung der ausgewählten Duplikate (Bytevergleich, Resource Fork, FinderInfo, Linkprüfung), Time-Machine-Metadaten und spezifische `everyone deny delete` / `deny delete_child`-Regeln. Geplante Änderungen und Pfade im Bericht.
- Zusätzliche Bestätigung der **dauerhaften** ACL-Änderung, insbesondere auch für nicht ausgewählte unmittelbare Kinder eines geänderten Elternordners. Keine automatische Wiederherstellung. Keine rekursive ACL-Korrektur, kein `chmod -N`, kein Löschen als root.
- Eine Admin-Anforderung für die ACL-Phase über `osascript` / fest eingebetteten Shell-Code; NUL-getrennte Datendatei statt riesiger Argumentliste, keine Speicherung von Passwörtern. Parent-ACLs werden gruppiert. Keine dauerhaft privilegierten Dienste.
- Pfad-, Geräte- und Inode-Prüfung vor Änderung; keine Symlinks oder mehrfach hartverlinkten Dateien mit zu ändernder Datei-ACL. Nicht gleichzeitig von anderen Prozessen manipulieren: Pfadprüfungen sind nicht atomar. Dateinamen mit Steuerzeichen werden für die ACL-Korrektur ausgelassen.
- Nach ACL-Aufhebung erneute Byte-/Metadatenprüfung und regulärer nativer Papierkorb. Bei Restfehlern bestehen die v22.1-Dialoge weiter. ACL-Änderungen können auch bei Abbruch oder späterem Löschfehler bestehen bleiben; während der laufenden Admin-Phase ist ein Stopp nicht sofort wirksam.
- Kein Nachweis für eine Behebung des Slint-Absturzes aus Build 220; dieser Bericht betrifft v22, nicht den späteren Löschabsturz.
- macOS-Test im Workflow mit isolierter ACL-Teststruktur. Der tatsächliche Admin-Dialog und native Papierkorb auf dem Benutzer-Mac müssen separat getestet werden.

### Build v22.2
ZIP `krokiet_folder_compare_patch_12.0.2_v22-2.zip`, Workflow `.github/workflows/build-krokiet-v22-2.yml`, Artifact `krokiet-v22-2-macos-arm64-app`.

---

# Historie: v22.1

Basis: Krokiet/Czkawka 12.0.2, Patch v22. **Quellcode-Teststand, keine kompilierte App.**

## Neu in v22.1

- Vor jeder Sammelaktion werden ausgewählte Quellen und Ziele nicht verändernd geprüft: reguläre Datei, lesbarer Quellpfad, vorhandene Vergleichsdatei, Größen, bekannte Link-Abhängigkeiten, bei Kopieren/Verschieben Zielkonflikte. Die Dateiinhaltsprüfung erfolgt unmittelbar vor der Aktion. Rechte, insbesondere ACL/TCC/Trash-Rechte, lassen sich damit nicht vollständig vorhersagen.
- Nicht geeignete Dateien werden aus dem laufenden Auftrag ausgeschlossen, bleiben aber zur späteren Bearbeitung in der Auswahl. Sind noch geeignete Dateien vorhanden, wird vor der Verarbeitung eine ausdrückliche Entscheidung verlangt. Unvollständige Link-Inventur verlangt ebenfalls Zustimmung; bekannte Abhängigkeiten bleiben gesperrt.
- Bei Laufzeitfehlern pausiert der Auftrag; Optionen: übrige versuchen, weitere Fehler überspringen, Auftrag stoppen. Nach fünf aufeinanderfolgenden Fehlern gibt es auch im Überspring-Modus eine erneute Warnung über ein mögliches systematisches Problem. Bei letzten Fehlern ohne Wiederholungsoption endet der Auftrag mit Bericht.
- Bei einem fehlgeschlagenen nativen Papierkorbversuch kann die betreffende Datei direkt über Finder erneut versucht werden (ggf. macOS-Admin-Dialog; erneuter Bytevergleich und Prüfung der Zusatzdaten). Keine automatische endgültige Löschung. Die bestehende Force-Delete-Option ist weiterhin normales `remove_file`, nicht Root.
- Jeder mutierende Auftrag erhält einen fortlaufend geschriebenen TXT-Bericht in `~/Library/Logs/Krokiet Folder Compare/`. Über **Dateioperationsbericht öffnen** lässt sich der letzte Bericht im Standardeditor öffnen, auch während einer Pause. Der Bericht enthält Pfade (Steuerzeichen wie CR werden escaped), A/B, Aktion, Volume-Informationen für externe Datenträger, jeden Vorab- und Laufzeit-Dateifehler, BEGIN/OK-Zeilen, bei Fehlern `ls -ldeOn@` der Datei und des Elternordners, Wiederholungen und Ergebniszahlen. Link-Inventurmeldungen enthalten weiterhin Anzahl und bis zu fünf Beispiele. Bericht lokal; Dateipfade können vertrauliche Namen enthalten. Prozessabbruch: bereits geschriebene Zeilen bleiben, letzter BEGIN ohne OK muss überprüft werden.
- Ein gebündelter, nicht privilegierter Swift-Helfer nutzt `FileManager.trashItem` und liefert `NSError`-Domain, Code, Beschreibung und rekursiven `NSUnderlyingErrorKey`. Er akzeptiert ausschließlich einen absoluten Pfad zu einer regulären Datei. Build per GitHub Actions; Rust-Entwicklungsbuild ohne Helfer nutzt die bisherige native Bibliothek. Start eines zusätzlichen Prozesses je Papierkorbdatei kann bei großen Aufträgen langsamer sein. Datenschutzverhalten des Helfers muss auf dem Ziel-Mac getestet werden.
- macOS: Duplikatlöschung prüft zusätzlich Resource Fork und FinderInfo (auch im schnellen Indexmodus). Unlesbare oder unterschiedliche Zusatzdaten verhindern die Löschung. Andere xattrs/ACLs sind weiterhin nicht Teil des Duplikatgleichheitsnachweises. Kopieren und dateisystemübergreifendes Verschieben nutzen `cp -p` und prüfen zusätzlich sämtliche sichtbaren Quell-xattrs gegen das Ziel; bei fehlenden/abweichenden xattrs bleibt die Quelle erhalten. Die maximale geprüfte xattr-Gesamtgröße ist 64 MiB je Datei; größere Fälle werden zur manuellen Prüfung ausgeschlossen. ACLs, Eigentümer und File Flags werden nicht vollständig verifiziert. Symlinks werden nicht verfolgt; gleichzeitige Änderungen durch andere Anwendungen vermeiden.
- Bundle-ID `local.krokiet.foldercompare.v22` bleibt erhalten. Ad-hoc-Signaturen können dennoch erneute macOS-Datenschutzfreigaben erfordern. Kein globales chmod/chown, keine SIP-Deaktivierung, kein privilegierter Dienst. Eine einmalige Administratorautorisierung für beliebig viele Dateien ist noch NICHT implementiert. Die tatsächliche Ursache der CCC-Backup-Fehler muss anhand eines Berichts identifiziert werden.

## Build und erster Test

ZIP `krokiet_folder_compare_patch_12.0.2_v22-3.zip` ins Repo-Hauptverzeichnis, Workflow `.github/workflows/build-krokiet-v22-3.yml`. Artifact `krokiet-v22-3-macos-arm64-app`. GitHub Actions prüft Python-Tests, Rust/Slint-Tests, erstellt die ARM64-App und kompiliert/signiert den Swift-Helfer; ein fehlender Testpfad muss mit POSIX-Fehler 2 gemeldet werden. Zunächst nur entbehrliche, verifizierte Testduplikate verwenden. Bei Fehler im CCC-Backup den erzeugten TXT-Bericht sichern. Keine Massendeletion vor erfolgreichem Test.

---

## Historie v22 und älter (historische Angaben, teilweise überholt)

# Krokiet Folder Compare – v22: Dateioperationen und Teilfehler

## Neu in v22
- Native macOS-Papierkorb-API (`trash::macos::DeleteMethod::NsFileManager`) je Datei statt Finder-/AppleScript-Paketen. Keine automatische permanente Löschung, keine automatische Rechteerhöhung. Bei fehlenden Rechten wird die Datei übersprungen; der Auftrag läuft weiter. macOS/TCC/ACL können weiterhin Zugriff verweigern. Wegen neuer Bundle-ID kann macOS Datenschutzrechte erneut abfragen.
- Kopieren und Verschieben wieder in beiden Richtungen im Arbeitsbereich. Kein Überschreiben. Bei dateisystemübergreifendem Move wird die Quelle erst nach erfolgreicher byteweiser Prüfung entfernt. Fehler werden einzeln gezählt; wenn eine verifizierte Kopie verbleibt, wird dies als nur kopiert gemeldet. Index und Tabelle werden für bestätigte Änderungen aktualisiert.
- Unlesbare Einträge/Bereiche im Symlink-Vorabcheck werden gezählt und mit Beispielen im Abschlussstatus gemeldet. **Unbekannte Link-Abhängigkeiten können nicht ausgeschlossen werden.** Bekannte Links schützen die betroffenen Pfade; Link-Ziele werden nicht verändert. Keine automatische Rechteänderung. Ungültige/überlappende Wurzelpfade blockieren weiterhin die ganze Operation. Ausgewählte Dateien werden separat geprüft.
- Papierkorb-/Löschbestätigung bietet drei getrennte Methoden: nativer Papierkorb (Standard), Finder-Wiederholung (genau ein identisches Dateipaar, ggf. macOS-Admin-Dialog) und Force Delete (endgültiges `remove_file`, nur byteweise verifiziertes Duplikat, kein Papierkorb und keine Umgehung von ACL/TCC). Letztere beiden erfordern immer Bytevergleich, unabhängig vom vorherigen Prüfmodus. Kann eine Datei nicht gelesen/verifiziert werden, wird sie auch hier nicht entfernt. Für unlesbare Alt-Systemdateien ggf. Finder oder Festplattenzugriffsrechte separat prüfen.
- Die normale Lösch-/Move-Operation fährt nach Einzelfehlern fort. Ergebnis enthält Anzahl erfolgreich, nicht durchgeführt, nicht bearbeitet, bis zu zwölf Fehlerdetails sowie Link-Warnungen. Abbruch zwischen Dateien möglich; bereits abgeschlossene Änderungen bleiben erhalten.
- Build auf macOS ARM64 weiterhin auf Basis 12.0.2, Cargo.lock bleibt gebunden. Python-Prüfungen sind strukturell; Rust-, Slint- und tatsächliche macOS-Dateioperationen müssen in CI bzw. auf einem Testdatenträger geprüft werden.

Die folgende Historie beschreibt frühere Implementierungen; deren Paketierungsangaben sind durch v22 ersetzt.

# Krokiet Folder Compare v21.3 – macOS ARM64 (Test-Build)

Basis: Krokiet/Czkawka 12.0.2, Weiterentwicklung von v19.1. **Dies ist Quellcode, keine kompilierte App.**


## v21.3 – Rust-Test an A-zentrierte Standardansicht angepasst

- Behebt den fehlgeschlagenen Rust-Test `session_row_is_updated_in_place` (`index out of bounds`): Nach Papierkorb aus A wird ein zuvor identisches Paar zu `Nur in B`. Die A-zentrierte Standardansicht blendet solche Einträge korrekt aus; der bisherige Test griff dennoch auf die zweite sichtbare Zeile zu.
- Der Test kontrolliert jetzt sowohl den **intern erhaltenen B-Dateieintrag** als auch dessen Sichtbarkeit über den expliziten `Nur B`-Filter. Kein Test übersprungen oder deaktiviert.
- Produktivlogik in Rust, Slint-UI, Performance-Optimierungen aus v21 und die Papierkorb-Paketierung aus v21.1 sind **unverändert**. Nur der Rust-Test und die Release-Verpackung wurden aktualisiert.
- Python-/Integrationstests ersetzen keinen macOS-Rust-Build. `cargo test -p krokiet` muss noch auf GitHub Actions durchlaufen.

## v21.2 – Slint-Tooltip-Kompilierungsfix

- Alle 16 Tooltips in `popup_folder_workspace.slint` geben nun `styled-text` mittels `@markdown(...)` aus.
- Dynamische Pfade und Statusmeldungen bleiben als dynamische Werte eingebunden; Inhalte werden bei der Markdown-Interpolation escaped.
- Keine Änderungen an der v21-Performance-Engine, am Datei-Scan oder an der v21.1-Papierkorb-Paketierung.
- Dieser Fix wurde statisch und mit Python-Regressionstests geprüft. Ein nativer macOS-Rust/Slint-Build bleibt erforderlich.

## v21.1 – Begrenzte Papierkorb-Systemaufrufe ohne Verlust der v21-Performance

- Der Fehler **„Argument list too long (os error 7)“** bei großen Papierkorb-Auswahlen wird adressiert: `trash::delete_all()` erhält nicht mehr die gesamte Auswahl auf einmal, sondern Pakete von höchstens **48 Pfaden**, zusätzlich begrenzt auf **32 KiB geschätzte Argumentkosten pro Aufruf** (mit Sicherheitszuschlag für Escaping). Das sind interne Paketgrenzen, **keine** Begrenzung der Dateiauswahl. Ein einzelner ungewöhnlich langer Pfad kann weiterhin einen macOS-Fehler auslösen.
- **Beide** zuvor unbeschränkten Aufrufstellen wurden angepasst: reguläre Papierkorb-Bereinigung und der datenträgerübergreifende Verschiebe-Fallback (historische, nicht prominent angebotene Move-Engine).
- Zwischen den Paketen kann abgebrochen werden. Jede Datei wird nach einem Paketergebnis separat auf den verbleibenden Quellpfad geprüft. Es werden ausschließlich eindeutig entfernte Dateien aus dem Index genommen; bereits kopierte Dateien mit verbliebener Quelle werden als Teilresultat behandelt.
- Ein weiterer macOS-Freigabedialog pro Paket ist möglich. Die Änderung behebt die überschrittene Argumentgröße, **nicht** Dateiberechtigungen, TCC-Abfragen oder sämtliche AppleScript-Probleme.
- Die v21-Dateizuordnung, Hintergrundvorschau, Ordner-Analyse-Caches und **Slint-UI sind unverändert geblieben**. Kein vollständiger Rust-/Slint- oder macOS-Laufzeittest in dieser Umgebung.

## v21 – Performance beim Laden eines Ordnerpaars und beim Seitenwechsel

Nur Geschwindigkeit, kein neuer Funktionsumfang. Gemessen wurde die Vorschau-Logik mit synthetischen Daten (190.000 Dateien in A, 3,4 Mio in B, Release-Build). Rust-Build von Krokiet und Slint sind weiterhin **nicht** geprüft.

- **Ordnerpaar wählen und „A/B tauschen“ liefen im UI-Thread.** Das Fenster fror ein, bis alle Zeilen gebaut waren. Jetzt läuft das im Hintergrund, die Oberfläche zeigt „Ordnerpaar wird aus dem Index geladen …“.
- **Quadratische Suche beseitigt.** Für jede identische Datei wurde die komplette B-Liste linear durchsucht (bei 115.000 identischen Dateien gegen 3,4 Mio B-Dateien). Das ist jetzt ein direkter Zugriff. Hochgerechnet etwa 17 Minuten, jetzt etwa 2 Sekunden. Die neue Funktion liefert Eintrag für Eintrag dasselbe wie die alte (Differenztest mit 3000 Zufallsfällen).
- **B wird nicht mehr komplett sortiert.** Bei Millionen Pfaden kostete das mehrere Sekunden. Nur A und die kleinen Kandidatenlisten werden sortiert. „Nur in B“ erscheint dafür in Baumreihenfolge.
- **Knotensuche im Index** baut Pfade nur noch für Ordner mit passendem Namen.
- **Paarliste (links): Seitenwechsel und Reiterwechsel rechnen nicht mehr alles neu.** Bisher wurden bei jedem Seitenwechsel alle Kandidaten neu berechnet, sortiert und auf Zwillinge geprüft; nur die Partnerdetails entstanden bereits für die sichtbare Seite. Jetzt liegt das Ergebnis zwischengespeichert vor und eine Seite ist nur ein Ausschnitt.
- Zwei neue Rust-Tests sichern die Zuordnung: Es wird immer eins zu eins gepaart (zwei identische Dateien in A, eine Kopie in B: nur eine gilt als identisch), und bei Duplikaten wird der gleiche relative Pfad bevorzugt.

**Noch nicht gelöst (Plan für v22):** Die Tabelle enthält weiterhin einen Eintrag je B-Datei (3,3 Mio „Nur in B“), das kostet Speicher und jede Filter- oder Auswahländerung durchläuft die Liste. „Nur in B“ sollte erst auf Wunsch aufgebaut und die Zähler sollten mitgeführt werden.

## v20 – Kompakter Arbeitsbereich zum Konsolidieren von Ordnern

**Wichtig:** Dieser Patch ist für einen GitHub-Build vorgesehen. Hier wurden kein Rust-/Slint-Build und keine realen Papierkorbaktionen durchgeführt. Nutze zunächst ausschließlich Testdaten.

- Ein Fenster mit drei gleichzeitig sichtbaren, scrollbareren Bereichen: **Ordnerpaare**, **Unterordner in A**, **Dateien in A/B**. Bei schmalen Fenstern können die Seitenbereiche einzeln ausgeblendet werden. Dateiaktionen sind unten fest angeordnet.
- A ist standardmäßig der **Arbeitsordner**. Die Hauptfilter lauten Alle A, Identisch in B, Fehlt in B und Abweichend. Nur-B-Dateien und alle A+B-Dateien sind weiter über **Mehr** sichtbar; ein A/B-Tausch bleibt möglich.
- Klick auf Unterordnernamen **filtert** die Dateiliste; das Kästchen **wählt alle für Aktionen geeigneten Dateien** dieses Unterordners. Konflikte werden dabei nicht mitselektiert. Die Auswahl bleibt über Filter und nachladbare Dateizeilen erhalten.
- Slint `ListView` virtualisiert die aktuell bereitgestellten Zeilen. Der Rust-Adapter lädt zunächst 240 Zeilen und auf Klick weitere 240. Es werden deshalb keine Millionen Zeilen gleichzeitig in das Slint-Modell kopiert; **v20 hat noch keinen automatischen Infinite-Scroll-Auslöser**.
- Der volle Dateipfad und Prüfnachweis ist nach Hover in einem Slint-Tooltip zugänglich (Slint 1.17). Finder und Quick Look bleiben für selektierte Zeilen vorhanden.
- **Kopieren** und **Papierkorb** sind getrennte, bestätigungspflichtige Aktionen. Die v19-Move-Engine bleibt im Quellcode, ist aber im normalen v20-Workflow **nicht über einen Button erreichbar**. Es werden keine Links automatisch umgeschrieben und keine Ordner automatisch gelöscht.
- Die **Zusatz-Byteprüfung** ist weiterhin freiwillig. Vor Papierkorb kann Schnell (Index), aktueller Hash (Standard) oder Bytevergleich gewählt werden. Für jede betroffene Datei wird die gewählte Prüfung separat ausgeführt.
- `link_preflight` inventarisiert nur noch Symlinks statt jedes regulären Dateieintrags. Die Verzeichnisse `.TemporaryItems` und `.Trashes` werden **ausschließlich unmittelbar im Stamm von `/Volumes/<Volume>/`** für diese Linkprüfung ausgelassen und bleiben unverändert. Andere nicht lesbare Verzeichnisse bleiben eine Sperre; deren mögliche Abhängigkeiten können wir nicht ausschließen. Das ist keine allgemeine Deaktivierung der macOS-Berechtigungen.
- Nach erfolgreichen Krokiet-Aktionen werden die bekannten Änderungen wie in v17 lokal im Index nachgeführt, ohne zwangsläufig den gesamten Datenträger neu zu scannen.

### Persistent gespeicherter Index – derzeitige Grenze

Der bestehende Code speichert seit v17 bereits einen **Cache-Snapshot** für Inventare bis zu **250.000 Dateien** (`MAX_PERSIST_FILES`). Dieser wird beim erneuten Laden stets als **veraltet/unverifiziert** behandelt. Für Archive mit Millionen Dateien – wie auf deinem Screenshot – gibt es **noch keinen vollständigen, pro Volume persistenten und inkrementell revalidierbaren Hash-Index**. Das ist eine separate, größere Datenbank-Änderung und **nicht Bestandteil von v20**. Es wäre falsch, die Snapshot-Funktion als vollwertige Lösung dafür zu bezeichnen.

### Geänderter Bedienablauf

1. Krokiet-Duplikatscan mit Hashes ausführen und **Ordner vergleichen** öffnen.
2. Links ein Paar wählen, in der mittleren Spalte einen Unterordner selektieren oder öffnen.
3. Rechts anhand der Statusfilter die A-Dateien prüfen; optional Konflikte nachprüfen (unter **Mehr**).
4. Dateien oder Unterordner auswählen. **Kopieren** ergänzt B ohne Überschreiben und lässt A bestehen. **Papierkorb** betrifft nur nach gewähltem Modus überprüfte identische Kopien aus A.
5. Das Ergebnis kontrollieren. Unlesbare Archivordner und externe Projekt-Pfadreferenzen sind weiterhin besondere Risiken.

---

## v19.1 – Korrektur des macOS-Kopiervorgangs

- In v19 verursachte `/bin/cp -pE` auf macOS einen **Aufruffehler (Exit-Code 64)**. Das war die Ursache für den fehlgeschlagenen Rust-Test `v19_copy_fallback_keeps_source_until_trash`.
- Der Verschiebe-Fallback verwendet jetzt `/bin/cp -p`. Die Option `-p` berücksichtigt auf macOS bereits Zeitstempel, Berechtigungen, ACLs, erweiterte Attribute und Resource Forks, soweit das Zieldateisystem sie unterstützt.
- Bei erneutem `cp`-Fehler erscheint nun zusätzlich die Ausgabe von `stderr` im Fehlerbericht. Das Original bleibt bei fehlgeschlagenem Kopiervorgang bestehen.

## Historie v19 – Verschieben und Kopieren getrennt (in v20 nicht in der Haupt-UI angeboten)

- Nach Wahl der Übertragungsrichtung stehen **Verschieben bestätigen** und **Nur kopieren** nebeneinander.
- **Verschieben** auf unterstützten Dateisystemen: mit `std::fs::hard_link` zuerst ein ausschließlich neu angelegtes Ziel erzeugen, anschließend Quellpfad entfernen. Bewahrt Inhalt und Dateimetadaten ohne erneutes Kopieren. Quelle liegt anschließend nicht im Papierkorb.
- **Verschieben über Dateisystemgrenzen oder auf Dateisystemen ohne Hardlinks:** Quelle metadatenschonend kopieren (`/bin/cp -p` auf macOS), Inhalt byteweise vergleichen und dann die Quellen in begrenzten `trash::delete_all`-Paketen in den Papierkorb verschieben. Bei Fehlern bleiben Quelldateien erhalten; die Anwendung meldet diesen Fall als **nur kopiert**.
- Bestehende Zieldateien werden niemals überschrieben. Bei Problemen ist ein Teilergebnis möglich, das einzeln im Finder kontrolliert werden sollte.
- Der Inhaltsindex aktualisiert nach erfolgreichen Verschiebungen den Dateipfad, statt ein zusätzliches Duplikat einzutragen. Kein vollständiger Neu-Scan nur wegen der eigenen Aktionen.
- Externe Projektverknüpfungen und jede Art von Metadaten auf inkompatiblen Ziel-Dateisystemen können nicht vollständig abgesichert werden. Für echte Archive zuerst mit Testdateien prüfen. Leere Quellverzeichnisse werden nicht automatisch entfernt.

## Wesentliche Änderungen

### Neu in v18: Merge in beiden Richtungen direkt sichtbar

- Im A/B-Vergleich stehen oberhalb der Dateiliste **A → B** und **B → A** mit der Anzahl der jeweils fehlenden Dateien. Eine Richtung wählen markiert automatisch nur die entsprechenden fehlenden Dateien; das Kopieren erfordert eine zweite ausdrückliche Bestätigung.
- Auch eine manuell zusammengestellte Auswahl kann über beide Richtungen kopiert werden. Die Auswahl kann über mehrere Seiten bestehen bleiben.
- V18 kann die fehlenden Dateien **direkt aus B nach A** kopieren; ein vorheriges A/B-Tauschen ist nicht mehr nötig.
- Es werden weder vorhandene Zieldateien überschrieben noch Dateien aus der Quelle entfernt. Nach dem Kopieren wird byteweise verifiziert und der bekannte Ordnerindex aktualisiert, ohne einen vollständigen Festplattenscan zu erzwingen.
- Bei vollständig gleichen Dateiinhalten ist ein Merge nicht erforderlich. Bestehen nur ungeklärte Pfadkonflikte, müssen diese separat untersucht werden; ein automatisches Überschreiben findet nicht statt.
- Hinweis: Die Anzeige beruht anfänglich auf dem **älteren Scan-Index**. Vor dem Kopieren kontrolliert `copy_missing` die Quelle und den Zielpfad; eine erfolgreiche Kopie wird direkt byteweise verifiziert. Metadaten wie Finder-Tags oder Resource Forks werden nicht vollständig übernommen.


### Neu in v17: Nach Lösch- und Kopieraktionen ohne vollständigen Neu-Scan weiterarbeiten

- Das bisherige globale `INDEX_DIRTY` nach **jeder** Dateiaktion war unnötig: Es blendete alle Ordnerbeziehungen aus. Jetzt wird nach nachweislich erfolgreichen Änderungen nur das **im Speicher vorhandene Inventar** korrigiert.
- In den Papierkorb verschobene Dateien werden aus dem Index entfernt. Erfolgreich und byteweise überprüfte Kopien werden ergänzt. Die Gruppenzähler und Ordnerbeziehungen werden aus diesen **gespeicherten Dateieinträgen** neu berechnet – ohne den Datenträger erneut zu durchsuchen oder unberührte Dateien zu hashen.
- Der aktuelle Ordnerfilter, die Sortierung und Seite werden nach Möglichkeit erhalten. Weil sich Zeilenpositionen ändern können, wird die alte Zeilenauswahl zurückgesetzt; die aktualisierte Trefferliste bleibt sichtbar.
- Für ältere unveränderte Dateien ist dies weiterhin der **Stand des letzten Scans**, keine Echtzeitüberwachung der Festplatte. Der Schnellmodus beim Papierkorb bleibt eine bewusste Vertrauensentscheidung.
- Kann eine Kopie nicht mit dem Inventar abgeglichen werden (beispielsweise Quelle außerhalb des ursprünglich gescannten Bereichs), wird der alte Index **ausdrücklich als unverifiziert** angezeigt statt fälschlich sichere Treffer zu melden.
- Der neue Index wird für den nächsten Start als **Cache-Snapshot** gespeichert, der nach Neustart weiterhin als unverifiziert gekennzeichnet wird. Bei sehr großen Inventaren entfällt das Caching, nicht die Aktualisierung im Arbeitsspeicher.


- Symmetrisch identische Zwillingsordner werden in der Trefferliste zu einem repräsentativen Treffer zusammengefasst. Bei mehr als zwei identischen Ordnern wird weiterhin die Gruppengröße angezeigt.
- Bei einem konkreten A/B-Paar steht die **Dateiabdeckung in beide Richtungen**: „A in B“ und „B in A“ mit Dateizahlen. Diese Zahl ist nicht die globale Abdeckung über verstreute Archive.
- In der Vergleichstabelle gibt es eine zusätzliche Aktion **Konflikte prüfen**. Sie vergleicht alle bislang unklaren Pfadpaare A/B frisch byteweise. Danach steht „Identisch“ oder „Verschieden“; „Ungeprüft“ ist bewusst keine Behauptung unterschiedlicher Inhalte.
- „A/B tauschen“ wechselt über die vorhandenen Indexdaten die Richtung des Paares. Die Aktion „Kopieren nach B“ kann so für beide Richtungen verwendet werden. Sind eigene, nicht indexierte Pfade ausgewählt, ist gegebenenfalls „Neu prüfen“ nötig.
- **Keine starre Grenze von 200 Dateien** bei ausdrücklichen Mehrfachaktionen. Dateien werden vor dem Papierkorb einzeln geprüft, danach mit **begrenzten `trash::delete_all`-Paketen** an das Betriebssystem übergeben. Zwischen Paketen ist ein Abbruch möglich; ein Fehler kann eine teilweise Ausführung bedeuten. Die Ergebnisse werden anhand der verbleibenden Originalpfade abgeglichen.
- Das Kopieren verwendet weiterhin `create_new(true)` und überschreibt keine Dateien. Kopien werden byteweise überprüft.
- Der beim Papierkorb verwendete Prüfmodus wird ausdrücklich in der Bestätigung gewählt. Kein neuer Vollscan der Platte; der aktuelle Hashmodus liest nur die ausgewählten A/B-Dateien.
- **Schnell kann Datenverlust ermöglichen:** Größe und Änderungszeit sind kein Beweis für unveränderte Inhalte, auch nicht bei gleichzeitiger Aktualisierung der Uhrzeiten. Wähle bei wichtigen Daten „Aktueller Hash“ oder „Bytevergleich“.

## Bedienung der Versionen v17–v19 (historisch; v20 siehe oben)

1. **Einmal** den regulären Duplikatscan mit Hash-Prüfung starten und **Ordner vergleichen** öffnen.
2. Links ein Ordnerpaar auswählen. Rechts erscheint die **unverifizierte Index-Vorschau**, ohne erneuten gesamten Datenträger-Scan.
3. Für problematische Fälle **Konflikte prüfen** wählen, um gleichnamige Dateien aktuell byteweise nachzuprüfen. Über **Neu prüfen** ist weiterhin ein vollständiger Audit möglich.
4. Oberhalb der Dateiliste steht **Merge A → B / B → A** mit der Zahl fehlender Dateien. Richtung wählen, Auswahl in der Vorschau kontrollieren und Kopieren ausdrücklich bestätigen. Die manuelle Auswahl unter „Nur A“ oder „Nur B“ bleibt möglich.
5. Für identische Dateipaare ist „Optional: Byteprüfung“ weiterhin eine zusätzliche Vorabprüfung. Vor der Papierkorb-Bestätigung einen von drei Modi wählen: **Schnell (Index)** prüft nur Scan-Nachweis, Größe und Änderungszeit (kein neues Lesen der Inhalte, höheres Risiko); **Aktueller Hash** berechnet BLAKE3 für A und B neu (**Voreinstellung**); **Bytevergleich** vergleicht alle Bytes direkt. Ohne qualifizierten Scan-Nachweis wird Schnell für betroffene Dateien gesperrt, nicht still auf einen anderen Modus gewechselt.
6. Nach Merge/Papierkorb wird die Ordnerliste ohne erneuten Scan aktualisiert. Die A/B-Tabelle wird zeilenweise fortgeschrieben; bei externen Änderungen oder unklaren Scan-Daten kann ein erneuter Scan nötig sein.
7. Bei Dateien in externen Projekten, Ressourcen-Forks und Dateien mit AppleDouble-`._`-Metadaten manuell kontrollieren. Die Anwendung kennt keine externen Projektverweise.

## Datenschutz und Sicherheitsgrenzen

- Kein automatisches Entfernen ganzer Ordner, keine permanente Löschung.
- Dateifilter können Inhalte verdecken. Für Archiventscheidungen Filter deaktivieren und den gesamten A/B-Bestand ansehen.
- Die Papierkorb-API verwendet auf macOS bei großen Mengen mehrere begrenzte Systemaufrufe. **Ob macOS tatsächlich nur eine Freigabe abfragt, kann nicht garantiert werden**: Zugriffsrechte, TCC und externe Volumes können weitere Dialoge auslösen. Niemals Rechte pauschal auf allen Dateien ändern, um Dialoge zu umgehen.
- Auch ein erfolgreiches `cargo test` ist keine Zertifizierung gegen alle Datenverlustfälle. Erst auf Testordnern und mit wiederherstellbaren Kopien prüfen.

## GitHub-Build

ZIP ins Repo-Hauptverzeichnis hochladen: `krokiet_folder_compare_patch_12.0.2_v22-3.zip`.
Workflow: `.github/workflows/build-krokiet-v22-3.yml` mit der beigefügten YAML erstellen.

Der Workflow klont Krokiet 12.0.2, wendet `apply_patch.py` an (einschließlich einer **direkten, auf die vorhandene Cargo.lock-Version festgelegten `trash`- und `blake3`-Abhängigkeiten**), führt die Tests mit `--locked` aus und erstellt das ad-hoc signierte ARM64-App-Bundle.

**Vor dem Build:** Der Patch wurde hier statisch geprüft und mit Python-Tests getestet. Rust-/Slint- und macOS-Dateisystem-Tests müssen in GitHub Actions bzw. auf dem Mac erfolgen.
