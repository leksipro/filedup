//! Interactive, manually operated side-by-side audit table.
//! Global folder relationships only suggest pairs; a separate fresh audit builds this table.
//! Filesystem mutations require explicit confirmation; copies never overwrite.
//! Native per-file trash after user-selected checking; no folder deletion.
use super::*;
use std::fs::{File, OpenOptions};
use std::io::{self, Read, Write};
#[cfg(unix)] use std::os::unix::fs::MetadataExt;
use std::process::{Command, Stdio};
use slint::{Model, ModelRc, SharedString, VecModel, Weak};
use std::cell::{Cell, RefCell};


const PAGE: usize = 120;
const INITIAL_VISIBLE: usize = PAGE;
// No arbitrary selection cap: all selected entries are processed with progress and cancellation.
// A batch operation requires an explicit confirmation showing the selected count.
static BATCH_STOP: AtomicBool = AtomicBool::new(false);
static ERROR_DECISION: std::sync::atomic::AtomicU8 = std::sync::atomic::AtomicU8::new(0);

// A separate report per confirmed operation, written incrementally. Paths use Debug
// formatting so control characters (e.g. Icon\r) do not corrupt report lines.
fn new_operation_report() -> io::Result<(PathBuf, File)> {
    let home = std::env::var_os("HOME").ok_or_else(|| io::Error::new(io::ErrorKind::NotFound, "HOME fehlt"))?;
    let dir = PathBuf::from(home).join("Library/Logs/Krokiet Folder Compare");
    fs::create_dir_all(&dir)?;
    let now = SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap_or_default().as_nanos();
    let path = dir.join(format!("operation-{now}-{}.txt", std::process::id()));
    let mut opts = OpenOptions::new();
    opts.write(true).create_new(true);
    #[cfg(unix)] { use std::os::unix::fs::OpenOptionsExt; opts.mode(0o600); }
    let file = opts.open(&path)?;
    Ok((path, file))
}
fn report_line(file: &mut File, text: &str) -> io::Result<()> {
    writeln!(file, "{text}")?;
    file.flush()
}
fn io_detail(e: io::Error) -> String {
    format!("{e} [kind={:?}, errno={:?}]", e.kind(), e.raw_os_error())
}
fn failure_diagnostics(path: &Path) -> String {
    #[cfg(target_os = "macos")]
    {
        let mut text = String::new();
        for item in std::iter::once(path).chain(path.parent()) {
            match Command::new("/bin/ls").arg("-ldeOn@").arg(item).output() {
                Ok(o) => text.push_str(&format!("\nMetadaten {:?}, exit {}:\n{}{}", item, o.status,
                    String::from_utf8_lossy(&o.stdout), String::from_utf8_lossy(&o.stderr))),
                Err(e) => text.push_str(&format!("\nMetadaten {:?}: {}", item, io_detail(e))),
            }
        }
        text
    }
    #[cfg(not(target_os = "macos"))]
    { format!("Metadaten {:?}: {:?}", path, fs::symlink_metadata(path)) }
}
// No privilege escalation here. Only the user can decide to skip or abort.
fn await_error_decision(weak: &Weak<MainWindow>, message: String, can_retry_finder: bool) -> u8 {
    await_operation_decision(weak,message,can_retry_finder,false)
}
fn await_operation_decision(weak: &Weak<MainWindow>, message: String, can_retry_finder: bool, confirm_acl: bool) -> u8 {
    crate::folder_diagnostics::event("OPERATION pause requested");
    ERROR_DECISION.store(0, Ordering::SeqCst);
    if weak.upgrade_in_event_loop(move |app| {
        app.set_folder_operation_finder_retry(can_retry_finder);
        app.set_folder_operation_confirm_acl(confirm_acl);
        app.set_folder_operation_pause(message.into());
        crate::folder_diagnostics::event("GUI error state shown");
    }).is_err() { BATCH_STOP.store(true, Ordering::Relaxed); return 3; }
    let decision = loop {
        if BATCH_STOP.load(Ordering::Relaxed) { break 3; }
        let d = ERROR_DECISION.load(Ordering::SeqCst);
        if d != 0 { break d; }
        thread::sleep(std::time::Duration::from_millis(80));
    };
    let _ = weak.upgrade_in_event_loop(|app| { app.set_folder_operation_pause("".into()); app.set_folder_operation_finder_retry(false); app.set_folder_operation_confirm_acl(false); });
    crate::folder_diagnostics::event(&format!("OPERATION pause decision {decision}"));
    if decision == 3 { BATCH_STOP.store(true, Ordering::Relaxed); }
    decision
}
struct ErrorPolicy { skip_all: bool, streak: usize, streak_warned: bool }
impl ErrorPolicy {
    fn new() -> Self { Self { skip_all: false, streak: 0, streak_warned: false } }
    fn success(&mut self) { self.streak = 0; self.streak_warned = false; }
    fn failed(&mut self, weak: &Weak<MainWindow>, report: &mut File, path: &Path, reason: &str, remaining: usize) -> bool {
        self.decide(weak,report,path,reason,remaining,false) != 3
    }
    fn decide(&mut self, weak: &Weak<MainWindow>, report: &mut File, path: &Path, reason: &str, remaining: usize, can_retry_finder: bool) -> u8 {
        let line = format!("FEHLER {:?}: {}{}", path, reason, failure_diagnostics(path));
        if report_line(report, &line).is_err() {
            BATCH_STOP.store(true, Ordering::Relaxed);
            ui_message(weak, "Fehlerbericht nicht mehr beschreibbar; Auftrag gestoppt.".into());
            return 3;
        }
        self.streak += 1;
        if BATCH_STOP.load(Ordering::Relaxed) { return 3; }
        if remaining == 0 && !can_retry_finder { return 1; }
        let systemic = self.streak >= 5 && !self.streak_warned;
        if !self.skip_all || systemic {
            self.streak_warned |= systemic;
            let msg = format!("{}Datei nicht verarbeitet: {:?}\n{}\nNoch {remaining} Dateien. Übrige versuchen?", if systemic { "Mehrere Fehler in Folge – allgemeines Rechte-/Volumeproblem möglich.\n" } else { "" }, path, reason);
            let decision = await_error_decision(weak, msg, can_retry_finder);
            match decision {
                1 | 4 => self.skip_all = false,
                2 => self.skip_all = true,
                _ => return 3,
            }
            return decision;
        }
        1
    }
}


// v22.3: ACL permissions and content verification are independent. The
// elevated phase only removes explicit everyone deny bits, never data.
#[cfg(any(target_os = "macos", test))]
fn acl_text_has_deny(text: &str, permission: &str) -> bool {
    text.lines().skip(1).any(|line| {
        let mut parts = line.split_whitespace();
        let index = parts.next().unwrap_or("");
        let principal = parts.next().unwrap_or("");
        index.ends_with(':') && index.trim_end_matches(':').parse::<usize>().is_ok()
            && (principal == "group:everyone" || principal.eq_ignore_ascii_case("ABCDEFAB-CDEF-ABCD-EFAB-CDEF0000000C"))
            && parts.next() == Some("deny")
            && parts.next().is_some_and(|rights| rights.split(',').any(|right| right == permission))
    })
}

#[cfg(target_os = "macos")]
fn backup_acl_has_deny(path: &Path, permission: &str) -> Result<bool, String> {
    let Some(s) = path.to_str() else { return Err("ACL: Nicht-UTF-8-Pfad".into()); };
    if s.contains('\n') { return Err("ACL: Zeilenumbruch im Pfad; manuell prüfen".into()); }
    // Escape control characters (including Icon\r) in ls output; the actual
    // path is passed unchanged, not parsed from the display text.
    let out = Command::new("/bin/ls").env("LC_ALL", "C").arg("-blde").arg(path).output().map_err(io_detail)?;
    if !out.status.success() { return Err(String::from_utf8_lossy(&out.stderr).into_owned()); }
    Ok(acl_text_has_deny(&String::from_utf8_lossy(&out.stdout), permission))
}

// No archive-name or xattr requirement. Limit elevated changes to selected
// data trees on mounted volumes or ordinary folders in the console user's home.
// Never change the volume/home root or operating-system/active backup paths.
#[cfg(any(target_os = "macos", test))]
fn acl_boundary(path: &Path, console_user: Option<&str>) -> Result<PathBuf, String> {
    let (base, home) = if let Ok(rel) = path.strip_prefix("/Volumes") {
        let volume = rel.components().next().ok_or("ACL: Volume fehlt")?;
        if !matches!(volume, Component::Normal(_)) || volume.as_os_str().to_string_lossy().starts_with('.') { return Err("ACL: ungültiges/geschütztes Volume".into()); }
        (Path::new("/Volumes").join(volume.as_os_str()), false)
    } else if let Some(user) = console_user.filter(|u| !u.is_empty() && *u != "root" && *u != "loginwindow" && !u.contains('/')) {
        (Path::new("/Users").join(user), true)
    } else { return Err("ACL: nur Datenträger und eigene Datenordner".into()); };
    let rel = path.strip_prefix(&base).map_err(|_| "ACL: außerhalb eigener Datenordner")?;
    for (i,c) in rel.components().enumerate() {
        let Component::Normal(name) = c else { return Err("ACL: nichtnormaler Pfad".into()); };
        let name = name.to_string_lossy().to_ascii_lowercase();
        if matches!(name.as_str(), "backups.backupdb" | ".trashes" | ".trash" | ".temporaryitems" | ".spotlight-v100" | ".fseventsd" | ".timemachine")
            || (home && i == 0 && (name == "library" || name.starts_with('.'))) {
            return Err("ACL: geschützter System-/Backup-/Papierkorbbereich".into());
        }
    }
    Ok(base)
}

#[cfg(target_os = "macos")]
fn backup_acl_scope(a: &Path) -> Result<(fs::Metadata, PathBuf, Option<String>), String> {
    let console = Command::new("/usr/bin/stat").args(["-f", "%Su", "/dev/console"]).output().ok()
        .filter(|o| o.status.success()).and_then(|o| String::from_utf8(o.stdout).ok()).map(|s| s.trim().to_owned());
    let boundary = acl_boundary(a, console.as_deref())?;
    if a.canonicalize().map_err(io_detail)?.as_path() != a { return Err("ACL-Modus: nichtkanonischer Quellordner".into()); }
    let meta = fs::symlink_metadata(a).map_err(io_detail)?;
    if !meta.is_dir() { return Err("ACL-Modus: kein Verzeichnis".into()); }
    Ok((meta, boundary, console))
}

#[cfg(target_os = "macos")]
fn prepare_backup_acl_batch(weak: &Weak<MainWindow>, report: &mut File, report_path: &Path,
    a: &Path, b: &Path, batch: &[(usize, Entry)], links: &LinkPreflight, mode: TrashCheckMode,
    excluded: &mut BTreeSet<usize>, move_source: bool, from_b: bool) -> Result<(), String> {
    let (scope, boundary, console) = backup_acl_scope(a)?;
    let mut files = BTreeMap::<PathBuf, (u64, u64)>::new();
    let mut parents = BTreeMap::<PathBuf, (u64, u64)>::new();
    let mut parent_cache = BTreeMap::<PathBuf, Result<bool, String>>::new();
    for (number, (index, entry)) in batch.iter().enumerate() {
        if BATCH_STOP.load(Ordering::Relaxed) { return Err("Abgebrochen vor ACL-Änderung".into()); }
        if number % 50 == 0 { ui_message(weak, format!("Backup-ACL prüfen: {} / {}",number+1,batch.len())); }
        let left = (if from_b { entry.b.as_deref() } else { entry.a.as_deref() }).ok_or("ACL: Quelle fehlt")?;
        let right = if from_b { entry.a.as_deref() } else { entry.b.as_deref() };
        let result = (|| -> Result<(), String> {
            let parent = left.parent().ok_or("ACL: Elternordner fehlt")?;
            // Inspect only paths that already passed the ordinary read-only screening.
            if acl_boundary(left, console.as_deref())? != boundary { return Err("ACL: außerhalb des Datenbereichs".into()); }
            let file_deny = backup_acl_has_deny(left, "delete")?;
            let parent_deny = parent_cache.entry(parent.to_path_buf()).or_insert_with(|| backup_acl_has_deny(parent,"delete_child")).clone()?;
            if !file_deny && !parent_deny { return Ok(()); }
            if parent_deny && parent == boundary.as_path() { return Err("ACL: Volume-/Home-Wurzel wird nicht verändert".into()); }
            let lm = checked_regular(left,a)?;
            if file_deny && lm.nlink() != 1 { return Err("ACL-Schutz an mehrfach hartverlinkter Datei bleibt unverändert".into()); }
            if lm.dev() != scope.dev() { return Err("ACL: anderes Volume".into()); }
            let pm = fs::symlink_metadata(parent).map_err(io_detail)?;
            if !pm.is_dir() || pm.dev() != scope.dev() || parent.canonicalize().map_err(io_detail)?.as_path() != parent { return Err("ACL: Elternordner unsicher".into()); }
            links.check_path(left)?;
            if move_source {
                // No counterpart exists yet. The real move must still verify the newly
                // created copy before removing the source; ACL changes alone never delete.
                File::open(left).map_err(io_detail)?;
                preview_destination(b, left.strip_prefix(a).map_err(|e| e.to_string())?)?;
            } else {
                let right = right.ok_or("ACL: Gegenstück fehlt")?;
                preflight_trash_pair_with_mode(a,b,left,right,mode,entry.fast_proof)?;
            }
            let now = checked_regular(left,a)?;
            if !same_inode(&lm,&now) || source_stamp(&lm) != source_stamp(&now) { return Err("ACL: Datei verändert".into()); }
            if file_deny { files.insert(left.to_path_buf(), (lm.dev(), lm.ino())); }
            if parent_deny { parents.insert(parent.to_path_buf(), (pm.dev(), pm.ino())); }
            Ok(())
        })();
        if let Err(e) = result {
            excluded.insert(*index);
            report_line(report,&format!("ACL VORAB AUSGESCHLOSSEN {:?}: {e}",left)).map_err(io_detail)?;
        }
    }
    if files.is_empty() && parents.is_empty() {
        report_line(report,"ACL: keine passenden Backup-Löschverbote zur Korrektur gefunden").map_err(io_detail)?;
        return Ok(());
    }
    let next_step = if move_source { "folgenden Verschiebeversuch mit verifizierter Übertragung" } else { "folgenden Papierkorbversuch" };
    let check_label = if move_source { "Zielkopie vor Quellenentfernung verifizieren" } else { mode.label() };
    let message = format!("ACL-Löschschutz DAUERHAFT aufheben? {} Datei-ACLs, {} Elternordner, {} Dateien ausgeschlossen. Prüfung: {check_label}. Nur everyone deny delete bzw. delete_child wird entfernt. Ordneränderung betrifft auch unmittelbare, nicht ausgewählte Kinder. Keine Wiederherstellung. 'ACL ändern + fortfahren' bestätigt die ACL-Änderung und den {next_step}. Nicht auf aktiven Backups verwenden.",files.len(),parents.len(),excluded.len());
    if await_operation_decision(weak,message,false,true) != 1 || BATCH_STOP.load(Ordering::Relaxed) { return Err("ACL-Änderung abgebrochen".into()); }
    let manifest_path = report_path.with_extension("acl-manifest");
    let mut opts = OpenOptions::new();
    use std::os::unix::fs::OpenOptionsExt;
    opts.write(true).create_new(true).mode(0o600);
    let mut manifest = opts.open(&manifest_path).map_err(io_detail)?;
    // The administrator receives only inert NUL-delimited data and fixed code,
    // not a writable executable/script from the archive. No passwords captured.
    let manifest_result = (|| -> Result<(),String> {
        for (kind, items) in [("file", &files), ("parent", &parents)] {
            for (path,(dev,ino)) in items {
                let p = path.to_str().ok_or("ACL: ungültiger Pfad")?;
                write!(manifest,"{kind}\0{dev}:{ino}\0{p}\0").map_err(io_detail)?;
                report_line(report,&format!("ACL GEPLANT {kind} {:?} {dev}:{ino}",path)).map_err(io_detail)?;
            }
        }
        manifest.sync_all().map_err(io_detail)
    })();
    drop(manifest);
    if let Err(e)=manifest_result { let _=fs::remove_file(&manifest_path); return Err(e); }
    if BATCH_STOP.load(Ordering::Relaxed) { let _=fs::remove_file(&manifest_path); return Err("Abgebrochen vor Autorisierung".into()); }
    ui_message(weak,"Administratorfreigabe für ACL-Sammelauftrag (keine Löschung als root) ...".into());
    let apple_script = r#"on run argv
        set cmd to "/usr/bin/env -i /bin/bash --noprofile --norc -c " & quoted form of (item 1 of argv) & " krokiet-acl " & quoted form of (item 2 of argv) & " " & quoted form of (item 3 of argv) & " " & quoted form of (item 4 of argv)
        with timeout of 7200 seconds
            return do shell script cmd with administrator privileges without altering line endings
        end timeout
    end run"#;
    let result = Command::new("/usr/bin/osascript").arg("-e").arg(apple_script)
        .arg(include_str!("macos_backup_acl.sh")).arg(&manifest_path).arg(a)
        .arg(format!("{}:{}",scope.dev(),scope.ino())).output();
    let _ = fs::remove_file(&manifest_path);
    let complete = match result {
        Ok(out) => {
            report_line(report,&format!("ACL ADMIN ERGEBNIS {}\n{}\n{}",out.status,String::from_utf8_lossy(&out.stdout),String::from_utf8_lossy(&out.stderr))).map_err(io_detail)?;
            out.status.success() && String::from_utf8_lossy(&out.stdout).lines().last().is_some_and(|line| line.trim() == "ACL_RESULT=0")
        }
        Err(e) => { report_line(report,&format!("ACL ADMIN STARTFEHLER: {}",io_detail(e))).map_err(io_detail)?; false }
    };
    if !complete {
        // A cancelled/partly failed admin batch must not re-try every protected
        // file blindly. Inspect only the paths which actually needed changes.
        let mut unresolved_parents = BTreeSet::new();
        for parent in parents.keys() {
            if !matches!(backup_acl_has_deny(parent,"delete_child"), Ok(false)) { unresolved_parents.insert(parent.clone()); }
        }
        for (index, entry) in batch {
            if excluded.contains(index) { continue; }
            let Some(left) = (if from_b { entry.b.as_deref() } else { entry.a.as_deref() }) else { continue; };
            if (files.contains_key(left) && !matches!(backup_acl_has_deny(left,"delete"),Ok(false)))
                || left.parent().is_some_and(|parent| unresolved_parents.contains(parent)) {
                excluded.insert(*index);
                report_line(report,&format!("ACL WEITERHIN GESCHÜTZT / NICHT PRÜFBAR {:?}",left)).map_err(io_detail)?;
            }
        }
        return Err("ACL-Aufhebung unvollständig oder abgebrochen; weiterhin geschützte Dateien ausgeschlossen. Bereits geänderte Rechte bleiben bestehen. Siehe Bericht.".into());
    }
    Ok(())
}

#[cfg(not(target_os = "macos"))]
fn prepare_backup_acl_batch(_weak: &Weak<MainWindow>, _report: &mut File, _report_path: &Path,
    _a: &Path, _b: &Path, _batch: &[(usize, Entry)], _links: &LinkPreflight, _mode: TrashCheckMode,
    _excluded: &mut BTreeSet<usize>, _move_source: bool, _from_b: bool) -> Result<(), String> {
    Err("Backup-ACL-Modus nur unter macOS".into())
}

// Native macOS trash: no Finder AppleScript or command-line path batches.
// A failed item never prevents trying the next item. No automatic permanent fallback.
fn native_trash(path: &Path) -> Result<(), String> {
    #[cfg(target_os = "macos")]
    {
        use trash::macos::{DeleteMethod, TrashContextExtMacos as _};
        if path.to_str().is_none() { return Err("Nicht-UTF-8-Pfad: nativer Papierkorb nicht sicher verfügbar".into()); }
        if let Ok(exe) = std::env::current_exe() {
            if let Some(dir) = exe.parent() {
                let helper = dir.join("krokiet-trash-diagnostics");
                if helper.is_file() {
                    let out = Command::new(helper).arg(path).output().map_err(io_detail)?;
                    if out.status.success() { return Ok(()); }
                    return Err(format!("NSFileManager trash ({}): {}{}", out.status,
                        String::from_utf8_lossy(&out.stderr), String::from_utf8_lossy(&out.stdout)));
                }
            }
        }
        let mut context = trash::TrashContext::default();
        context.set_delete_method(DeleteMethod::NsFileManager);
        context.delete(path).map_err(|e| e.to_string())
    }
    #[cfg(not(target_os = "macos"))]
    { trash::delete(path).map_err(|e| e.to_string()) }
}

fn remove_verified_source(path: &Path, permanent: bool, finder_retry: bool) -> Result<(), String> {
    if permanent { fs::remove_file(path).map_err(io_detail)?; }
    else if finder_retry {
        if path.to_str().is_none() { return Err("Nicht-UTF-8-Pfad: Finder-Wiederholung nicht sicher verfügbar".into()); }
        trash::delete(path).map_err(|e| e.to_string())?;
    }
    else { native_trash(path)?; }
    match fs::symlink_metadata(path) {
        Err(e) if e.kind() == io::ErrorKind::NotFound => Ok(()),
        Err(e) => Err(format!("Quellstatus nicht überprüfbar: {e}")),
        Ok(_) => Err("Quellpfad ist weiterhin vorhanden".into()),
    }
}

pub(super) fn cancel_batch() { BATCH_STOP.store(true, Ordering::Relaxed); }
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Kind { Same, OnlyA, OnlyB, Conflict }
#[derive(Clone, Debug)]
struct Entry { a: Option<PathBuf>, b: Option<PathBuf>, kind: Kind, checked_conflict: bool, fast_proof: Option<FastProof> }

/// A fast check is knowingly weaker: it trusts a prior successful content match
/// only while size and modification time still match the saved scan evidence.
#[derive(Clone, Copy, Debug)]
struct FastProof { size_a: u64, size_b: u64, modified_a: u64, modified_b: u64 }

impl FastProof {
    fn from_audit(a: &Stamp, b: &Stamp) -> Option<Self> {
        Some(Self { size_a: a.bytes, size_b: b.bytes,
            modified_a: unix_seconds(a.modified?)?, modified_b: unix_seconds(b.modified?)? })
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum TrashCheckMode { Fast, FreshHash, Bytes }
impl TrashCheckMode {
    fn parse(s: &str) -> Option<Self> {
        match s { "fast" => Some(Self::Fast), "hash" => Some(Self::FreshHash), "bytes" => Some(Self::Bytes), _ => None }
    }
    fn label(self) -> &'static str { match self { Self::Fast => "Schnell (Index)", Self::FreshHash => "Aktueller BLAKE3", Self::Bytes => "Bytevergleich" } }
}

// Separate operation and verification, with legacy bare commands retaining bytes.
fn removal_check_mode(action: &str) -> Option<TrashCheckMode> {
    if let Some((_, suffix)) = action.split_once(':') { return TrashCheckMode::parse(suffix); }
    match action {
        "force_delete_selected" | "finder_retry_selected" | "backup_acl_trash_selected" => Some(TrashCheckMode::Bytes),
        _ => None,
    }
}

fn unix_seconds(date: SystemTime) -> Option<u64> { date.duration_since(std::time::UNIX_EPOCH).ok().map(|d| d.as_secs()) }

struct Session {
    a: PathBuf, b: PathBuf, patterns: Vec<String>, entries: Vec<Entry>,
    page: usize, filter: String, selected: BTreeSet<usize>, from_index: bool,
    scope: String, display_limit: usize,
    groups: BTreeMap<String, [usize; 4]>, groups_dirty: bool,
    visible_cache: RefCell<Option<(String, String, Arc<Vec<usize>>)>>,
    counts_cache: Cell<Option<[i32; 6]>>,
    group_page: usize,
}
static SESSION: Mutex<Option<Session>> = Mutex::new(None);

fn model(rows: Vec<Vec<String>>) -> ModelRc<ModelRc<SharedString>> {
    ModelRc::new(VecModel::from(rows.into_iter().map(|row| {
        ModelRc::new(VecModel::from(row.into_iter().map(SharedString::from).collect::<Vec<_>>()))
    }).collect::<Vec<_>>()))
}

fn row_text(entry: &Entry, a: &Path, b: &Path) -> Vec<String> {
    let left = entry.a.as_deref().map(|p| rel(p, a)).unwrap_or_else(|| "—".into());
    let right = entry.b.as_deref().map(|p| rel(p, b)).unwrap_or_else(|| "—".into());
    let (label, code) = match entry.kind {
        Kind::Same => ("Identisch", "same"),
        Kind::OnlyA => ("Nur in A", "only_a"),
        Kind::OnlyB => ("Nur in B", "only_b"),
        Kind::Conflict => (if entry.checked_conflict { "Verschieden" } else { "Ungeprüft" }, "conflict"),
    };
    let evidence = match entry.kind {
        Kind::Conflict if entry.checked_conflict => "Byteweise geprüft: Datei-Inhalte unterscheiden sich.",
        Kind::Conflict => "Gleicher relativer Pfad; Inhalt noch nicht aktuell byteweise geprüft.",
        Kind::Same => "Identisch laut Vergleich/Index. Vor Papierkorb: Prüfmodus wählen (Schnell / Aktueller Hash / Bytevergleich).",
        Kind::OnlyA => "In B wurde keine identische Dateikopie zugeordnet.",
        Kind::OnlyB => "In A wurde keine identische Dateikopie zugeordnet.",
    };
    vec![left, right, code.into(), label.into(), "0".into(), evidence.into()]
}

/// Seitenzeilen als reine Strings: darf in Hintergrundthreads gebaut werden (ModelRc ist nicht Send).
/// First-level group of an A-side relative file. A top-level file has its own group.
/// The comparison remains an A-centred workflow by default; B-only is opt-in.
fn folder_group(path: &Path, root: &Path) -> String {
    let Ok(relative) = path.strip_prefix(root) else { return "".into() };
    let mut components = relative.components();
    let first = components.next();
    if components.next().is_none() { return "<ROOT>".into(); }
    first.map(|c| c.as_os_str().to_string_lossy().to_string()).unwrap_or_default()
}

fn scope_contains(session: &Session, entry: &Entry) -> bool {
    if session.scope.is_empty() { return true; }
    entry.a.as_deref().is_some_and(|a| folder_group(a, &session.a) == session.scope)
}

fn same_relative_path(session: &Session, entry: &Entry) -> bool {
    match (entry.a.as_deref().and_then(|p| p.strip_prefix(&session.a).ok()),
        entry.b.as_deref().and_then(|p| p.strip_prefix(&session.b).ok())) {
        (Some(a),Some(b)) => a == b,
        _ => false,
    }
}
fn visible_indices(session: &Session) -> Arc<Vec<usize>> {
    if let Some((filter, scope, indices)) = session.visible_cache.borrow().as_ref() {
        if filter == &session.filter && scope == &session.scope { return Arc::clone(indices); }
    }
    let indices = Arc::new(session.entries.iter().enumerate().filter(|(_, e)| {
        if !scope_contains(session, e) { return false; }
        match session.filter.as_str() {
            "same" => e.kind == Kind::Same,
            "same_path" => e.kind == Kind::Same && same_relative_path(session,e),
            "only_a" => e.kind == Kind::OnlyA,
            "only_b" => e.kind == Kind::OnlyB,
            "conflict" => e.kind == Kind::Conflict,
            "different" => e.kind != Kind::Same,
            "all_pairs" => true,
            // Normal working view is A-centred; B-only is visible via More.
            _ => e.kind != Kind::OnlyB,
        }
    }).map(|(i, _)| i).collect::<Vec<_>>());
    *session.visible_cache.borrow_mut() = Some((session.filter.clone(), session.scope.clone(), Arc::clone(&indices)));
    indices
}

/// Precompute first-level group counts once per index load or batch mutation.
/// Toggling selections must NOT iterate millions of source records again.
fn build_group_counts(entries: &[Entry], a: &Path) -> BTreeMap<String, [usize; 4]> {
    let mut groups = BTreeMap::new();
    for entry in entries {
        let Some(path) = entry.a.as_deref() else { continue; };
        let values = groups.entry(folder_group(path, a)).or_insert([0; 4]);
        values[0] += 1;
        match entry.kind {
            Kind::Same => values[1] += 1,
            Kind::OnlyA => values[2] += 1,
            Kind::Conflict => values[3] += 1,
            Kind::OnlyB => {},
        }
    }
    groups
}

/// [group-key, display-name, A-files, identical, only-A, conflict, selected].
fn subfolder_rows(session: &Session) -> Vec<Vec<String>> {
    let mut selected_by_group: BTreeMap<String, usize> = BTreeMap::new();
    for i in &session.selected {
        if let Some(path) = session.entries.get(*i).and_then(|e| e.a.as_deref()) {
            *selected_by_group.entry(folder_group(path, &session.a)).or_default() += 1;
        }
    }
    let (start, end) = group_page_bounds(session);
    session.groups.iter().skip(start).take(end-start).map(|(key, c)| {
        let label = if key == "<ROOT>" { "Dateien im Stamm".to_owned() } else { key.clone() };
        vec![key.clone(), label, c[0].to_string(), c[1].to_string(),
            c[2].to_string(), c[3].to_string(), selected_by_group.get(key).copied().unwrap_or(0).to_string()]
    }).collect()
}

fn group_page_bounds(session: &Session) -> (usize, usize) {
    let len = session.groups.len();
    let start = session.group_page.min(len.max(1).div_ceil(40)-1)*40;
    (start, (start+40).min(len))
}
fn group_page_info(session: &Session) -> (String, bool, bool) {
    let (start,end) = group_page_bounds(session);
    (format!("Unterordner {}–{} / {}", if end==0 { 0 } else { start+1 }, end, session.groups.len()), start>0, end<session.groups.len())
}
fn set_group_page(app: &MainWindow, info: (String,bool,bool)) {
    app.set_folder_audit_group_page_info(info.0.into());
    app.set_folder_audit_group_has_prev(info.1);
    app.set_folder_audit_group_has_next(info.2);
}
fn set_audit_rows(app: &MainWindow, rows: Vec<Vec<String>>) {
    crate::folder_relations::update_rows_model(app.get_folder_audit_rows(), rows, |m| app.set_folder_audit_rows(m));
}
fn set_audit_groups(app: &MainWindow, rows: Vec<Vec<String>>) {
    crate::folder_relations::update_rows_model(app.get_folder_audit_subfolders(), rows, |m| app.set_folder_audit_subfolders(m));
}
fn set_counts(app: &MainWindow, counts: [i32; 6]) {
    let current = app.get_folder_audit_counts();
    if let Some(model) = current.as_any().downcast_ref::<VecModel<i32>>() {
        if model.row_count() == counts.len() {
            for (i, value) in counts.into_iter().enumerate() {
                if model.row_data(i) != Some(value) { model.set_row_data(i, value); }
            }
            return;
        }
    }
    app.set_folder_audit_counts(ModelRc::new(VecModel::from(counts.to_vec())));
}
pub(super) fn publish_rows(app: &MainWindow, rows: Vec<Vec<String>>) { set_audit_rows(app, rows); }

fn warm_session_cache() {
    if let Ok(mut guard) = SESSION.lock() { if let Some(session) = guard.as_mut() {
        refresh_cached_groups(session);
        let _ = session_counts(session);
        let _ = visible_indices(session);
    } }
}
fn refresh_cached_groups(session: &mut Session) {
    if session.groups_dirty {
        session.groups = build_group_counts(&session.entries, &session.a);
        session.groups_dirty = false;
    }
}

// Single mapping for every displayed page and row action. Clamp stale page
// after batch mutations so a shrunken result never addresses a wrong file.
fn page_bounds(session: &Session, len: usize) -> (usize,usize) {
    let size = session.display_limit.clamp(1,PAGE);
    let max_page = len.max(1).div_ceil(size).saturating_sub(1);
    let start = session.page.min(max_page) * size;
    (start,(start+size).min(len))
}
fn page_rows(session: &Session) -> (Vec<Vec<String>>, String) {
    let displayed = visible_indices(session);
    let (start, end) = page_bounds(session, displayed.len());
    let rows = displayed[start.min(displayed.len())..end].iter().map(|&i| {
        let mut row = row_text(&session.entries[i], &session.a, &session.b);
        row[4] = if session.selected.contains(&i) { "1".into() } else { "0".into() };
        row
    }).collect();
    let selected = session.selected.len();
    let label = if session.from_index { "Index-Vorschau – nicht vollständig geprüft" } else { "Aktueller Audit" };
    (rows, format!("{label} · {}–{} von {} Dateien · {selected} ausgewählt",
        if displayed.is_empty() { 0 } else { start+1 }, end, displayed.len()))
}

/// Nur im UI-Thread aufrufen.
pub(super) fn to_model(rows: Vec<Vec<String>>) -> ModelRc<ModelRc<SharedString>> { model(rows) }

/// Called from the background scan thread, before the UI result is published.
pub(super) fn prepare(audit: &Audit, a: &Path, b: &Path) -> (Vec<Vec<String>>, String) {
    let mut entries = Vec::with_capacity(audit.files_a + audit.extra_b.len());
    // Pair same relative path but DIFFERENT content explicitly as a conflict.
    // These paths are NOT in audit.pairs (which contain verified same-content pairs).
    let extra_by_relative: BTreeMap<PathBuf, PathBuf> = audit.extra_b.iter()
        .filter_map(|p| p.strip_prefix(b).ok().map(|relative| (relative.to_path_buf(), p.clone())))
        .collect();
    let mut conflicts_b = BTreeSet::new();
    for path in &audit.missing_a {
        let counterpart = path.strip_prefix(a).ok().and_then(|r| extra_by_relative.get(r));
        if let Some(right) = counterpart {
            conflicts_b.insert(right.clone());
            entries.push(Entry { a: Some(path.clone()), b: Some(right.clone()), kind: Kind::Conflict, checked_conflict: false, fast_proof: None });
        } else {
            entries.push(Entry { a: Some(path.clone()), b: None, kind: Kind::OnlyA, checked_conflict: false, fast_proof: None });
        }
    }
    for (left, right) in &audit.pairs {
        let proof = audit.pair_stamps.get(left).and_then(|(a, b)| FastProof::from_audit(a, b));
        entries.push(Entry { a: Some(left.clone()), b: Some(right.clone()), kind: Kind::Same,
            checked_conflict: false, fast_proof: proof });
    }
    for path in &audit.extra_b {
        if !conflicts_b.contains(path) { entries.push(Entry { a: None, b: Some(path.clone()), kind: Kind::OnlyB, checked_conflict: false, fast_proof: None }); }
    }
    let groups = build_group_counts(&entries, a);
    let session = Session { a: a.to_owned(), b: b.to_owned(), patterns: audit.patterns.clone(), entries, page: 0, filter: "all".into(), selected: BTreeSet::new(), from_index: false, scope: String::new(), display_limit: INITIAL_VISIBLE, groups, groups_dirty: false, visible_cache: RefCell::new(None), counts_cache: Cell::new(None), group_page: 0 };
    let _ = session_counts(&session);
    let result = page_rows(&session);
    if let Ok(mut guard) = SESSION.lock() { *guard = Some(session); }
    result
}

/// Construct a side-by-side table from the existing content index without
/// rehashing files. All conclusions remain explicitly provisional.
///
/// Linear in der Dateizahl: Kandidaten je Inhalt werden einmal vorsortiert nachgeschlagen,
/// statt für jede Datei die komplette B-Liste zu durchsuchen. Das Ergebnis ist
/// Eintrag für Eintrag identisch mit der früheren, quadratischen Variante (Differenztest).
pub(super) fn prepare_index_preview(
    a: &Path, b: &Path,
    indexed_a: Vec<crate::folder_relations::IndexedFile>,
    indexed_b: Vec<crate::folder_relations::IndexedFile>,
    patterns: Vec<String>,
) -> (Vec<Vec<String>>, String) {
    let session = index_preview_session(a, b, indexed_a, indexed_b, patterns);
    let _ = session_counts(&session);
    let result = page_rows(&session);
    if let Ok(mut guard) = SESSION.lock() { *guard = Some(session); }
    result
}

fn index_preview_session(
    a: &Path, b: &Path,
    indexed_a: Vec<crate::folder_relations::IndexedFile>,
    indexed_b: Vec<crate::folder_relations::IndexedFile>,
    patterns: Vec<String>,
) -> Session {
    let mut left = indexed_a;
    let mut right = indexed_b;
    // A kommt sortiert aus dem Index. B bleibt in Baumreihenfolge: Eine Sortierung von Millionen Pfaden
    // kostet Sekunden und ist nicht nötig, nur die kleinen Kandidatenlisten werden nach Pfad geordnet.
    if !left.windows(2).all(|w| w[0].path <= w[1].path) { left.sort_by(|x, y| x.path.cmp(&y.path)); }

    // Nur Inhalte, die in A vorkommen, brauchen Kandidaten in B (je Liste: Pfadreihenfolge).
    let wanted: std::collections::HashSet<u32> = left.iter().filter_map(|f| f.content_id).collect();
    let mut candidates_b: std::collections::HashMap<u32, Vec<usize>> = std::collections::HashMap::new();
    for (i, f) in right.iter().enumerate() {
        if let Some(id) = f.content_id { if wanted.contains(&id) { candidates_b.entry(id).or_default().push(i); } }
    }
    for list in candidates_b.values_mut() { list.sort_by(|&x, &y| right[x].path.cmp(&right[y].path)); }
    let mut used_b = vec![false; right.len()];
    let mut entries: Vec<Entry> = Vec::with_capacity(left.len());
    {
        // (Inhalt, relativer Pfad in B) -> Index: bevorzugt dieselbe Lage wie in A.
        let mut by_relative: std::collections::HashMap<(u32, &Path), usize> = std::collections::HashMap::new();
        for (id, list) in &candidates_b {
            for &i in list {
                if let Ok(rel) = right[i].path.strip_prefix(b) { by_relative.insert((*id, rel), i); }
            }
        }
        let mut cursor: std::collections::HashMap<u32, usize> = std::collections::HashMap::new();
        for file in &left {
            let mut found: Option<usize> = None;
            if let Some(id) = file.content_id {
                if let Some(list) = candidates_b.get(&id) {
                    let preferred = file.path.strip_prefix(a).ok()
                        .and_then(|rel| by_relative.get(&(id, rel)).copied())
                        .filter(|&i| !used_b[i]);
                    found = preferred.or_else(|| {
                        // Erster noch freier Kandidat; der Zeiger geht nur vorwärts (Belegungen werden nie zurückgenommen).
                        let position = cursor.entry(id).or_insert(0);
                        while *position < list.len() && used_b[list[*position]] { *position += 1; }
                        list.get(*position).copied()
                    });
                }
            }
            if let Some(i) = found { used_b[i] = true; }
            let fast_proof = found.and_then(|i| {
                let other = &right[i];
                (file.fast_eligible && other.fast_eligible).then(|| FastProof { size_a: file.size, size_b: other.size,
                    modified_a: file.modified, modified_b: other.modified })
            });
            entries.push(Entry { a: Some(file.path.clone()), b: found.map(|i| right[i].path.clone()),
                kind: if found.is_some() { Kind::Same } else { Kind::OnlyA }, checked_conflict: false, fast_proof });
        }
    }
    // Gleicher relativer Pfad mit anderem oder unbekanntem Hash: Konflikt.
    let mut consumed = vec![false; right.len()];
    {
        let unmatched: std::collections::HashMap<&Path, usize> = entries.iter().enumerate()
            .filter(|(_, e)| e.kind == Kind::OnlyA)
            .filter_map(|(n, e)| Some((e.a.as_deref()?.strip_prefix(a).ok()?, n))).collect();
        if !unmatched.is_empty() {
            let mut conflicts: Vec<(usize, usize)> = Vec::new();
            for (i, f) in right.iter().enumerate() {
                if used_b[i] { continue; }
                if let Some(&n) = f.path.strip_prefix(b).ok().and_then(|rel| unmatched.get(rel)) { conflicts.push((n, i)); }
            }
            for (n, i) in conflicts {
                entries[n].b = Some(right[i].path.clone());
                entries[n].kind = Kind::Conflict;
                consumed[i] = true;
            }
        }
    }
    for (i, file) in right.into_iter().enumerate() {
        if !used_b[i] && !consumed[i] {
            entries.push(Entry { a: None, b: Some(file.path), kind: Kind::OnlyB, checked_conflict: false, fast_proof: None });
        }
    }
    let groups = build_group_counts(&entries, a);
    Session { a: a.into(), b: b.into(), patterns,
        entries, page: 0, filter: "all".into(), selected: BTreeSet::new(), from_index: true, scope: String::new(), display_limit: INITIAL_VISIBLE, groups, groups_dirty: false, visible_cache: RefCell::new(None), counts_cache: Cell::new(None), group_page: 0 }
}

/// Produce a truthful report from the indexed preview instead of accidentally
/// exporting a previously completed, unrelated fresh audit.
pub(super) fn index_preview_report() -> Option<String> {
    let guard = SESSION.lock().ok()?;
    let session = guard.as_ref()?;
    if !session.from_index { return None; }
    let mut lines = vec![
        "UNVERIFIZIERTE INDEX-VORSCHAU – KEINE LÖSCHFREIGABE".to_owned(),
        format!("A: {}", session.a.display()),
        format!("B: {}", session.b.display()),
        format!("{} Einträge aus früherem Scan; Filter für Systemdateien können den Index einschränken", session.entries.len()),
    ];
    for entry in &session.entries {
        let row = row_text(entry, &session.a, &session.b);
        lines.push(format!("{} | {} | {}", row[3], row[0], row[1]));
    }
    Some(lines.join("\n"))
}

pub(super) fn reset() {
    if let Ok(mut guard) = SESSION.lock() { *guard = None; }
}

fn ui_message(weak: &Weak<MainWindow>, message: String) {
    let _ = weak.upgrade_in_event_loop(move |app| app.set_folder_compare_status(message.into()));
}

/// A completed audit belongs to one exact pair of roots and one set of filters.
/// The user can edit the path fields or choose a different pair from Folder Relationships
/// without starting a new scan. Never apply a manual file action to that old session.
fn current_inputs_match_session(app: &MainWindow) -> bool {
    let Ok(guard) = SESSION.lock() else { return false; };
    let Some(session) = guard.as_ref() else { return false; };
    let left = fs::canonicalize(Path::new(app.get_folder_compare_left_path().as_str())).ok();
    let right = fs::canonicalize(Path::new(app.get_folder_compare_right_path().as_str())).ok();
    let patterns = parse_patterns(app.get_folder_compare_ignore_patterns().as_str()).ok();
    // Auch der Pfad der Sitzung wird kanonisiert: Die Index-Vorschau speichert den Pfad aus dem Scan, der Audit den kanonischen.
    let session_a = fs::canonicalize(&session.a).ok();
    let session_b = fs::canonicalize(&session.b).ok();
    left.is_some() && right.is_some()
        && left == session_a
        && right == session_b
        && patterns.as_deref() == Some(session.patterns.as_slice())
}

fn checked_roots(a: &Path, b: &Path) -> Result<(), String> {
    let ma = fs::symlink_metadata(a).map_err(|e| format!("A: {e}"))?;
    let mb = fs::symlink_metadata(b).map_err(|e| format!("B: {e}"))?;
    if !ma.file_type().is_dir() || !mb.file_type().is_dir() {
        return Err("A und B müssen echte Verzeichnisse sein (keine symbolischen Links).".into());
    }
    let ca = a.canonicalize().map_err(|e| e.to_string())?;
    let cb = b.canonicalize().map_err(|e| e.to_string())?;
    if starts_with_ci(&ca, &cb) || starts_with_ci(&cb, &ca) { return Err("A und B dürfen nicht ineinander liegen.".into()); }
    Ok(())
}

fn checked_regular(path: &Path, root: &Path) -> Result<fs::Metadata, String> {
    if !path.starts_with(root) || path == root { return Err("Datei liegt außerhalb des gewählten Ordners.".into()); }
    let relative = path.strip_prefix(root).map_err(|e| e.to_string())?;
    if relative.components().any(|c| !matches!(c, Component::Normal(_))) { return Err("Ungültiger Quellpfad".into()); }
    let mut parent = root.to_path_buf();
    for component in relative.parent().ok_or("Ungültiger Quellpfad")?.components() {
        parent.push(component.as_os_str());
        if !fs::symlink_metadata(&parent).map_err(|e| format!("{:?}: {}", parent, io_detail(e)))?.file_type().is_dir() {
            return Err(format!("Quellpfad enthält symbolischen Link oder Nicht-Verzeichnis: {}", parent.display()));
        }
    }
    let meta = fs::symlink_metadata(path).map_err(io_detail)?;
    if !meta.file_type().is_file() { return Err("Nur echte reguläre Dateien sind erlaubt, keine Symlinks.".into()); }
    let canon = path.canonicalize().map_err(|e| e.to_string())?;
    if !canon.starts_with(root.canonicalize().map_err(|e| e.to_string())?) {
        return Err("Dateipfad verlässt den ausgewählten Ordner.".into());
    }
    Ok(meta)
}

/// Liest, bis der Puffer voll oder das Ende erreicht ist. Einzelne `read`-Aufrufe dürfen kürzer ausfallen
/// (Netzlaufwerke, externe Platten); ohne diese Schleife würden gleiche Dateien als verschieden gemeldet.
fn fill<R: Read>(reader: &mut R, buffer: &mut [u8]) -> io::Result<usize> {
    let mut total = 0;
    while total < buffer.len() {
        match reader.read(&mut buffer[total..]) {
            Ok(0) => break,
            Ok(n) => total += n,
            Err(e) if e.kind() == io::ErrorKind::Interrupted => continue,
            Err(e) => return Err(e),
        }
    }
    Ok(total)
}

fn equal_streams<R: Read, S: Read>(left: &mut R, right: &mut S) -> io::Result<bool> {
    let mut left_buffer = vec![0u8; 128 * 1024];
    let mut right_buffer = vec![0u8; 128 * 1024];
    loop {
        let n = fill(left, &mut left_buffer)?;
        let m = fill(right, &mut right_buffer)?;
        if n != m || left_buffer[..n] != right_buffer[..m] { return Ok(false); }
        if n == 0 { return Ok(true); }
    }
}

fn equal_bytes(a: &Path, b: &Path) -> io::Result<bool> {
    equal_streams(&mut File::open(a)?, &mut File::open(b)?)
}

#[cfg(target_os = "macos")]
fn mac_xattrs(path: &Path, all: bool) -> Result<BTreeMap<Vec<u8>, Vec<u8>>, String> {
    use std::os::unix::ffi::OsStrExt;
    use std::ffi::{CString, c_char, c_void};
    unsafe extern "C" {
        fn listxattr(path: *const c_char, names: *mut c_char, size: usize, options: i32) -> isize;
        fn getxattr(path: *const c_char, name: *const c_char, value: *mut c_void, size: usize, position: u32, options: i32) -> isize;
    }
    const NOFOLLOW: i32 = 1;
    const LIMIT: usize = 64 * 1024 * 1024;
    let p = CString::new(path.as_os_str().as_bytes()).map_err(|e| e.to_string())?;
    let n = unsafe { listxattr(p.as_ptr(), std::ptr::null_mut(), 0, NOFOLLOW) };
    if n < 0 { return Err(format!("xattr list: {}", io_detail(io::Error::last_os_error()))); }
    if n as usize > LIMIT { return Err("xattr Namensliste zu groß".into()); }
    let mut names = vec![0u8; n as usize];
    if n == 0 { return Ok(BTreeMap::new()); }
    let got = unsafe { listxattr(p.as_ptr(), names.as_mut_ptr().cast(), names.len(), NOFOLLOW) };
    if got < 0 { return Err(io_detail(io::Error::last_os_error())); }
    if got != n { return Err("xattr Liste während Prüfung geändert".into()); }
    let mut result = BTreeMap::new();
    let mut total = 0usize;
    for name in names.split(|b| *b == 0).filter(|n| !n.is_empty()) {
        if !all && name != b"com.apple.ResourceFork" && name != b"com.apple.FinderInfo" { continue; }
        let c = CString::new(name).map_err(|e| e.to_string())?;
        let len = unsafe { getxattr(p.as_ptr(), c.as_ptr(), std::ptr::null_mut(), 0, 0, NOFOLLOW) };
        if len < 0 { return Err(io_detail(io::Error::last_os_error())); }
        total = total.saturating_add(len as usize);
        if total > LIMIT { return Err("xattr Daten über 64 MiB; manuelle Prüfung erforderlich".into()); }
        let mut value = vec![0u8; len as usize];
        if len > 0 {
            let read = unsafe { getxattr(p.as_ptr(), c.as_ptr(), value.as_mut_ptr().cast(), value.len(), 0, NOFOLLOW) };
            if read < 0 { return Err(io_detail(io::Error::last_os_error())); }
            if read != len { return Err("xattr während Prüfung geändert".into()); }
        }
        result.insert(name.to_vec(), value);
    }
    Ok(result)
}
fn verify_mac_extra(a: &Path, b: &Path, copy: bool) -> Result<(), String> {
    #[cfg(target_os = "macos")]
    {
        let left = mac_xattrs(a, copy)?;
        let right = mac_xattrs(b, copy)?;
        if if copy { left.iter().any(|(k,v)| right.get(k) != Some(v)) } else { left != right } {
            return Err("macOS-Zusatzdaten unterschiedlich (Resource Fork/FinderInfo bzw. Kopier-xattrs); Quelle bleibt erhalten".into());
        }
    }
    #[cfg(not(target_os = "macos"))] let _ = (a,b,copy);
    Ok(())
}
fn source_stamp(meta: &fs::Metadata) -> (u64, Option<SystemTime>) {
    (meta.len(), meta.modified().ok())
}

/// Streaming BLAKE3: bounded memory independent of file size.
fn hash_file(path: &Path) -> io::Result<blake3::Hash> {
    let mut file = File::open(path)?;
    let mut hasher = blake3::Hasher::new();
    let mut buf = [0_u8; 128 * 1024];
    loop {
        let n = file.read(&mut buf)?;
        if n == 0 { break; }
        hasher.update(&buf[..n]);
    }
    Ok(hasher.finalize())
}

/// Fast mode does not read content. Only valid for a qualifying, formerly
/// content-verified pair with metadata from that completed scan.
fn matches_fast_evidence(left: &fs::Metadata, right: &fs::Metadata, proof: FastProof) -> bool {
    left.len() == proof.size_a && right.len() == proof.size_b &&
        proof.size_a == proof.size_b &&
        left.modified().ok().and_then(unix_seconds) == Some(proof.modified_a) &&
        right.modified().ok().and_then(unix_seconds) == Some(proof.modified_b)
}

/// Create missing parent directories, refusing all existing symlinks.
/// Does not allow a symlink in any component of the target within B.
// Read-only selected-path check: no mkdir, no deletion and no access() promise.
fn preview_destination(root: &Path, relative: &Path) -> Result<(), String> {
    if relative.is_absolute() || relative.components().any(|c| !matches!(c, Component::Normal(_))) { return Err("Ungültiges Ziel".into()); }
    let mut path = root.to_owned();
    for component in relative.components() {
        path.push(component.as_os_str());
        match fs::symlink_metadata(&path) {
            Ok(m) if path == root.join(relative) => { let _ = m; return Err(format!("Ziel existiert: {:?}", path)); }
            Ok(m) if !m.file_type().is_dir() => return Err(format!("Zielpfad enthält Link oder Datei: {:?}", path)),
            Ok(_) => {},
            Err(e) if e.kind() == io::ErrorKind::NotFound => return Ok(()),
            Err(e) => return Err(format!("Zielpfad {:?}: {}", path, io_detail(e))),
        }
    }
    Ok(())
}
fn checked_destination(b: &Path, relative: &Path) -> Result<PathBuf, String> {
    if relative.is_absolute() || relative.components().any(|c| !matches!(c, Component::Normal(_))) {
        return Err("Ungültiger relativer Dateipfad.".into());
    }
    let mut current = b.to_path_buf();
    let parent = relative.parent().ok_or("Ungültiger Zielpfad")?;
    for component in parent.components() {
        current.push(component.as_os_str());
        if current.exists() {
            let meta = fs::symlink_metadata(&current).map_err(|e| e.to_string())?;
            if !meta.file_type().is_dir() { return Err(format!("Ziel enthält Link oder Datei statt Verzeichnis: {}", current.display())); }
        } else {
            fs::create_dir(&current).map_err(|e| format!("Ordner konnte nicht erstellt werden: {e}"))?;
        }
    }
    Ok(b.join(relative))
}

/// Merge ONE file (only in A) into B at the same relative path.
/// Existing destination ALWAYS causes failure; no replacement, no move, no source deletion.
#[cfg(target_os = "macos")]
fn copy_missing(a: &Path, b: &Path, source: &Path) -> Result<(PathBuf, bool), String> {
    copy_for_move(a,b,source).map(|p| (p,true))
}
#[cfg(not(target_os = "macos"))]
fn copy_missing(a: &Path, b: &Path, source: &Path) -> Result<(PathBuf, bool), String> {
    checked_roots(a, b)?;
    let before = checked_regular(source, a)?;
    let relative = source.strip_prefix(a).map_err(|e| e.to_string())?;
    let target = checked_destination(b, relative)?;
    let mut input = File::open(source).map_err(|e| e.to_string())?;
    let mut output = OpenOptions::new().write(true).create_new(true).open(&target)
        .map_err(|e| format!("Zieldatei existiert bereits oder kann nicht erstellt werden: {} ({e})", target.display()))?;
    let copied = (|| -> Result<(), String> {
        io::copy(&mut input, &mut output).map_err(|e| format!("Kopieren fehlgeschlagen: {e}"))?;
        output.flush().map_err(|e| e.to_string())?;
        output.sync_all().map_err(|e| e.to_string())?;
        drop(output);
        let after = checked_regular(source, a)?;
        if source_stamp(&before) != source_stamp(&after) {
            return Err("Quelle wurde während des Kopierens verändert.".into());
        }
        if !equal_bytes(source, &target).map_err(|e| e.to_string())? {
            return Err("Kopierte Datei ist nicht byte-identisch.".into());
        }
        Ok(())
    })();
    if let Err(err) = copied {
        // Only a file that we successfully created with create_new can be cleaned up.
        let _ = fs::remove_file(&target);
        return Err(err);
    }
    // Der Inhalt ist verifiziert. Zeitstempel und Zugriffsrechte werden danach bestmöglich übernommen.
    // Finder-Tags, erweiterte Attribute und Resource Forks werden NICHT kopiert.
    let mut metadata_ok = true;
    if let Ok(modified) = before.modified() {
        metadata_ok &= OpenOptions::new().write(true).open(&target).and_then(|file| file.set_modified(modified)).is_ok();
    }
    metadata_ok &= fs::set_permissions(&target, before.permissions()).is_ok();
    Ok((target, metadata_ok))
}

/// MOVE uses a no-overwrite hard link and removes the old link when supported.
/// Otherwise we make a verified destination copy first, and trash the source in
/// a native per-file trash operation. Never call a partial copy a completed move.
#[derive(Debug)]
enum MoveStage { Moved(PathBuf), PendingTrash(PathBuf) }

#[cfg(unix)]
fn same_inode(a: &fs::Metadata, b: &fs::Metadata) -> bool { a.dev() == b.dev() && a.ino() == b.ino() }

#[cfg(target_os = "macos")]
fn copy_for_move(from: &Path, to: &Path, source: &Path) -> Result<PathBuf, String> {
    checked_roots(from, to)?;
    let before = checked_regular(source, from)?;
    let rel = source.strip_prefix(from).map_err(|e| e.to_string())?;
    let dest = checked_destination(to, rel)?;
    // Reserve destination EXCLUSIVELY. /bin/cp may only overwrite our own placeholder.
    let placeholder = OpenOptions::new().write(true).create_new(true).open(&dest)
        .map_err(|e| format!("Ziel existiert oder ist gesperrt: {} ({e})", dest.display()))?;
    drop(placeholder);
    let outcome = (|| -> Result<(), String> {
        // macOS cp -p already preserves timestamps, permissions, ACLs, xattrs and resource forks.
        // -E is NOT a supported macOS cp flag (exit status 64 / usage error).
        let result = Command::new("/bin/cp").arg("-p").arg(source).arg(&dest).output()
            .map_err(|e| format!("macOS-Metadatenkopie konnte nicht gestartet werden: {e}"))?;
        if !result.status.success() {
            return Err(format!("macOS-Metadatenkopie fehlgeschlagen ({}): {}",
                result.status, String::from_utf8_lossy(&result.stderr).trim()));
        }
        if !equal_bytes(source, &dest).map_err(|e| e.to_string())? {
            return Err("Zielinhalt stimmt nicht byteweise mit Quelle überein".into());
        }
        verify_mac_extra(source, &dest, true)?;
        if source_stamp(&checked_regular(source, from)?) != source_stamp(&before) {
            return Err("Quelle wurde beim Kopieren verändert".into());
        }
        checked_regular(&dest, to)?;
        Ok(())
    })();
    if let Err(e) = outcome {
        let _ = fs::remove_file(&dest);
        return Err(format!("{e}; Quelle bleibt bestehen"));
    }
    Ok(dest)
}
#[cfg(not(target_os = "macos"))]
fn copy_for_move(from: &Path, to: &Path, source: &Path) -> Result<PathBuf, String> {
    copy_missing(from, to, source).map(|(p, _)| p)
}

fn stage_move(from: &Path, to: &Path, source: &Path) -> Result<MoveStage, String> {
    stage_move_impl(from, to, source, false)
}
fn stage_move_impl(from: &Path, to: &Path, source: &Path, force_copy: bool) -> Result<MoveStage, String> {
    checked_roots(from, to)?;
    let before = checked_regular(source, from)?;
    let rel = source.strip_prefix(from).map_err(|e| e.to_string())?;
    let dest = checked_destination(to, rel)?;
    if !force_copy && fs::hard_link(source, &dest).is_ok() {
        let src_after = checked_regular(source, from)?;
        let dst_after = checked_regular(&dest, to)?;
        #[cfg(unix)] let unchanged = same_inode(&before, &src_after) && same_inode(&before, &dst_after);
        #[cfg(not(unix))] let unchanged = source_stamp(&before) == source_stamp(&src_after);
        if !unchanged || source_stamp(&before) != source_stamp(&src_after) {
            let _ = fs::remove_file(&dest);
            return Err("Quelldatei hat sich verändert; nichts gelöscht".into());
        }
        return match fs::remove_file(source) {
            Ok(()) => Ok(MoveStage::Moved(dest)),
            Err(_) => Ok(MoveStage::PendingTrash(dest)),
        };
    }
    copy_for_move(from, to, source).map(MoveStage::PendingTrash)
}

/// Bytevergleich zweier gepaarter Dateien ohne jede Änderung. Ok(true) = byteweise identisch.
fn verify_pair(a: &Path, b: &Path, left: &Path, right: &Path) -> Result<bool, String> {
    let la = checked_regular(left, a)?;
    let rb = checked_regular(right, b)?;
    if la.len() != rb.len() { return Ok(false); }
    equal_bytes(left, right).map_err(|e| e.to_string())
}

/// macOS creates these transient directories at the top level of external
/// volumes. They must not be changed and are outside the archive inventory.
/// We cannot assert that they contain no links; this exception is documented
/// in the UI and must NOT be applied to arbitrary unreadable user folders.
fn is_known_volume_temp(path: &Path) -> bool {
    let name = path.file_name().and_then(|n| n.to_str());
    let volume = path.parent();
    matches!(name, Some(".TemporaryItems" | ".Trashes"))
        && volume.and_then(Path::parent) == Some(Path::new("/Volumes"))
}

/// Partial link inventory: unreadable unrelated entries are reported, not silently
/// treated as link-free. Known dependencies still protect the affected source.
#[derive(Default)]
struct LinkPreflight {
    roots: Vec<PathBuf>,
    protected: BTreeSet<PathBuf>,
    skipped: usize,
    examples: Vec<String>,
}
fn link_key_path(path: &Path) -> PathBuf {
    // Same conservative case folding as the original links_into_a check.
    PathBuf::from(normalize(path).to_string_lossy().to_lowercase())
}
impl LinkPreflight {
    fn skip(&mut self, path: &Path, error: &io::Error) {
        self.skipped += 1;
        if self.examples.len() < 5 { self.examples.push(format!("{}: {error}", path.display())); }
    }
    fn protect(&mut self, path: &Path) {
        let key = link_key_path(path);
        // An external ancestor (e.g. a link to / or /Volumes) is not a
        // dependency on an individual file in the chosen archive.
        if self.roots.iter().any(|root| key.starts_with(root)) { self.protected.insert(key); }
    }
    fn check_path(&self, path: &Path) -> Result<(), String> {
        let key = link_key_path(path);
        if key.ancestors().any(|p| self.protected.contains(p)) {
            return Err(format!("Bekannte Symlink-Abhängigkeit: {}", path.display()));
        }
        if let Ok(canonical) = path.canonicalize() {
            let key = link_key_path(&canonical);
            if key.ancestors().any(|p| self.protected.contains(p)) {
                return Err(format!("Bekannte Symlink-Abhängigkeit: {}", path.display()));
            }
        }
        Ok(())
    }
    fn warning(&self) -> String {
        if self.skipped == 0 { String::new() } else {
            format!(" ACHTUNG: Link-Prüfung unvollständig ({} nicht lesbare Einträge/Bereiche). Unbekannte Links nicht ausgeschlossen. {}", self.skipped, self.examples.join(" | "))
        }
    }
}
fn inventory_links_for_preflight(root: &Path, result: &mut LinkPreflight) -> Result<(), String> {
    let mut directories = vec![root.to_owned()];
    while let Some(dir) = directories.pop() {
        if BATCH_STOP.load(Ordering::Relaxed) { return Err("Link-Prüfung abgebrochen".into()); }
        if is_known_volume_temp(&dir) { continue; }
        let entries = match fs::read_dir(&dir) {
            Ok(entries) => entries,
            Err(e) => { result.skip(&dir, &e); continue; }
        };
        for entry in entries {
            if BATCH_STOP.load(Ordering::Relaxed) { return Err("Link-Prüfung abgebrochen".into()); }
            let entry = match entry { Ok(entry) => entry, Err(e) => { result.skip(&dir, &e); continue; } };
            let path = entry.path();
            if is_known_volume_temp(&path) { continue; }
            let metadata = match fs::symlink_metadata(&path) {
                Ok(metadata) => metadata,
                Err(e) => { result.skip(&path, &e); continue; }
            };
            if metadata.file_type().is_dir() { directories.push(path); }
            else if metadata.file_type().is_symlink() {
                match fs::read_link(&path) {
                    Ok(target) => result.protect(&resolve_target(&path, &target)),
                    Err(e) => result.skip(&path, &e),
                }
                if let Ok(canonical) = fs::canonicalize(&path) { result.protect(&canonical); }
            }
        }
    }
    Ok(())
}
fn link_preflight(a: &Path, b: &Path) -> Result<LinkPreflight, String> {
    checked_roots(a, b)?;
    let mut result = LinkPreflight::default();
    result.roots.extend([link_key_path(a), link_key_path(b)]);
    for root in [a,b] {
        if let Ok(canonical) = root.canonicalize() { result.roots.push(link_key_path(&canonical)); }
    }
    inventory_links_for_preflight(a, &mut result)?;
    inventory_links_for_preflight(b, &mut result)?;
    Ok(result)
}

/// Verify selected files according to the explicitly chosen mode. Never mutates data.
/// Fast is a metadata-guarded TRUST decision; it is NOT a fresh content check.
fn preflight_trash_pair_with_mode(
    a: &Path, b: &Path, left: &Path, right: &Path,
    mode: TrashCheckMode, proof: Option<FastProof>,
) -> Result<(), String> {
    let la = checked_regular(left, a)?;
    let rb = checked_regular(right, b)?;
    if la.len() != rb.len() { return Err("Dateigrößen unterscheiden sich; keine Papierkorbaktion.".into()); }
    let before_a = source_stamp(&la);
    let before_b = source_stamp(&rb);
    if left.canonicalize().map_err(|e|e.to_string())? == right.canonicalize().map_err(|e|e.to_string())? {
        return Err("A und B bezeichnen denselben Dateipfad".into());
    }
    let matches = match mode {
        TrashCheckMode::Fast => {
            let Some(p) = proof else {
                return Err("Kein geeigneter, aktueller BLAKE3-Scan-Nachweis vorhanden. 'Aktueller Hash' oder 'Bytevergleich' wählen.".into());
            };
            matches_fast_evidence(&la, &rb, p)
        }
        TrashCheckMode::FreshHash => hash_file(left).map_err(|e| format!("Hash {:?}: {}",left,io_detail(e)))?
            == hash_file(right).map_err(|e| format!("Hash {:?}: {}",right,io_detail(e)))?,
        TrashCheckMode::Bytes => equal_bytes(left, right).map_err(io_detail)?,
    };
    if !matches { return Err("Inhalt bzw. Scan-Metadaten stimmen nicht überein. Keine Papierkorbaktion.".into()); }
    verify_mac_extra(left, right, false)?;
    // TOCTOU mitigation (not atomic). Root/link checks are still separately mandatory.
    let after_a = checked_regular(left, a)?;
    let after_b = checked_regular(right, b)?;
    #[cfg(unix)]
    if !same_inode(&la,&after_a) || !same_inode(&rb,&after_b) { return Err("Datei wurde während der Prüfung ersetzt".into()); }
    if before_a != source_stamp(&after_a) || before_b != source_stamp(&after_b) {
        return Err("Dateien wurden während der Prüfung verändert.".into());
    }
    Ok(())
}

/// One confirmed pair, independent of every other selected pair.
fn verified_remove_pair(a: &Path, b: &Path, left: &Path, right: &Path,
    mode: TrashCheckMode, proof: Option<FastProof>, links: &LinkPreflight,
    permanent: bool, finder_retry: bool) -> Result<(), String> {
    checked_roots(a,b)?;
    links.check_path(left).map_err(|e| format!("Linkprüfung: {e}"))?;
    preflight_trash_pair_with_mode(a,b,left,right,mode,proof).map_err(|e| format!("Duplikatprüfung: {e}"))?;
    if BATCH_STOP.load(Ordering::Relaxed) { return Err("Abgebrochen".into()); }
    remove_verified_source(left, permanent, finder_retry).map_err(|e| format!("Entfernen: {e}"))
}

/// Legacy safety helper for tests/individual audit code: full byte comparison.
fn preflight_trash_pair(a: &Path, b: &Path, left: &Path, right: &Path) -> Result<(), String> {
    preflight_trash_pair_with_mode(a, b, left, right, TrashCheckMode::Bytes, None)
}

/// One-file manual trash remains a distinct, user-confirmed operation.
fn trash_pair(a: &Path, b: &Path, left: &Path, right: &Path) -> Result<(), String> {
    preflight_trash_pair(a, b, left, right)?;
    remove_verified_source(left, false, false)
}

/// Einzelaktion: Preflight und Papierkorb für eine Datei.
fn trash_identical_a(a: &Path, b: &Path, left: &Path, right: &Path) -> Result<(), String> {
    let links = link_preflight(a, b)?;
    if links.skipped > 0 { return Err(links.warning()); }
    links.check_path(left)?;
    trash_pair(a, b, left, right)
}

#[cfg(target_os="macos")]
fn show_file(path: &Path, preview: bool) -> Result<(), String> {
    let mut command = if preview { Command::new("qlmanage") } else { Command::new("open") };
    command.arg(if preview { "-p" } else { "-R" }).arg(path)
        .stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null());
    let mut child = command.spawn().map_err(|e| e.to_string())?;
    thread::spawn(move || { let _ = child.wait(); });
    Ok(())
}
#[cfg(not(target_os="macos"))]
fn show_file(_path: &Path, _preview: bool) -> Result<(), String> { Err("Nur auf macOS verfügbar".into()) }

fn selected(index: i32) -> Result<(Entry, PathBuf, PathBuf, usize), String> {
    let guard = SESSION.lock().map_err(|_| "Interner Zustandsfehler")?;
    let session = guard.as_ref().ok_or("Bitte zuerst vergleichen.")?;
    let idx = usize::try_from(index).map_err(|_| "Keine Datei ausgewählt")?;
    let visible = visible_indices(session);
    let (start,end) = page_bounds(session,visible.len());
    if idx >= end-start { return Err("Keine Datei ausgewählt".into()); }
    let global = *visible.get(start+idx).ok_or("Keine Datei ausgewählt")?;
    let entry = session.entries.get(global).ok_or("Keine Datei ausgewählt")?.clone();
    Ok((entry, session.a.clone(), session.b.clone(), global))
}

fn selected_batch(kind: Kind) -> Result<(Vec<(usize, Entry)>, PathBuf, PathBuf), String> {
    let guard = SESSION.lock().map_err(|_| "Interner Zustandsfehler")?;
    let session = guard.as_ref().ok_or("Bitte zuerst vergleichen.")?;
    let entries = session.selected.iter().filter_map(|&i| session.entries.get(i)
        .filter(|entry| entry.kind == kind).map(|entry| (i, entry.clone())))
        .collect();
    Ok((entries, session.a.clone(), session.b.clone()))
}

fn conflict_batch() -> Result<(Vec<(usize, Entry)>, PathBuf, PathBuf), String> {
    let guard = SESSION.lock().map_err(|_| "Interner Zustandsfehler")?;
    let session = guard.as_ref().ok_or("Bitte zuerst vergleichen.")?;
    let entries = session.entries.iter().enumerate()
        .filter(|(_, entry)| entry.kind == Kind::Conflict)
        .map(|(i, entry)| (i, entry.clone())).collect();
    Ok((entries, session.a.clone(), session.b.clone()))
}

fn session_counts(session: &Session) -> [i32; 6] {
    if let Some(counts) = session.counts_cache.get() { return counts; }
    let mut counts = [0i32; 6];
    for item in &session.entries {
        counts[0] += 1;
        match item.kind {
            Kind::Same => counts[5] += 1,
            Kind::OnlyA => { counts[1] += 1; counts[2] += 1; },
            Kind::OnlyB => { counts[1] += 1; counts[3] += 1; },
            Kind::Conflict => { counts[1] += 1; counts[4] += 1; },
        }
    }
    session.counts_cache.set(Some(counts));
    counts
}

/// Called only from the UI thread. Counters describe the full audit, not just the visible page.
pub(super) fn update_metrics(app: &MainWindow) {
    let values = SESSION.lock().ok().and_then(|mut guard| guard.as_mut().map(|session| {
        refresh_cached_groups(session);
        let merge = session.selected.iter().filter(|&&i| session.entries.get(i).is_some_and(|e| e.kind == Kind::OnlyA)).count();
        let merge_back = session.selected.iter().filter(|&&i| session.entries.get(i).is_some_and(|e| e.kind == Kind::OnlyB)).count();
        let same = session.selected.iter().filter(|&&i| session.entries.get(i).is_some_and(|e| e.kind == Kind::Same)).count();
        (session_counts(session), merge, merge_back, same, session.from_index, subfolder_rows(session), group_page_info(session))
    }));
    let (counts, merge, merge_back, same, from_index, groups, group_info) = values.unwrap_or(([0;6],0,0,0,true,Vec::new(),("Unterordner 0–0 / 0".into(),false,false)));
    set_counts(app, counts);
    app.set_folder_audit_from_index(from_index);
    set_audit_groups(app, groups);
    set_group_page(app, group_info);
    app.set_folder_audit_selected_merge_count(i32::try_from(merge).unwrap_or(i32::MAX));
    app.set_folder_audit_selected_merge_back_count(i32::try_from(merge_back).unwrap_or(i32::MAX));
    app.set_folder_audit_selected_same_count(i32::try_from(same).unwrap_or(i32::MAX));
}

fn refresh_selection(weak: &Weak<MainWindow>) {
    // Collect everything under one lock, then release it BEFORE calling any UI setters.
    // update_metrics() must never lock SESSION recursively (std::sync::Mutex is not re-entrant).
    let values = SESSION.lock().ok().and_then(|mut guard| guard.as_mut().map(|session| {
        refresh_cached_groups(session);
        let (rows, info) = page_rows(session);
        let counts = session_counts(session);
        let merge = session.selected.iter().filter(|&&i| session.entries.get(i).is_some_and(|e| e.kind == Kind::OnlyA)).count();
        let merge_back = session.selected.iter().filter(|&&i| session.entries.get(i).is_some_and(|e| e.kind == Kind::OnlyB)).count();
        let same = session.selected.iter().filter(|&&i| session.entries.get(i).is_some_and(|e| e.kind == Kind::Same)).count();
        (rows, info, counts, merge, merge_back, same, session.from_index, subfolder_rows(session), group_page_info(session))
    }));
    let Some((rows, info, counts, merge, merge_back, same, from_index, groups, group_info)) = values else { return };
    if let Some(app) = weak.upgrade() {
        app.set_folder_audit_selected(-1);
        crate::folder_diagnostics::event(&format!("GUI audit refresh: {} rows, {} groups", rows.len(), groups.len()));
        set_audit_rows(&app, rows);
        set_audit_groups(&app, groups);
        set_group_page(&app, group_info);
        app.set_folder_audit_from_index(from_index);
        app.set_folder_audit_page_info(info.into());
        app.set_folder_audit_selected(-1);
        set_counts(&app, counts);
        app.set_folder_audit_selected_merge_count(i32::try_from(merge).unwrap_or(i32::MAX));
        app.set_folder_audit_selected_merge_back_count(i32::try_from(merge_back).unwrap_or(i32::MAX));
        app.set_folder_audit_selected_same_count(i32::try_from(same).unwrap_or(i32::MAX));
    }
}

pub(super) fn connect(app: &MainWindow) {
    let weak = app.as_weak();
    app.on_folder_audit_action(move |action, index| {
        // Audit actions must never act on a previous A/B pair after the visible
        // path or ignore-filter fields have changed.
        let Some(app) = weak.upgrade() else { return; };
        if action == "open_operation_report" {
            let path = app.get_folder_operation_report();
            if !path.is_empty() {
                #[cfg(target_os = "macos")]
                { let _ = Command::new("/usr/bin/open").arg(path.as_str()).spawn(); }
            }
            return;
        }
        if matches!(action.as_str(), "error_continue" | "error_skip_all" | "error_abort" | "error_retry_finder") {
            if app.get_folder_compare_busy() && !app.get_folder_operation_pause().is_empty() {
                let d = match action.as_str() { "error_continue" => 1, "error_skip_all" if !app.get_folder_operation_confirm_acl() => 2,
                    "error_retry_finder" if app.get_folder_operation_finder_retry() => 4, _ => 3 };
                ERROR_DECISION.store(d, Ordering::SeqCst);
                app.set_folder_operation_pause("".into());
            }
            return;
        }
        if app.get_folder_compare_busy() || app.get_folder_relations_busy() { return; }
        if !current_inputs_match_session(&app) {
            reset();
            app.set_folder_compare_has_report(false);
            set_audit_rows(&app, Vec::new());
            app.set_folder_audit_selected(-1);
            app.set_folder_audit_page_info("Auswahl geändert – erneute Prüfung erforderlich".into());
            update_metrics(&app);
            app.set_folder_compare_status("A, B oder Filter wurden seit dem letzten Audit geändert. Vor einer Dateiaktion bitte 'Inhalte prüfen' erneut ausführen.".into());
            return;
        }
        // Selection is stored by global entry index, not by current page row.
        if action.starts_with("filter:") || matches!(action.as_str(),
            "group_prev" | "group_next" | "toggle" | "select_page" | "select_all" | "clear_selection" | "select_merge_to_b" | "select_merge_to_a" | "load_more" | "prev" | "next") ||
            action.starts_with("scope:") || action.starts_with("select_scope:") {
            if app.get_folder_compare_busy() { return; }
            if let Ok(mut guard) = SESSION.lock() {
                if let Some(session) = guard.as_mut() {
                    if action == "group_prev" || action == "group_next" {
                        let (start, _) = group_page_bounds(session);
                        let page = start/40;
                        session.group_page = if action == "group_prev" { page.saturating_sub(1) } else { (page+1).min(session.groups.len().max(1).div_ceil(40)-1) };
                    } else if let Some(filter) = action.strip_prefix("filter:") {
                        session.filter = filter.to_owned(); session.page = 0; session.display_limit = INITIAL_VISIBLE;
                    } else if let Some(scope) = action.strip_prefix("scope:") {
                        session.scope = if scope == "all" { String::new() } else { scope.to_owned() };
                        session.page = 0; session.display_limit = INITIAL_VISIBLE;
                    } else if let Some(scope) = action.strip_prefix("select_scope:") {
                        // Select only actionable A entries. Unknown/conflicting files are never auto-selected.
                        let candidates: Vec<usize> = session.entries.iter().enumerate()
                            .filter(|(_,e)| e.a.as_deref().is_some_and(|a| folder_group(a, &session.a) == scope)
                                && matches!(e.kind, Kind::Same | Kind::OnlyA))
                            .map(|(i,_)| i).collect();
                        let all_selected = candidates.iter().all(|i| session.selected.contains(i));
                        for i in candidates { if all_selected { session.selected.remove(&i); } else { session.selected.insert(i); } }
                    } else if matches!(action.as_str(), "load_more" | "next" | "prev") {
                        let len = visible_indices(session).len();
                        let size = session.display_limit.clamp(1,PAGE);
                        let max_page = len.max(1).div_ceil(size).saturating_sub(1);
                        let current = session.page.min(max_page);
                        session.page = if action == "prev" { current.saturating_sub(1) } else { (current+1).min(max_page) };
                    } else if action == "clear_selection" {
                        session.selected.clear();
                    } else if action == "select_merge_to_b" || action == "select_merge_to_a" {
                        let target_kind = if action == "select_merge_to_b" { Kind::OnlyA } else { Kind::OnlyB };
                        session.filter = if target_kind == Kind::OnlyA { "only_a".into() } else { "only_b".into() };
                        session.page = 0;
                        session.selected = session.entries.iter().enumerate()
                            .filter(|(_, entry)| entry.kind == target_kind).map(|(i, _)| i).collect();
                    } else {
                        let shown = visible_indices(session);
                        let (start,end) = page_bounds(session,shown.len());
                        let page_items = shown[start..end].to_vec();
                        match action.as_str() {
                            "toggle" => {
                                if let Ok(row) = usize::try_from(index) {
                                    if let Some(&i) = page_items.get(row) {
                                        if !session.selected.insert(i) { session.selected.remove(&i); }
                                    }
                                }
                            }
                            "select_page" => { session.selected.extend(page_items); }
                            "select_all" => { session.selected.extend(shown.iter().copied()); }
                            _ => {}
                        }
                    }
                }
            }
            refresh_selection(&weak);
            return;
        }
        if action == "verify_conflicts" {
            if app.get_folder_compare_busy() { return; }
            let (batch, a, b) = match conflict_batch() {
                Ok(value) => value, Err(e) => { app.set_folder_compare_status(e.into()); return; }
            };
            if batch.is_empty() { app.set_folder_compare_status("Keine Konflikte vorhanden.".into()); return; }
            BATCH_STOP.store(false, Ordering::Relaxed);
            app.set_folder_compare_busy(true);
            let weak = app.as_weak();
            thread::spawn(move || {
                let total = batch.len();
                let mut identical = Vec::new();
                let mut different = Vec::new();
                let mut errors = Vec::new();
                for (number, (index, entry)) in batch.into_iter().enumerate() {
                    if BATCH_STOP.load(Ordering::Relaxed) { break; }
                    if number % 10 == 0 { ui_message(&weak, format!("Prüfe Konflikte {} / {total} ...", number + 1)); }
                    let (Some(left), Some(right)) = (entry.a.as_deref(), entry.b.as_deref()) else { continue };
                    match verify_pair(&a, &b, left, right) {
                        Ok(true) => identical.push(index),
                        Ok(false) => different.push(index),
                        Err(e) => { if errors.len() < 16 { errors.push(format!("{}: {e}", left.display())); } },
                    }
                }
                let n_equal = identical.len();
                let n_different = different.len();
                if let Ok(mut guard) = SESSION.lock() {
                    if let Some(session) = guard.as_mut() {
                        session.groups_dirty = true; session.visible_cache.get_mut().take(); session.counts_cache.set(None);
                        for index in identical {
                            if let Some(entry) = session.entries.get_mut(index) {
                                if entry.kind == Kind::Conflict { entry.kind = Kind::Same; entry.checked_conflict = false; entry.fast_proof = None; }
                            }
                            session.selected.remove(&index);
                        }
                        for index in different {
                            if let Some(entry) = session.entries.get_mut(index) {
                                if entry.kind == Kind::Conflict { entry.checked_conflict = true; }
                            }
                            session.selected.remove(&index);
                        }
                    }
                }
                let stopped = BATCH_STOP.load(Ordering::Relaxed);
                let _ = weak.upgrade_in_event_loop(move |app| {
                    refresh_selection(&app.as_weak());
                    app.set_folder_compare_busy(false);
                    app.set_folder_compare_status(format!(
                        "Konflikte geprüft: {n_equal} byte-identisch, {n_different} tatsächlich verschieden, {} Fehler. {}{}",
                        errors.len(), if stopped { "Abgebrochen. " } else { "" }, errors.join(" | ")).into());
                });
            });
            return;
        }
        if action == "verify_selected" {
            if app.get_folder_compare_busy() { return; }
            let (batch, a, b) = match selected_batch(Kind::Same) {
                Ok(out) => out, Err(e) => { app.set_folder_compare_status(e.into()); return; }
            };
            if batch.is_empty() { app.set_folder_compare_status("Keine ausgewählten Zeilen mit Status 'Identisch'.".into()); return; }
            BATCH_STOP.store(false, Ordering::Relaxed);
            app.set_folder_compare_busy(true);
            let weak = app.as_weak();
            thread::spawn(move || {
                let total = batch.len();
                let (mut confirmed, mut differing, mut errors) = (0usize, Vec::new(), Vec::new());
                for (number, (index, entry)) in batch.into_iter().enumerate() {
                    if BATCH_STOP.load(Ordering::Relaxed) { break; }
                    if number % 20 == 0 { ui_message(&weak, format!("Byteweise Prüfung {} / {total} ...", number + 1)); }
                    match verify_pair(&a, &b, entry.a.as_deref().expect("same a"), entry.b.as_deref().expect("same b")) {
                        Ok(true) => confirmed += 1,
                        Ok(false) => differing.push(index),
                        Err(e) => if errors.len() < 8 { errors.push(e); },
                    }
                }
                let differing_count = differing.len();
                if let Ok(mut guard) = SESSION.lock() {
                    if let Some(session) = guard.as_mut() {
                        // Gleicher Hash im Index, aber andere Bytes jetzt: als Konflikt anzeigen und aus der Auswahl nehmen.
                        session.groups_dirty = true; session.visible_cache.get_mut().take(); session.counts_cache.set(None);
                        for index in differing { if let Some(entry) = session.entries.get_mut(index) { entry.kind = Kind::Conflict; entry.checked_conflict = true; entry.fast_proof = None; } session.selected.remove(&index); }
                    }
                }
                let stopped = BATCH_STOP.load(Ordering::Relaxed);
                let _ = weak.upgrade_in_event_loop(move |app| {
                    refresh_selection(&app.as_weak());
                    app.set_folder_compare_busy(false);
                    app.set_folder_compare_status(format!("Byteweise geprüft, nichts verändert: {confirmed} identisch, {differing_count} abweichend (jetzt Konflikt), {} nicht lesbar. {}{}",
                        errors.len(), if stopped { "Vorgang abgebrochen. " } else { "" }, errors.join(" | ")).into());
                });
            });
            return;
        }
        let operation = action.split(':').next().unwrap_or("");
        if matches!(action.as_str(), "merge_selected" | "merge_selected_a_to_b" | "merge_selected_b_to_a" | "move_selected_a_to_b" | "move_selected_b_to_a" | "move_selected_a_to_b:acl" | "move_selected_b_to_a:acl") || action.starts_with("trash_selected:") || matches!(operation, "force_delete_selected" | "finder_retry_selected" | "backup_acl_trash_selected") {
            if app.get_folder_compare_busy() { return; }
            let merge_to_a = matches!(operation, "merge_selected_b_to_a" | "move_selected_b_to_a");
            let is_move = matches!(operation, "move_selected_a_to_b" | "move_selected_b_to_a");
            let is_merge = is_move || matches!(action.as_str(), "merge_selected" | "merge_selected_a_to_b" | "merge_selected_b_to_a");
            let permanent = operation == "force_delete_selected";
            let finder_retry = operation == "finder_retry_selected";
            let backup_acl = operation == "backup_acl_trash_selected" || (is_move && action.ends_with(":acl"));
            let mode = if is_merge { TrashCheckMode::Bytes } else {
                let Some(mode) = removal_check_mode(action.as_str()) else {
                    app.set_folder_compare_status("Ungültiger Prüfmodus. Keine Papierkorbaktion.".into()); return;
                };
                mode
            };
            let target_kind = if merge_to_a { Kind::OnlyB } else if is_merge { Kind::OnlyA } else { Kind::Same };
            let (batch, a, b) = match selected_batch(target_kind) {
                Ok(out) => out, Err(e) => { app.set_folder_compare_status(e.into()); return; }
            };
            if batch.is_empty() { app.set_folder_compare_status("Keine geeigneten ausgewählten Dateien vorhanden.".into()); return; }
            if finder_retry && batch.len() != 1 { app.set_folder_compare_status("Finder-Admin-Wiederholung: genau ein identisches Dateipaar auswählen.".into()); return; }
            let (report_path, mut report) = match new_operation_report() {
                Ok(v) => v, Err(e) => { app.set_folder_compare_status(format!("Kein Fehlerbericht möglich; nichts ausgeführt: {}", io_detail(e)).into()); return; }
            };
            let total = batch.len();
            if report_line(&mut report, &format!("Krokiet v22.5 | Aktion: {action} | Prüfung: {} | {total} Dateien\nA: {:?}\nB: {:?}", mode.label(),a,b)).is_err() {
                app.set_folder_compare_status("Fehlerbericht nicht beschreibbar; nichts ausgeführt".into()); return;
            }
            app.set_folder_operation_report(report_path.to_string_lossy().into_owned().into());
            app.set_folder_operation_pause("".into());
            app.set_folder_operation_confirm_acl(false);
            BATCH_STOP.store(false, Ordering::Relaxed);
            app.set_folder_compare_busy(true);
            let weak = app.as_weak();
            thread::spawn(move || {
                crate::folder_diagnostics::checkpoint(&format!("OPERATION start: {total} files"));
                let mut policy = ErrorPolicy::new();
                if is_merge && report_line(&mut report,"Übertragung: relative Quellpfade, kein Überschreiben; macOS cp -p übernimmt verbleibende ACLs und xattrs. ACL-Option ändert nur den Quell-Löschschutz, nicht übrige Rechte. Bei Abbruch BEGIN/ZIEL VERIFIZIERT/OK abgleichen, frisch vergleichen.").is_err() {
                    BATCH_STOP.store(true, Ordering::Relaxed);
                }
                #[cfg(target_os = "macos")]
                for root in [&a,&b] {
                    if let Ok(rel) = root.strip_prefix("/Volumes") {
                        if let Some(component) = rel.components().next() {
                            let volume = Path::new("/Volumes").join(component.as_os_str());
                            if report_line(&mut report, &format!("Volume-/Papierkorb-Metadaten:{}{}", failure_diagnostics(&volume), failure_diagnostics(&volume.join(".Trashes")))).is_err() { BATCH_STOP.store(true, Ordering::Relaxed); }
                            if let Ok(out) = Command::new("/usr/sbin/diskutil").arg("info").arg(&volume).output() {
                                if report_line(&mut report, &format!("VOLUME {:?}:\n{}{}",volume,String::from_utf8_lossy(&out.stdout),String::from_utf8_lossy(&out.stderr))).is_err() { BATCH_STOP.store(true, Ordering::Relaxed); }
                            }
                        }
                    }
                }
                let mut ok = 0usize;
                let mut changes = Vec::<crate::folder_relations::ManualChange>::new();
                let mut failed_count = 0usize;
                let preflight = if is_move || !is_merge {
                    ui_message(&weak, "Prüfe Ordnergrenzen und Symlinks in A und B ...".to_owned());
                    link_preflight(&a, &b)
                } else { checked_roots(&a, &b).map(|()| LinkPreflight::default()) };
                let links = match preflight {
                    Ok(links) => links,
                    Err(reason) => {
                        let _ = report_line(&mut report, &format!("ABBRUCH Vorabprüfung: {reason}"));
                        let _ = weak.upgrade_in_event_loop(move |app| {
                            app.set_folder_compare_busy(false);
                            app.set_folder_compare_status(format!("Nichts ausgeführt: {reason}").into());
                        });
                        return;
                    }
                };
                let link_warning = links.warning();
                if !link_warning.is_empty() {
                    if report_line(&mut report, &link_warning).is_err() || await_error_decision(&weak, format!("{link_warning}\nTrotz unvollständiger Linkprüfung fortfahren?"), false) == 3 {
                        BATCH_STOP.store(true, Ordering::Relaxed);
                    }
                }
                // Screen selected paths without modifying anything. Actual content and
                // safety checks are repeated immediately before the real operation.
                let mut eligible = Vec::new();
                let mut screened = 0usize;
                for (index, entry) in batch {
                    if BATCH_STOP.load(Ordering::Relaxed) { break; }
                    screened += 1;
                    let (from,to,src) = if merge_to_a { (&b,&a,entry.b.as_deref().expect("only-b")) }
                        else { (&a,&b,entry.a.as_deref().expect("source-a")) };
                    let check = (|| -> Result<(), String> {
                        let meta = checked_regular(src, from)?;
                        File::open(src).map_err(|e| format!("Quelle öffnen: {}",io_detail(e)))?;
                        if is_move || !is_merge { links.check_path(src)?; }
                        if is_merge { preview_destination(to, src.strip_prefix(from).map_err(|e| e.to_string())?)?; }
                        else {
                            let right = entry.b.as_deref().expect("same-b");
                            let target = checked_regular(right, to)?;
                            File::open(right).map_err(|e| format!("Vergleich öffnen {:?}: {}",right,io_detail(e)))?;
                            if meta.len() != target.len() { return Err("Dateigrößen unterscheiden sich".into()); }
                            verify_mac_extra(src, right, false)?;
                        }
                        Ok(())
                    })();
                    match check {
                        Ok(()) => eligible.push((index,entry)),
                        Err(e) => {
                            failed_count += 1;
                            if report_line(&mut report, &format!("VORAB AUSGESCHLOSSEN {:?}: {e}{}", src, failure_diagnostics(src))).is_err() {
                                BATCH_STOP.store(true, Ordering::Relaxed); break;
                            }
                        }
                    }
                    if screened % 100 == 0 { ui_message(&weak, format!("Vorabprüfung {screened}/{total}")); }
                }
                if failed_count > 0 && !eligible.is_empty() && !BATCH_STOP.load(Ordering::Relaxed) {
                    match await_error_decision(&weak, format!("Vorabprüfung: {failed_count} Dateien ausgeschlossen. {} übrige Dateien versuchen? Details im Dateioperationsbericht.", eligible.len()), false) {
                        2 => policy.skip_all = true,
                        3 => BATCH_STOP.store(true, Ordering::Relaxed),
                        _ => {},
                    }
                }
                let mut batch = eligible;
                if backup_acl && !batch.is_empty() && !BATCH_STOP.load(Ordering::Relaxed) {
                    let mut acl_excluded = BTreeSet::new();
                    // Orient the plan towards the source without cloning the entire batch.
                    let (from,to) = if merge_to_a { (&b,&a) } else { (&a,&b) };
                    let result = prepare_backup_acl_batch(&weak,&mut report,&report_path,from,to,&batch,&links,mode,&mut acl_excluded,is_move,merge_to_a);
                    if !acl_excluded.is_empty() {
                        let before = batch.len();
                        batch.retain(|(index,_)| !acl_excluded.contains(index));
                        let excluded = before - batch.len();
                        failed_count += excluded;
                        if report_line(&mut report,&format!("ACL: {excluded} Dateien ausgeschlossen, {} verbleibend",batch.len())).is_err() {
                            BATCH_STOP.store(true, Ordering::Relaxed);
                        }
                        if result.is_ok() && !batch.is_empty() && !BATCH_STOP.load(Ordering::Relaxed)
                            && await_error_decision(&weak,format!("ACL-Vorabprüfung: {excluded} Dateien ausgeschlossen. {} übrige Dateien versuchen?",batch.len()),false) == 3 {
                            BATCH_STOP.store(true, Ordering::Relaxed);
                        }
                    }
                    if let Err(reason) = result {
                        if report_line(&mut report,&format!("ACL ABBRUCH: {reason}")).is_err() { BATCH_STOP.store(true, Ordering::Relaxed); }
                        // Never silently fall back to the regular trash after a failed or cancelled authorization.
                        if !batch.is_empty() && !BATCH_STOP.load(Ordering::Relaxed) {
                            if await_error_decision(&weak,format!("{reason}\n{} übrige Dateien ohne weitere ACL-Änderung versuchen?",batch.len()),false) == 3 { BATCH_STOP.store(true, Ordering::Relaxed); }
                        }
                    }
                }
                let remaining_total = batch.len();
                let mut only_copied = 0usize;
                if is_merge {
                    for (number, (index, entry)) in batch.into_iter().enumerate() {
                        if BATCH_STOP.load(Ordering::Relaxed) { break; }
                        if number % 10 == 0 { ui_message(&weak, format!("{} {} / {total} ...", if is_move { "Verschiebe" } else { "Kopiere" }, number+1)); }
                        let src = if merge_to_a { entry.b.as_deref().expect("only-b") } else { entry.a.as_deref().expect("only-a") };
                        let (from,to) = if merge_to_a { (&b,&a) } else { (&a,&b) };
                        let prior_ok = ok;
                        let relative = match src.strip_prefix(from) {
                            Ok(rel) => rel,
                            Err(e) => { failed_count+=1; if !policy.failed(&weak,&mut report,src,&e.to_string(),remaining_total-number-1) { break; } continue; }
                        };
                        let planned_dest = to.join(relative);
                        if report_line(&mut report, &format!("BEGIN {:?} -> {:?}",src,planned_dest)).is_err() { BATCH_STOP.store(true, Ordering::Relaxed); break; }
                        if is_move {
                            let staged = links.check_path(src).and_then(|()| stage_move(from,to,src));
                            match staged {
                                Ok(MoveStage::Moved(dest)) => {
                                    changes.push(crate::folder_relations::ManualChange::Moved { source:src.to_owned(), destination:dest.clone() });
                                    update_session_moved(index,dest,merge_to_a); ok+=1;
                                }
                                Ok(MoveStage::PendingTrash(dest)) => {
                                    // Record the verified destination before any source removal. If logging
                                    // fails, leave both paths intact and do not proceed to trash.
                                    let recorded = report_line(&mut report,&format!("ZIEL VERIFIZIERT {:?} -> {:?}",src,dest));
                                    if recorded.is_err() { BATCH_STOP.store(true, Ordering::Relaxed); }
                                    let removed = (|| -> Result<(), String> {
                                        if BATCH_STOP.load(Ordering::Relaxed) { return Err("Abgebrochen; Quelle bleibt".into()); }
                                        checked_roots(&a, &b)?;
                                        links.check_path(src)?;
                                        preflight_trash_pair_with_mode(from,to,src,&dest,TrashCheckMode::Bytes,None)?;
                                        verify_mac_extra(src, &dest, true)?;
                                        remove_verified_source(src, false, false).map_err(|e| format!("Entfernen: {e}"))
                                    })();
                                    let mut already_prompted = false;
                                    let removed = match removed {
                                        Err(e) if !BATCH_STOP.load(Ordering::Relaxed) && fs::symlink_metadata(src).is_ok()
                                            && cfg!(target_os = "macos") && e.starts_with("Entfernen: ") => {
                                            let reason = format!("Ziel verifiziert, Quelle nicht entfernt: {e}");
                                            already_prompted = true;
                                            let decision = policy.decide(&weak,&mut report,src,&reason,remaining_total-number-1,true);
                                            if decision == 4 {
                                                if report_line(&mut report,&format!("FINDER WIEDERHOLUNG MOVE {:?}",src)).is_err() {
                                                    BATCH_STOP.store(true, Ordering::Relaxed);
                                                    Err("Fehlerbericht nicht beschreibbar".into())
                                                } else {
                                                    let retry = (|| -> Result<(), String> {
                                                        preflight_trash_pair_with_mode(from,to,src,&dest,TrashCheckMode::Bytes,None)?;
                                                        verify_mac_extra(src,&dest,true)?;
                                                        links.check_path(src)?;
                                                        if BATCH_STOP.load(Ordering::Relaxed) { return Err("Abgebrochen".into()); }
                                                        remove_verified_source(src,false,true)
                                                    })();
                                                    if let Err(ref err) = retry {
                                                        let _ = report_line(&mut report,&format!("FINDER MOVE FEHLER {:?}: {err}",src));
                                                    }
                                                    retry
                                                }
                                            } else { Err(e) }
                                        }
                                        other => other,
                                    };
                                    match removed {
                                        Ok(()) => {
                                            changes.push(crate::folder_relations::ManualChange::Moved { source:src.to_owned(), destination:dest.clone() });
                                            update_session_moved(index,dest,merge_to_a); ok+=1;
                                        }
                                        Err(e) => {
                                            failed_count+=1;
                                            let reason = format!("Quelle nicht bestätigt entfernt: {e}");
                                            if preflight_trash_pair_with_mode(from,to,src,&dest,TrashCheckMode::Bytes,None).is_ok() {
                                                only_copied+=1;
                                                let _ = report_line(&mut report, &format!("NUR KOPIERT {:?} -> {:?}",src,dest));
                                                changes.push(crate::folder_relations::ManualChange::Copied { source:src.to_owned(), destination:dest.clone() });
                                                update_session_copied(index,dest,merge_to_a);
                                            } else {
                                                // Do not assert equality after a concurrent change or ambiguous source status.
                                                let _ = report_line(&mut report, &format!("STATUS UNKLAR {:?} -> {:?}: bitte neu prüfen", src, dest));
                                            }
                                            if already_prompted {
                                                if report_line(&mut report,&format!("MOVE NICHT ABGESCHLOSSEN {:?}: {reason}",src)).is_err() { BATCH_STOP.store(true, Ordering::Relaxed); }
                                                if BATCH_STOP.load(Ordering::Relaxed) { break; }
                                            } else if !policy.failed(&weak, &mut report, src, &reason, remaining_total-number-1) { break; }
                                        }
                                    }
                                }
                                Err(e) => { failed_count+=1; if !policy.failed(&weak, &mut report, src, &e, remaining_total-number-1) { break; } }
                            }
                        } else {
                            match copy_missing(from,to,src) {
                                Ok((dest,_)) => {
                                    changes.push(crate::folder_relations::ManualChange::Copied { source:src.to_owned(), destination:dest.clone() });
                                    update_session_copied(index,dest,merge_to_a); ok+=1;
                                }
                                Err(e) => { failed_count+=1; if !policy.failed(&weak, &mut report, src, &e, remaining_total-number-1) { break; } }
                            }
                        }
                        if ok > prior_ok { policy.success(); if report_line(&mut report, &format!("OK {:?} -> {:?}",src,planned_dest)).is_err() { BATCH_STOP.store(true, Ordering::Relaxed); break; } }
                    }
                } else {
                    // Verify and remove one file at a time. No large argv, stale verified list,
                    // or shared failure can prevent unrelated files from being attempted.
                    for (number, (index, entry)) in batch.into_iter().enumerate() {
                        if BATCH_STOP.load(Ordering::Relaxed) { break; }
                        if number % 10 == 0 { ui_message(&weak, format!("{}: {} / {total} ...", mode.label(), number + 1)); }
                        let left = entry.a.as_deref().expect("same a");
                        let right = entry.b.as_deref().expect("same b");
                        if report_line(&mut report, &format!("BEGIN {:?} | geprüft gegen {:?}",left,right)).is_err() { BATCH_STOP.store(true, Ordering::Relaxed); break; }
                        let outcome = verified_remove_pair(&a, &b, left, right, mode, entry.fast_proof, &links, permanent, finder_retry);
                        let outcome: Result<(), String> = match outcome {
                            Ok(()) => Ok(()),
                            Err(e) => {
                                let can_retry = cfg!(target_os = "macos") && !permanent && !finder_retry && e.starts_with("Entfernen: ") && fs::symlink_metadata(left).is_ok();
                                let decision = policy.decide(&weak,&mut report,left,&e,remaining_total-number-1,can_retry);
                                if decision == 4 {
                                    if report_line(&mut report, &format!("FINDER WIEDERHOLUNG {:?}",left)).is_err() { BATCH_STOP.store(true, Ordering::Relaxed); failed_count += 1; break; }
                                    // Finder may request admin authorization. Recheck with the selected mode and extra data first.
                                    match verified_remove_pair(&a,&b,left,right,mode,entry.fast_proof,&links,false,true) {
                                        Ok(()) => Ok(()),
                                        Err(retry_error) => {
                                            failed_count += 1;
                                            if !policy.failed(&weak,&mut report,left,&format!("Finder-Wiederholung: {retry_error}"),remaining_total-number-1) { break; }
                                            continue;
                                        }
                                    }
                                } else {
                                    failed_count += 1;
                                    if decision == 3 { break; }
                                    continue;
                                }
                            }
                        };
                        match outcome {
                            Ok(()) => {
                                changes.push(crate::folder_relations::ManualChange::Trashed(left.to_owned()));
                                // Only update the row here, rebuild the visible model once after the batch.
                                update_session_trashed(index); ok += 1; policy.success();
                                if report_line(&mut report, &format!("OK {:?}",left)).is_err() { BATCH_STOP.store(true, Ordering::Relaxed); break; }
                            }
                            Err(e) => { failed_count += 1; if !policy.failed(&weak, &mut report, left, &e, remaining_total-number-1) { break; } }
                        }
                    }
                }
                if !changes.is_empty() {
                    ui_message(&weak, format!("Merke {} Indexänderungen vor (kein Neuaufbau) ...", changes.len()));
                    crate::folder_relations::apply_manual_changes(&weak, changes);
                }
                warm_session_cache();
                let stopped = BATCH_STOP.load(Ordering::Relaxed);
                crate::folder_diagnostics::checkpoint(&format!("OPERATION worker done: {ok} successful; {failed_count} failed; {only_copied} copied-only"));
                let report_ok = report_line(&mut report, &format!("ENDE: {ok} erfolgreich; {failed_count} fehlgeschlagen; {} ausstehend; {only_copied} nur kopiert; gestoppt={stopped}", total.saturating_sub(ok+failed_count))).is_ok();
                let _ = weak.upgrade_in_event_loop(move |app| {
                    crate::folder_diagnostics::event("GUI operation completion begin");
                    refresh_selection(&app.as_weak());
                    crate::folder_diagnostics::event("GUI operation model updated");
                    app.set_folder_operation_pause("".into());
                    app.set_folder_operation_confirm_acl(false);
                    app.set_folder_compare_busy(false);
                    app.set_folder_compare_status(format!("{} {ok} Dateien erfolgreich; {failed_count} nicht durchgeführt; {} nicht bearbeitet. {}{}.{}{}",
                        if is_move { "Verschoben:".to_owned() } else if is_merge { "Kopiert und geprüft:".to_owned() } else if permanent { "Endgültig gelöscht:".to_owned() } else { format!("In Papierkorb verschoben ({}):", mode.label()) },
                        total.saturating_sub(ok + failed_count), if stopped { "Abgebrochen. " } else { "" }, if report_ok { "Details: Fehlerbericht öffnen" } else { "Fehlerbericht unvollständig (Schreibfehler)" },
                        if is_move { format!(" {only_copied} nur kopiert, Quelle weiterhin vorhanden. Bitte Teilergebnisse prüfen.") } else if is_merge { "".to_owned() } else { "".to_owned() }, if link_warning.is_empty() { "" } else { " Linkprüfung unvollständig; siehe Bericht." }).into());
                });
            });
            return;
        }
        if action == "finder_folder_a" || action == "finder_folder_b" {
            let paths = SESSION.lock().ok().and_then(|session| session.as_ref().map(|s| (s.a.clone(), s.b.clone())));
            let result = paths.ok_or("Bitte zuerst vergleichen".to_owned()).and_then(|(a, b)| {
                checked_roots(&a, &b)?;
                show_file(if action == "finder_folder_a" { &a } else { &b }, false)
            });
            if let Err(error) = result { ui_message(&weak, error); }
            return;
        }
        let (entry, a, b, global) = match selected(index) {
            Ok(value) => value,
            Err(error) => { ui_message(&weak, error); return; }
        };
        if action == "preview_a" || action == "preview_b" || action == "finder_a" || action == "finder_b" {
            let path = if action.ends_with("_a") { entry.a.as_deref() } else { entry.b.as_deref() };
            let root = if action.ends_with("_a") { &a } else { &b };
            let outcome = path.ok_or("Für diese Seite gibt es keine Datei".to_owned())
                .and_then(|path| checked_regular(path, root).map(|_| path))
                .and_then(|path| show_file(path, action.starts_with("preview")));
            if let Err(err) = outcome { ui_message(&weak, err); }
            return;
        }
        if !matches!(action.as_str(), "merge_one" | "trash_one_a") { ui_message(&weak, "Unbekannte Aktion".into()); return; }
        let Some(app) = weak.upgrade() else { return };
        if app.get_folder_compare_busy() { return; }
        // Note: confirmation of trash_one_a occurs in the Slint UI BEFORE calling us.
        let valid = match action.as_str() {
            "merge_one" => entry.kind == Kind::OnlyA && entry.a.is_some(),
            "trash_one_a" => entry.kind == Kind::Same && entry.a.is_some() && entry.b.is_some(),
            _ => false,
        };
        if !valid { app.set_folder_compare_status("Aktion für diese Dateizeile nicht erlaubt".into()); return; }
        app.set_folder_compare_busy(true);
        let weak = app.as_weak();
        let is_merge = action == "merge_one";
        let (path, mut report) = match new_operation_report() {
            Ok(v) => v, Err(e) => { app.set_folder_compare_busy(false); app.set_folder_compare_status(io_detail(e).into()); return; }
        };
        if report_line(&mut report, &format!("Einzelaktion {action}: {:?}", entry.a)).is_err() { app.set_folder_compare_busy(false); return; }
        app.set_folder_operation_report(path.to_string_lossy().into_owned().into());
        BATCH_STOP.store(false, Ordering::Relaxed);
        thread::spawn(move || {
            let result: Result<(String, Option<PathBuf>), String> = if is_merge {
                copy_missing(&a, &b, entry.a.as_deref().expect("validated")).map(|(dest, metadata_ok)| {
                    let note = if metadata_ok { "Zeitstempel und Rechte übernommen" } else { "Zeitstempel oder Rechte konnten nicht übernommen werden" };
                    (format!("Kopiert und byteweise geprüft: {} ({note}; macOS: Quell-xattrs geprüft; andere Plattformen: Zusatzattribute nicht kopiert).", dest.display()), Some(dest))
                })
            } else {
                trash_identical_a(&a, &b, entry.a.as_deref().expect("validated"), entry.b.as_deref().expect("validated"))
                    .map(|()| ("Eine ausdrücklich ausgewählte Datei aus A in den Papierkorb verschoben.".to_owned(), None))
            };
            match result {
                Ok((message, destination)) => {
                    let _ = report_line(&mut report, &message);
                    // Die Tabelle wird nur an dieser einen Zeile angepasst. Jede Aktion prüft beim Ausführen selbst
                    // erneut (Neuanlage ohne Überschreiben bzw. frischer Bytevergleich), daher ist kein Komplett-Scan nötig.
                    let change = match &destination {
                        Some(dest) => crate::folder_relations::ManualChange::Copied {
                            source: entry.a.as_ref().expect("valid source").clone(),
                            destination: dest.clone(),
                        },
                        None => crate::folder_relations::ManualChange::Trashed(
                            entry.a.as_ref().expect("valid source").clone(),
                        ),
                    };
                    let (rows, info) = update_session(global, destination);
                    // Reconcile just this known change; no full disk scan or hash pass.
                    crate::folder_relations::apply_manual_changes(&weak, vec![change]);
                    let _ = weak.upgrade_in_event_loop(move |app| {
                        if let Some(rows) = rows { set_audit_rows(&app, rows); }
                        app.set_folder_audit_page_info(info.into());
                        app.set_folder_audit_selected(-1);
                        update_metrics(&app);
                        app.set_folder_compare_busy(false);
                        app.set_folder_compare_status(format!("{message} Die Tabelle wurde für diese Zeile angepasst. Der gespeicherte Bericht zeigt den Stand vor der Aktion.").into());
                    });
                }
                Err(err) => {
                    let _ = report_line(&mut report, &format!("FEHLER {err}{}", entry.a.as_deref().map(failure_diagnostics).unwrap_or_default()));
                    let _ = weak.upgrade_in_event_loop(move |app| {
                        app.set_folder_compare_busy(false);
                        app.set_folder_compare_status(format!("Aktion nicht durchgeführt: {err}").into());
                    });
                }
            }
        });
    });
}

/// Update just the copied row, not the entire paginated model for each file.
/// Direction is explicit and the source remains intact in both cases.
fn update_session_copied(global: usize, destination: PathBuf, from_b: bool) {
    if let Ok(mut guard) = SESSION.lock() {
        if let Some(session) = guard.as_mut() {
            if let Some(entry) = session.entries.get_mut(global) {
                session.groups_dirty = true; session.visible_cache.get_mut().take(); session.counts_cache.set(None);
                if from_b && entry.kind == Kind::OnlyB && entry.b.is_some() {
                    entry.a = Some(destination);
                    entry.kind = Kind::Same;
                    entry.fast_proof = None;
                    session.selected.remove(&global);
                } else if !from_b && entry.kind == Kind::OnlyA && entry.a.is_some() {
                    entry.b = Some(destination);
                    entry.kind = Kind::Same;
                    entry.fast_proof = None;
                    session.selected.remove(&global);
                }
            }
        }
    }
}

/// On successful MOVE the source disappears and the target remains on the other side.
fn update_session_moved(index:usize, target:PathBuf, from_b:bool) {
    if let Ok(mut lock)=SESSION.lock() { if let Some(s)=lock.as_mut() {
        s.groups_dirty = true; s.visible_cache.get_mut().take(); s.counts_cache.set(None);
        if let Some(e)=s.entries.get_mut(index) {
            if from_b && e.kind==Kind::OnlyB && e.b.is_some() { e.b=None; e.a=Some(target); e.kind=Kind::OnlyA; s.selected.remove(&index); }
            else if !from_b && e.kind==Kind::OnlyA && e.a.is_some() { e.a=None; e.b=Some(target); e.kind=Kind::OnlyB; s.selected.remove(&index); }
            e.fast_proof=None;
        }
    }}
}

fn update_session_trashed(index: usize) {
    if let Ok(mut guard) = SESSION.lock() { if let Some(session) = guard.as_mut() {
        if let Some(entry) = session.entries.get_mut(index) {
            entry.a = None; entry.kind = Kind::OnlyB; entry.fast_proof = None;
        }
        session.selected.remove(&index); session.groups_dirty = true; session.visible_cache.get_mut().take(); session.counts_cache.set(None);
    }}
}

/// Passt genau eine Zeile an: Merge macht aus "Nur in A" ein "Identisch", Papierkorb macht aus "Identisch" ein "Nur in B".
fn update_session(global: usize, destination: Option<PathBuf>) -> (Option<Vec<Vec<String>>>, String) {
    let Ok(mut guard) = SESSION.lock() else { return (None, "Tabelle nicht aktualisiert".to_owned()) };
    let Some(session) = guard.as_mut() else { return (None, "Tabelle nicht aktualisiert".to_owned()) };
    if let Some(entry) = session.entries.get_mut(global) {
        match destination {
            Some(dest) => { entry.b = Some(dest); entry.kind = Kind::Same; entry.fast_proof = None; }
            None => { entry.a = None; entry.kind = Kind::OnlyB; entry.fast_proof = None; }
        }
    }
    session.selected.remove(&global);
    session.groups_dirty = true; session.visible_cache.get_mut().take(); session.counts_cache.set(None);
    let (rows, info) = page_rows(session);
    (Some(rows), info)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicU64, Ordering as AO};
    static NEXT: AtomicU64 = AtomicU64::new(0);
    #[test]
    fn v221_destination_preview_does_not_create_folders() {
        let f = Fixture::new();
        assert!(preview_destination(&f.b, Path::new("missing/sub/file")).is_ok());
        assert!(!f.b.join("missing").exists());
        fs::write(f.b.join("exists"), b"x").unwrap();
        assert!(preview_destination(&f.b, Path::new("exists")).is_err());
    }
    #[cfg(target_os = "macos")]
    #[test]
    fn v221_finder_info_difference_blocks_duplicate_removal() {
        let f = Fixture::new();
        let a = f.a.join("icon"); let b = f.b.join("icon");
        fs::write(&a,b"same").unwrap(); fs::write(&b,b"same").unwrap();
        let out = Command::new("/usr/bin/xattr").args(["-wx", "com.apple.FinderInfo", "5445585474747874000000000000000000000000000000000000000000000000"]).arg(&a).output().unwrap();
        assert!(out.status.success(), "{}", String::from_utf8_lossy(&out.stderr));
        assert!(verify_mac_extra(&a,&b,false).is_err());
        assert!(a.exists() && b.exists());
    }
    struct Fixture { root: PathBuf, a: PathBuf, b: PathBuf }
    impl Fixture {
        fn new() -> Self {
            let root = std::env::temp_dir().join(format!("krokiet_merge_{}_{}", std::process::id(), NEXT.fetch_add(1, AO::SeqCst)));
            let a = root.join("A"); let b = root.join("B");
            fs::create_dir_all(&a).unwrap(); fs::create_dir_all(&b).unwrap();
            Self { root, a, b }
        }
    }
    impl Drop for Fixture { fn drop(&mut self) { let _ = fs::remove_dir_all(&self.root); } }
    #[cfg(unix)] #[test]
    fn v19_move_same_filesystem_removes_original_without_overwrite() {
        let f=Fixture::new(); let src=f.a.join("x"); fs::write(&src,b"important").unwrap();
        let before=fs::metadata(&src).unwrap();
        let MoveStage::Moved(dst)=stage_move(&f.a,&f.b,&src).unwrap() else { panic!("expected move") };
        assert!(!src.exists()); assert_eq!(fs::read(&dst).unwrap(),b"important");
        assert!(same_inode(&before,&fs::metadata(dst).unwrap()));
    }
    #[test]
    fn v19_move_rejects_existing_destination_both_directions() {
        let f=Fixture::new(); fs::write(f.a.join("x"),b"A").unwrap(); fs::write(f.b.join("x"),b"B").unwrap();
        assert!(stage_move(&f.a,&f.b,&f.a.join("x")).is_err());
        assert!(stage_move(&f.b,&f.a,&f.b.join("x")).is_err());
        assert_eq!(fs::read(f.a.join("x")).unwrap(),b"A"); assert_eq!(fs::read(f.b.join("x")).unwrap(),b"B");
    }
    #[test]
    fn v19_copy_fallback_keeps_source_until_trash() {
        let f=Fixture::new(); fs::write(f.a.join("x"),b"source").unwrap();
        let MoveStage::PendingTrash(dst)=stage_move_impl(&f.a,&f.b,&f.a.join("x"),true).unwrap() else {panic!("fallback")};
        assert_eq!(fs::read(dst).unwrap(),b"source"); assert!(f.a.join("x").exists());
    }
    #[test]
    fn merge_copies_missing_and_never_overwrites() {
        let f = Fixture::new(); let source = f.a.join("Photos/a.jpg");
        fs::create_dir_all(source.parent().unwrap()).unwrap(); fs::write(&source, b"one").unwrap();
        let target = copy_missing(&f.a, &f.b, &source).unwrap().0;
        assert_eq!(fs::read(&target).unwrap(), b"one");
        assert!(copy_missing(&f.a, &f.b, &source).is_err());
        assert_eq!(fs::read(&target).unwrap(), b"one");
    }
    #[test]
    fn v18_bidirectional_merge_copy_reuses_non_overwrite_checks() {
        let f = Fixture::new();
        let from_b = f.b.join("Sounds/sample.wav");
        fs::create_dir_all(from_b.parent().unwrap()).unwrap();
        fs::write(&from_b, b"sample only in B").unwrap();
        let in_a = copy_missing(&f.b, &f.a, &from_b).unwrap().0;
        assert_eq!(fs::read(&in_a).unwrap(), b"sample only in B");
        assert_eq!(fs::read(&from_b).unwrap(), b"sample only in B");
        assert!(copy_missing(&f.b, &f.a, &from_b).is_err());
        assert_eq!(fs::read(&in_a).unwrap(), b"sample only in B");
    }
    #[test]
    fn v18_reverse_merge_rejects_colliding_a_target() {
        let f = Fixture::new();
        fs::write(f.b.join("x"), b"B source").unwrap();
        fs::write(f.a.join("x"), b"A stays").unwrap();
        assert!(copy_missing(&f.b, &f.a, &f.b.join("x")).is_err());
        assert_eq!(fs::read(f.a.join("x")).unwrap(), b"A stays");
    }
    #[test]
    fn merge_rejects_existing_different_content() {
        let f=Fixture::new(); fs::write(f.a.join("x"), b"old").unwrap(); fs::write(f.b.join("x"), b"new").unwrap();
        assert!(copy_missing(&f.a, &f.b, &f.a.join("x")).is_err());
        assert_eq!(fs::read(f.b.join("x")).unwrap(), b"new");
    }
    #[test]
    fn manual_trash_refuses_files_with_different_contents() {
        let f=Fixture::new();
        let a_file=f.a.join("match.txt"); let b_file=f.b.join("match.txt");
        fs::write(&a_file, b"version A").unwrap();
        fs::write(&b_file, b"version B").unwrap();
        assert!(trash_identical_a(&f.a, &f.b, &a_file, &b_file).is_err());
        assert!(a_file.exists());
        assert!(b_file.exists());
    }
    #[test]
    fn v20_protected_volume_system_directories_are_only_exact_root_entries() {
        assert!(is_known_volume_temp(Path::new("/Volumes/T7/.TemporaryItems")));
        assert!(is_known_volume_temp(Path::new("/Volumes/T7/.Trashes")));
        assert!(!is_known_volume_temp(Path::new("/Volumes/T7/Archive/.TemporaryItems")));
        assert!(!is_known_volume_temp(Path::new("/Volumes/T7/Archive/private")));
    }
    #[cfg(unix)]
    #[test]
    fn v20_symlink_only_preflight_still_detects_references() {
        use std::os::unix::fs::symlink;
        let f = Fixture::new();
        fs::write(f.a.join("sample.wav"), b"sample").unwrap();
        symlink(f.a.join("sample.wav"), f.b.join("remote-link")).unwrap();
        assert!(link_preflight(&f.a, &f.b).unwrap().check_path(&f.a.join("sample.wav")).is_err());
    }
    #[cfg(unix)]
    #[test]
    fn manual_trash_refuses_dependency_in_b() {
        use std::os::unix::fs::symlink;
        let f=Fixture::new();
        let a_file=f.a.join("x.txt"); let b_file=f.b.join("x.txt");
        fs::write(&a_file, b"same").unwrap(); fs::write(&b_file, b"same").unwrap();
        symlink(&a_file, f.b.join("dependent-link")).unwrap();
        assert!(trash_identical_a(&f.a, &f.b, &a_file, &b_file).is_err());
        assert!(a_file.exists());
    }
    #[cfg(unix)]
    #[test]
    fn merge_refuses_symlink_destination_directory() {
        use std::os::unix::fs::symlink;
        let f=Fixture::new(); let out=f.root.join("outside"); fs::create_dir(&out).unwrap();
        symlink(&out, f.b.join("Photos")).unwrap();
        fs::create_dir_all(f.a.join("Photos")).unwrap(); fs::write(f.a.join("Photos/x"), b"x").unwrap();
        assert!(copy_missing(&f.a, &f.b, &f.a.join("Photos/x")).is_err());
        assert!(!out.join("x").exists());
    }
    #[test]
    fn filters_and_all_selection_cover_all_pages() {
        let mk = |kind| Entry { a: Some(PathBuf::from("/A/x")), b: None, kind, checked_conflict: false, fast_proof: None };
        let mut session = Session {
            a: PathBuf::from("/A"), b: PathBuf::from("/B"),
            patterns: vec![], page: 0, filter: "only_a".into(),
            selected: BTreeSet::new(), from_index: true, scope: String::new(), display_limit: INITIAL_VISIBLE, groups: BTreeMap::new(), groups_dirty: false, visible_cache: RefCell::new(None), counts_cache: Cell::new(None), group_page: 0,
            entries: (0..250).map(|i| mk(if i % 2 == 0 { Kind::OnlyA } else { Kind::Same })).collect(),
        };
        assert_eq!(visible_indices(&session).len(), 125);
        session.selected.extend(visible_indices(&session).iter().copied());
        session.page = 1;
        let (rows, _) = page_rows(&session);
        assert_eq!(rows.len(), 5);
        assert!(rows.iter().all(|r| r[4] == "1"));
        session.filter = "different".into();
        assert_eq!(visible_indices(&session).len(), 125);
        session.filter = "same".into();
        assert_eq!(visible_indices(&session).len(), 125);
    }
    #[test]
    fn v20_scope_filters_a_and_ignores_b_only_by_default() {
        let entry = |a: Option<&str>, kind| Entry { a: a.map(PathBuf::from), b: None, kind,
            checked_conflict: false, fast_proof: None };
        let mut s = Session { a: PathBuf::from("/A"), b: PathBuf::from("/B"), patterns: vec![],
            entries: vec![entry(Some("/A/2023/kick"), Kind::Same),
                entry(Some("/A/2022/snare"), Kind::OnlyA), entry(None, Kind::OnlyB)],
            page: 0, filter: "all".into(), selected: BTreeSet::new(), from_index: true,
            scope: String::new(), display_limit: INITIAL_VISIBLE, groups: BTreeMap::new(), groups_dirty: true, visible_cache: RefCell::new(None), counts_cache: Cell::new(None), group_page: 0 };
        refresh_cached_groups(&mut s);
        assert_eq!(visible_indices(&s).as_ref(), &vec![0, 1]);
        s.scope = "2023".into();
        assert_eq!(visible_indices(&s).as_ref(), &vec![0]);
        s.filter = "only_b".into(); s.scope.clear();
        assert_eq!(visible_indices(&s).as_ref(), &vec![2]);
        let groups = subfolder_rows(&s);
        assert_eq!(groups.len(), 2);
        assert_eq!(groups[0][1], "2022");
    }

    #[test]
    fn v225_cache_reused_on_selection_and_invalidated_on_edit() {
        let mk=|i| Entry { a:Some(PathBuf::from(format!("/A/group{i}/file"))),b:None,kind:Kind::OnlyA,checked_conflict:false,fast_proof:None };
        let entries=(0..101).map(mk).collect::<Vec<_>>();
        let groups=build_group_counts(&entries,Path::new("/A"));
        let mut session=Session { a:PathBuf::from("/A"),b:PathBuf::from("/B"),patterns:vec![],entries,
            page:0,filter:"only_a".into(),selected:BTreeSet::new(),from_index:true,scope:String::new(),display_limit:INITIAL_VISIBLE,
            groups,groups_dirty:false,visible_cache:RefCell::new(None),counts_cache:Cell::new(None),group_page:0 };
        let first=visible_indices(&session); session.selected.insert(1);
        assert!(Arc::ptr_eq(&first,&visible_indices(&session)));
        assert_eq!(session_counts(&session)[2],101);
        assert_eq!(subfolder_rows(&session).len(),40);
        session.group_page=2; assert_eq!(subfolder_rows(&session).len(),21);
        session.entries[0].kind=Kind::Same; session.visible_cache.get_mut().take(); session.counts_cache.set(None);
        assert_eq!(visible_indices(&session).len(),100); assert_eq!(session_counts(&session)[2],100);
    }

    #[test]
    fn v22_4_paging_is_bounded_and_nonoverlapping() {
        let mk = |i| Entry { a: Some(PathBuf::from(format!("/A/{i}"))), b: None, kind: Kind::OnlyA, checked_conflict: false, fast_proof: None };
        let mut session = Session { a: PathBuf::from("/A"), b: PathBuf::from("/B"), patterns: vec![],
            entries: (0..301).map(mk).collect(), page:0, filter:"all".into(), selected:BTreeSet::new(),
            from_index:true, scope:String::new(),display_limit:INITIAL_VISIBLE,groups:BTreeMap::new(),groups_dirty: false, visible_cache: RefCell::new(None), counts_cache: Cell::new(None), group_page: 0 };
        assert_eq!(page_bounds(&session,301),(0,PAGE));
        session.page=1;
        assert_eq!(page_bounds(&session,301),(PAGE,2*PAGE));
        session.page=999;
        assert_eq!(page_bounds(&session,301),(2*PAGE,301));
        assert_eq!(page_bounds(&session,1),(0,1));
        assert_eq!(page_bounds(&session,0),(0,0));
    }
    #[test]
    fn v22_4_same_path_filter_excludes_other_relative_paths() {
        let mk = |a,b| Entry { a: Some(PathBuf::from(a)), b: Some(PathBuf::from(b)), kind: Kind::Same, checked_conflict: false, fast_proof: None };
        let session = Session { a:PathBuf::from("/A"), b:PathBuf::from("/B"), patterns:vec![],
            entries:vec![mk("/A/x/a.wav","/B/x/a.wav"),mk("/A/y/a.wav","/B/z/a.wav")],
            page:0,filter:"same_path".into(),selected:BTreeSet::new(),from_index:true,scope:String::new(),
            display_limit:INITIAL_VISIBLE,groups:BTreeMap::new(),groups_dirty: false, visible_cache: RefCell::new(None), counts_cache: Cell::new(None), group_page: 0 };
        assert_eq!(visible_indices(&session).as_ref(), &vec![0]);
    }
    #[test]
    fn v22_4_nested_copy_preserves_relative_paths_both_directions() {
        let f=Fixture::new();
        for (from,to,relative) in [(&f.a,&f.b,"new/sub/a.wav"),(&f.b,&f.a,"another/sub/b.wav")] {
            let source=from.join(relative);
            fs::create_dir_all(source.parent().unwrap()).unwrap();
            fs::write(&source,b"sample").unwrap();
            let dest=copy_for_move(from,to,&source).unwrap();
            assert_eq!(dest,to.join(relative));
            assert_eq!(fs::read(&dest).unwrap(),b"sample");
            assert!(source.exists());
            assert!(copy_for_move(from,to,&source).is_err());
        }
    }
    #[test]
    fn v22_3_all_removal_methods_accept_selected_mode() {
        for action in ["trash_selected", "backup_acl_trash_selected", "finder_retry_selected", "force_delete_selected"] {
            for (suffix, mode) in [("fast", TrashCheckMode::Fast), ("hash", TrashCheckMode::FreshHash), ("bytes", TrashCheckMode::Bytes)] {
                assert_eq!(removal_check_mode(&format!("{action}:{suffix}")), Some(mode));
            }
            assert_eq!(removal_check_mode(&format!("{action}:invalid")), None);
        }
    }
    #[test]
    fn v22_3_acl_detection_exact_deny_without_backup_xattrs() {
        let text = "-rw-rw-rw-+ 1 user staff 1 Jan 1 10:00 /tmp/Icon\\015\n 0: group:everyone deny write,delete,append\n 1: group:staff deny delete_child\n";
        assert!(acl_text_has_deny(text,"delete"));
        assert!(!acl_text_has_deny(text,"delete_child"));
        let text = "directory\n 0: ABCDEFAB-CDEF-ABCD-EFAB-CDEF0000000C deny delete_child\n";
        assert!(acl_text_has_deny(text,"delete_child"));
        assert!(!acl_text_has_deny(text,"delete"));
    }
    #[test]
    fn v22_3_acl_scope_not_tied_to_ccc_name() {
        for path in ["/Volumes/T7", "/Volumes/T7/Old Music", "/Volumes/T7/_CCC SafetyNet/Archive"] {
            assert_eq!(acl_boundary(Path::new(path),Some("user")).unwrap(),PathBuf::from("/Volumes/T7"));
        }
        assert_eq!(acl_boundary(Path::new("/Users/user/Documents/Archive"),Some("user")).unwrap(),PathBuf::from("/Users/user"));
        for path in ["/", "/System/Library", "/Users/other/Documents", "/Users/user/Library", "/Volumes/T7/.Trashes/501", "/Volumes/T7/Backups.backupdb"] {
            assert!(acl_boundary(Path::new(path),Some("user")).is_err(),"{path}");
        }
    }

    struct OneByte<'a>(&'a [u8]);
    impl Read for OneByte<'_> {
        fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
            if self.0.is_empty() || buf.is_empty() { return Ok(0); }
            buf[0] = self.0[0];
            self.0 = &self.0[1..];
            Ok(1)
        }
    }
    #[test]
    fn byte_compare_survives_short_reads() {
        let data: Vec<u8> = (0..300_000u32).map(|i| (i % 251) as u8).collect();
        let mut other = data.clone();
        assert!(equal_streams(&mut OneByte(&data), &mut io::Cursor::new(&data)).unwrap());
        other[299_999] ^= 1;
        assert!(!equal_streams(&mut OneByte(&data), &mut io::Cursor::new(&other)).unwrap());
        assert!(!equal_streams(&mut io::Cursor::new(&data[..299_999]), &mut io::Cursor::new(&data)).unwrap());
    }
    #[test]
    fn merge_keeps_modification_time() {
        let f = Fixture::new();
        let source = f.a.join("x.txt");
        fs::write(&source, b"inhalt").unwrap();
        let old = SystemTime::UNIX_EPOCH + std::time::Duration::from_secs(1_500_000_000);
        OpenOptions::new().write(true).open(&source).unwrap().set_modified(old).unwrap();
        let (target, metadata_ok) = copy_missing(&f.a, &f.b, &source).unwrap();
        assert!(metadata_ok);
        assert_eq!(fs::metadata(&target).unwrap().modified().unwrap(), old);
    }
    #[test]
    fn session_row_is_updated_in_place() {
        let entry = |a: Option<&str>, b: Option<&str>, kind| Entry { a: a.map(PathBuf::from), b: b.map(PathBuf::from), kind, checked_conflict: false, fast_proof: None };
        *SESSION.lock().unwrap() = Some(Session {
            a: PathBuf::from("/A"), b: PathBuf::from("/B"), patterns: Vec::new(), page: 0,
            entries: vec![entry(Some("/A/x"), None, Kind::OnlyA), entry(Some("/A/y"), Some("/B/y"), Kind::Same)],
            filter: "all".into(), selected: BTreeSet::new(), from_index: false, scope: String::new(), display_limit: INITIAL_VISIBLE, groups: BTreeMap::new(), groups_dirty: true, visible_cache: RefCell::new(None), counts_cache: Cell::new(None), group_page: 0,
        });
        let (rows, _) = update_session(0, Some(PathBuf::from("/B/x")));
        assert_eq!(rows.unwrap()[0][2], "same");
        // Removing the A copy changes this entry into OnlyB. The default
        // A-centred filter intentionally hides it, so there is no row[1].
        let (rows, _) = update_session(1, None);
        let rows = rows.expect("session must still have a visible result");
        assert_eq!(rows.len(), 1);
        assert_eq!(rows[0][2], "same");
        {
            let mut guard = SESSION.lock().unwrap();
            let session = guard.as_mut().unwrap();
            let removed_from_a = &session.entries[1];
            assert_eq!(removed_from_a.kind, Kind::OnlyB);
            assert!(removed_from_a.a.is_none());
            assert_eq!(removed_from_a.b.as_deref(), Some(Path::new("/B/y")));

            // The underlying B-only entry is retained and must remain
            // available through the explicit B-only filter.
            session.filter = "only_b".into();
            let (b_rows, _) = page_rows(session);
            assert_eq!(b_rows.len(), 1);
            assert_eq!(b_rows[0][1], "y");
            assert_eq!(b_rows[0][2], "only_b");
        }
        *SESSION.lock().unwrap() = None;
    }
    #[test]
    fn verify_pair_reports_difference_without_changing_anything() {
        let f = Fixture::new();
        let (l, r) = (f.a.join("x"), f.b.join("y"));
        fs::write(&l, b"gleich").unwrap(); fs::write(&r, b"gleich").unwrap();
        assert_eq!(verify_pair(&f.a, &f.b, &l, &r), Ok(true));
        fs::write(&r, b"gleiCh").unwrap();
        assert_eq!(verify_pair(&f.a, &f.b, &l, &r), Ok(false));
        fs::write(&r, b"laenger!").unwrap();
        assert_eq!(verify_pair(&f.a, &f.b, &l, &r), Ok(false));
        assert!(l.exists() && r.exists());
    }
    #[cfg(unix)]
    #[test]
    fn preflight_refuses_links_into_a_and_passes_clean_trees() {
        use std::os::unix::fs::symlink;
        let f = Fixture::new();
        fs::write(f.a.join("x"), b"x").unwrap();
        assert!(link_preflight(&f.a, &f.b).is_ok());
        symlink(f.a.join("x"), f.b.join("link")).unwrap();
        assert!(link_preflight(&f.a, &f.b).unwrap().check_path(&f.a.join("x")).is_err());
    }
    #[test]
    fn conflict_preview_is_not_claimed_to_be_byte_different() {
        let e = Entry { a: Some(PathBuf::from("/A/x")), b: Some(PathBuf::from("/B/x")),
            kind: Kind::Conflict, checked_conflict: false, fast_proof: None };
        let row = row_text(&e, Path::new("/A"), Path::new("/B"));
        assert_eq!(row[3], "Ungeprüft");
        assert!(row[5].contains("nicht aktuell byteweise geprüft"));
        let verified = Entry { checked_conflict: true, ..e };
        let row = row_text(&verified, Path::new("/A"), Path::new("/B"));
        assert_eq!(row[3], "Verschieden");
    }
    #[test]
    fn preflight_trash_is_non_mutating() {
        let f = Fixture::new();
        let a_file = f.a.join("x"); let b_file = f.b.join("x");
        fs::write(&a_file, b"same").unwrap(); fs::write(&b_file, b"same").unwrap();
        assert!(preflight_trash_pair(&f.a, &f.b, &a_file, &b_file).is_ok());
        assert!(a_file.exists() && b_file.exists());
        fs::write(&b_file, b"changed").unwrap();
        assert!(preflight_trash_pair(&f.a, &f.b, &a_file, &b_file).is_err());
        assert!(a_file.exists() && b_file.exists());
    }
    #[test]
    fn check_modes_deny_changed_content_and_fast_needs_evidence() {
        let f = Fixture::new();
        let (left, right) = (f.a.join("left"), f.b.join("right"));
        fs::write(&left, b"abc").unwrap();
        fs::write(&right, b"abc").unwrap();
        let ml = fs::metadata(&left).unwrap();
        let mr = fs::metadata(&right).unwrap();
        let proof = FastProof {
            size_a: ml.len(), size_b: mr.len(),
            modified_a: unix_seconds(ml.modified().unwrap()).unwrap(),
            modified_b: unix_seconds(mr.modified().unwrap()).unwrap(),
        };
        assert!(preflight_trash_pair_with_mode(&f.a, &f.b, &left, &right, TrashCheckMode::Fast, Some(proof)).is_ok());
        assert!(preflight_trash_pair_with_mode(&f.a, &f.b, &left, &right, TrashCheckMode::Fast, None).is_err());
        assert!(preflight_trash_pair_with_mode(&f.a, &f.b, &left, &right, TrashCheckMode::FreshHash, None).is_ok());
        assert!(preflight_trash_pair_with_mode(&f.a, &f.b, &left, &right, TrashCheckMode::Bytes, None).is_ok());
        fs::write(&right, b"different").unwrap();
        for mode in [TrashCheckMode::Fast, TrashCheckMode::FreshHash, TrashCheckMode::Bytes] {
            assert!(preflight_trash_pair_with_mode(&f.a, &f.b, &left, &right, mode, Some(proof)).is_err());
        }
        assert!(left.exists() && right.exists());
    }
    #[test]
    fn fast_mode_rejects_modified_time_change_with_same_length() {
        let f = Fixture::new();
        let (left, right) = (f.a.join("x"), f.b.join("x"));
        fs::write(&left, b"abc").unwrap(); fs::write(&right, b"abc").unwrap();
        let proof = FastProof {
            size_a: 3, size_b: 3,
            modified_a: unix_seconds(fs::metadata(&left).unwrap().modified().unwrap()).unwrap(),
            modified_b: unix_seconds(fs::metadata(&right).unwrap().modified().unwrap()).unwrap(),
        };
        fs::write(&right, b"xyz").unwrap();
        let later = SystemTime::UNIX_EPOCH + std::time::Duration::from_secs(proof.modified_b + 10);
        OpenOptions::new().write(true).open(&right).unwrap().set_modified(later).unwrap();
        assert!(preflight_trash_pair_with_mode(&f.a, &f.b, &left, &right, TrashCheckMode::Fast, Some(proof)).is_err());
        assert!(preflight_trash_pair_with_mode(&f.a, &f.b, &left, &right, TrashCheckMode::FreshHash, None).is_err());
    }
    #[test]
    fn trash_pair_refuses_changed_pair() {
        let f = Fixture::new();
        let (l, r) = (f.a.join("x"), f.b.join("x"));
        fs::write(&l, b"eins").unwrap(); fs::write(&r, b"zwei").unwrap();
        assert!(trash_pair(&f.a, &f.b, &l, &r).is_err());
        assert!(l.exists());
    }
    fn indexed(path: &str, id: Option<u32>) -> crate::folder_relations::IndexedFile {
        crate::folder_relations::IndexedFile { path: PathBuf::from(path), size: 1, modified: 1, content_id: id, fast_eligible: false }
    }
    #[test]
    fn index_preview_pairs_one_to_one_and_finds_conflicts_with_unordered_b() {
        // A hat zwei identische Dateien, B nur eine Kopie: nur EINE A-Datei darf als identisch gelten,
        // sonst könnte der Papierkorb beide Kopien entfernen.
        let left = vec![indexed("/A/x/1.wav", Some(1)), indexed("/A/x/2.wav", Some(1)),
            indexed("/A/y/c.wav", Some(2)), indexed("/A/z/u.wav", Some(3))];
        let right = vec![indexed("/B/zz/other.bin", Some(7)), indexed("/B/y/c.wav", Some(9)), indexed("/B/q/copy.wav", Some(1))];
        let session = index_preview_session(Path::new("/A"), Path::new("/B"), left, right, Vec::new());
        let kinds: Vec<Kind> = session.entries.iter().map(|e| e.kind).collect();
        assert_eq!(kinds[..4], [Kind::Same, Kind::OnlyA, Kind::Conflict, Kind::OnlyA]);
        assert_eq!(kinds.iter().filter(|k| **k == Kind::OnlyB).count(), 1);
        assert_eq!(session.entries[0].b.as_deref(), Some(Path::new("/B/q/copy.wav")));
        assert_eq!(session.entries[2].b.as_deref(), Some(Path::new("/B/y/c.wav")));
    }
    #[test]
    fn index_preview_prefers_same_relative_path_among_duplicates() {
        let left = vec![indexed("/A/d/same.wav", Some(5))];
        let right = vec![indexed("/B/a/other.wav", Some(5)), indexed("/B/d/same.wav", Some(5))];
        let session = index_preview_session(Path::new("/A"), Path::new("/B"), left, right, Vec::new());
        assert_eq!(session.entries[0].kind, Kind::Same);
        assert_eq!(session.entries[0].b.as_deref(), Some(Path::new("/B/d/same.wav")));
    }

    #[cfg(unix)]
    #[test]
    fn v22_link_dependency_does_not_block_unrelated_file() {
        use std::os::unix::fs::symlink;
        let f = Fixture::new();
        let blocked = f.a.join("blocked"); let safe = f.a.join("safe");
        fs::write(&blocked,b"x").unwrap(); fs::write(&safe,b"y").unwrap();
        symlink(&blocked,f.b.join("link")).unwrap();
        let links = link_preflight(&f.a,&f.b).unwrap();
        assert!(links.check_path(&blocked).is_err());
        assert!(links.check_path(&safe).is_ok());
        assert!(blocked.exists() && safe.exists());
    }
    #[test]
    fn v22_unreadable_inventory_is_reported_not_global_failure() {
        let f = Fixture::new();
        let mut links = LinkPreflight::default();
        inventory_links_for_preflight(&f.a.join("missing"), &mut links).unwrap();
        assert_eq!(links.skipped, 1);
        assert!(links.warning().contains("unvollständig"));
        assert!(links.check_path(&f.a.join("other")).is_ok());
    }
    #[test]
    fn v22_force_delete_only_after_verified_pair() {
        let f = Fixture::new();
        let a=f.a.join("x"); let b=f.b.join("x");
        fs::write(&a,b"a").unwrap(); fs::write(&b,b"b").unwrap();
        assert!(preflight_trash_pair(&f.a,&f.b,&a,&b).is_err());
        assert!(a.exists());
        fs::write(&b,b"a").unwrap();
        preflight_trash_pair(&f.a,&f.b,&a,&b).unwrap();
        remove_verified_source(&a,true,false).unwrap();
        assert!(!a.exists() && b.exists());
    }
    #[test]
    fn v22_failed_pair_does_not_prevent_later_verified_removal() {
        let f = Fixture::new();
        let bad=f.a.join("bad"); let bad_copy=f.b.join("bad");
        let good=f.a.join("good"); let good_copy=f.b.join("good");
        fs::write(&bad,b"bad").unwrap(); fs::write(&bad_copy,b"new").unwrap();
        fs::write(&good,b"ok").unwrap(); fs::write(&good_copy,b"ok").unwrap();
        let links=link_preflight(&f.a,&f.b).unwrap();
        let results: Vec<_> = [(&bad,&bad_copy),(&good,&good_copy)].into_iter()
            .map(|(a,b)| verified_remove_pair(&f.a,&f.b,a,b,TrashCheckMode::Bytes,None,&links,true,false)).collect();
        assert!(results[0].is_err()); assert!(results[1].is_ok());
        assert!(bad.exists() && bad_copy.exists() && !good.exists() && good_copy.exists());
    }
    #[cfg(unix)]
    #[test]
    fn v22_permission_denied_in_unrelated_directory() {
        use std::os::unix::fs::PermissionsExt;
        let f=Fixture::new();
        let locked=f.a.join("locked"); fs::create_dir(&locked).unwrap();
        fs::write(locked.join("file"),b"private").unwrap();
        let a=f.a.join("good"); let b=f.b.join("good");
        fs::write(&a,b"ok").unwrap(); fs::write(&b,b"ok").unwrap();
        fs::set_permissions(&locked,fs::Permissions::from_mode(0o000)).unwrap();
        let inaccessible=fs::read_dir(&locked).is_err();
        let links=link_preflight(&f.a,&f.b);
        fs::set_permissions(&locked,fs::Permissions::from_mode(0o700)).unwrap();
        let links=links.unwrap();
        if inaccessible { assert!(links.skipped>0); }
        assert!(verified_remove_pair(&f.a,&f.b,&a,&b,TrashCheckMode::Bytes,None,&links,true,false).is_ok());
        assert!(!a.exists() && b.exists() && locked.join("file").exists());
    }

}
