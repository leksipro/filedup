#!/usr/bin/env python3
"""Apply the content-based folder comparison add-on to a Krokiet 12.0.2 checkout.

This script never touches user data or scans. It modifies only Krokiet source files.
It fails if the expected source layout/snippets do not match.
"""
from pathlib import Path
import shutil
import sys

BUNDLE = Path(__file__).resolve().parent


def replace_once(source: str, needle: str, replacement: str, label: str) -> str:
    hits = source.count(needle)
    if hits != 1:
        raise RuntimeError(f"{label}: expected 1 occurrence, found {hits}. Is this Krokiet 12.0.2?")
    return source.replace(needle, replacement, 1)


def main() -> None:
    if len(sys.argv) != 2:
        sys.exit("Usage: python3 apply_patch.py /path/to/czkawka")
    root = Path(sys.argv[1]).expanduser().resolve()
    main_rs = root / "krokiet/src/main.rs"
    main_slint = root / "krokiet/ui/main_window.slint"
    cargo = root / "krokiet/Cargo.toml"
    if not all(p.is_file() for p in (main_rs, main_slint, cargo)):
        sys.exit("Not a full Czkawka/Krokiet source checkout (missing Krokiet source files).")
    if 'version = "12.0.2"' not in cargo.read_text(encoding="utf-8"):
        sys.exit("Version mismatch: expected Krokiet 12.0.2. Do not patch an unknown source version.")
    dest_module = root / "krokiet/src/folder_compare.rs"
    dest_popup = root / "krokiet/ui/popups/popup_folder_compare.slint"
    if dest_module.exists() or dest_popup.exists():
        sys.exit("Existing folder_compare files found; refusing to overwrite.")

    rust = main_rs.read_text(encoding="utf-8")
    rust = replace_once(rust, "mod file_actions;", "mod file_actions;\nmod folder_compare;", "main.rs module")
    rust = replace_once(
        rust,
        "    connect_scan_button(&app, progress_sender.clone(), stop_flag.clone(), Arc::clone(&shared_models), Arc::clone(&audio_player));",
        "    connect_scan_button(&app, progress_sender.clone(), stop_flag.clone(), Arc::clone(&shared_models), Arc::clone(&audio_player));\n    folder_compare::connect_folder_compare(&app);",
        "main.rs initialization",
    )

    slint = main_slint.read_text(encoding="utf-8")
    slint = replace_once(
        slint,
        'import { HorizontalBox, LineEdit, Palette, VerticalBox } from "std-widgets.slint";',
        'import { Button, HorizontalBox, LineEdit, Palette, VerticalBox } from "std-widgets.slint";',
        "Slint widget import",
    )
    slint = replace_once(
        slint,
        'import { PopupNewDirectories } from "popups/popup_new_directories.slint";',
        'import { PopupNewDirectories } from "popups/popup_new_directories.slint";\nimport { PopupFolderCompare } from "popups/popup_folder_compare.slint";',
        "Slint popup import",
    )
    slint = replace_once(
        slint,
        "    callback scan_ended(string);",
        "    callback scan_ended(string);\n"
        "    callback folder_compare_choose_left();\n"
        "    callback folder_compare_choose_right();\n"
        "    callback folder_compare_start(string, string, string);\n"
        "    callback folder_compare_cancel();\n"
        "    callback folder_compare_save_report();",
        "Slint callbacks",
    )
    slint = replace_once(
        slint,
        '    in-out property <string> text_summary_text: "";',
        '    in-out property <string> text_summary_text: "";\n'
        '    in-out property <string> folder_compare_left_path: "";\n'
        '    in-out property <string> folder_compare_right_path: "";\n'
        '    in-out property <string> folder_compare_output: "Choose two folders to compare.";\n'
        '    in-out property <string> folder_compare_ignore_patterns: "";\n'
        '    in-out property <string> folder_compare_status: "";\n'
        '    in-out property <bool> folder_compare_has_report: false;\n'
        '    in-out property <bool> folder_compare_busy: false;',
        "Slint state",
    )
    slint = replace_once(
        slint,
        "            text_summary := LineEdit {",
        '            Button {\n'
        '                text: "Compare folders";\n'
        '                enabled: !root.scanning && !root.processing;\n'
        '                clicked => { folder_compare_popup_window.show_popup(); }\n'
        '            }\n'
        "            text_summary := LineEdit {",
        "Slint toolbar button",
    )
    slint = replace_once(
        slint,
        "    new_directory_popup_window := PopupNewDirectories {",
        '    folder_compare_popup_window := PopupFolderCompare {\n'
        '        x: 0; y: 0;\n'
        '        width: root.width;\n'
        '        height: root.height;\n'
        '        left_path <=> root.folder_compare_left_path;\n'
        '        right_path <=> root.folder_compare_right_path;\n'
        '        output <=> root.folder_compare_output;\n'
        '        busy <=> root.folder_compare_busy;\n'
        '        ignore_patterns <=> root.folder_compare_ignore_patterns;\n'
        '        status <=> root.folder_compare_status;\n'
        '        has_report <=> root.folder_compare_has_report;\n'
        '        choose_left() => { root.folder_compare_choose_left(); }\n'
        '        choose_right() => { root.folder_compare_choose_right(); }\n'
        '        start_compare(a, b, patterns) => { root.folder_compare_start(a, b, patterns); }\n'
        '        cancel_compare() => { root.folder_compare_cancel(); }\n'
        '        save_report() => { root.folder_compare_save_report(); }\n'
        '    }\n'
        "    new_directory_popup_window := PopupNewDirectories {",
        "Slint new popup",
    )

    # Changes are written only after *all* checks pass.
    main_rs.write_text(rust, encoding="utf-8")
    main_slint.write_text(slint, encoding="utf-8")
    shutil.copy2(BUNDLE / "krokiet/src/folder_compare.rs", dest_module)
    shutil.copy2(BUNDLE / "krokiet/ui/popups/popup_folder_compare.slint", dest_popup)
    print("Applied Krokiet Folder Compare extension.")
    print("Next: cargo test -p krokiet folder_compare --locked")
    print("Then: cargo build -p krokiet --release --locked")


if __name__ == "__main__":
    main()
