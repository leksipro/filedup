"""Static checks for the responsive v11 UI; not a Slint compiler substitute."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
POPUPS = ROOT / "krokiet/ui/popups"

class ResponsiveUiChecks(unittest.TestCase):
    def test_no_fixed_popup_minimum_heights(self):
        for name in ("popup_folder_compare.slint", "popup_folder_relations.slint"):
            source = (POPUPS / name).read_text(encoding="utf-8")
            self.assertIn("popup_min_height: 0px;", source)
            self.assertIn("root.height - 115px", source)
            self.assertIn("root.width - 20px", source)
            self.assertNotIn("parent.width - 16px", source)

    def test_full_path_details_and_compact_modes(self):
        audit = (POPUPS / "popup_folder_compare.slint").read_text(encoding="utf-8")
        relations = (POPUPS / "popup_folder_relations.slint").read_text(encoding="utf-8")
        self.assertIn('root.audit_rows[root.selected][0]', audit)
        self.assertIn('root.audit_rows[root.selected][1]', audit)
        self.assertIn('root.files[root.selected_file][0]', relations)
        self.assertIn('root.show_detail = true', relations)
        self.assertIn('root.show_detail = false', relations)
        self.assertIn('in-out property <bool> summarize: false;', relations)

    def test_manual_actions_preserved(self):
        audit = (POPUPS / "popup_folder_compare.slint").read_text(encoding="utf-8")
        self.assertIn('"merge_one"', audit)
        self.assertIn('"trash_one_a"', audit)
        self.assertIn('"finder_folder_b"', audit)
        relations = (POPUPS / "popup_folder_relations.slint").read_text(encoding="utf-8")
        self.assertNotIn('"trash_one_a"', relations)
        self.assertNotIn('"start_trash"', relations)

if __name__ == "__main__":
    unittest.main()
