#!/usr/bin/env python3
"""Apply the content-based folder comparison add-on to a Krokiet 12.0.2 checkout.

This installer never touches user data or scans. It modifies Krokiet source files and adds a pinned direct dependency to its Cargo.toml/Cargo.lock.
It fails if the expected source layout/snippets do not match.
"""
from pathlib import Path
import shutil
import sys
import re

BUNDLE = Path(__file__).resolve().parent

# Additive, read-only method for czkawka_core: lists the files the scan would consider (same filters),
# without hashing and without touching any file.
CORE_METHOD = """    /// Add-on (Ordner-Übersicht): Mindestgröße, mit der der Scan lief (kleinere Dateien wurden nicht verglichen).
    pub fn get_minimal_file_size_for_addon(&self) -> u64 {
        self.common_data.minimal_file_size
    }

    /// Warnungen des ursprünglichen Hashscans; bei Problemen kein uneingeschränkt positives Urteil.
    pub fn get_addon_scan_warnings(&self) -> Vec<String> {
        self.common_data.text_messages.warnings.clone()
    }

    /// Erneute Inventarisierung ohne Hashen; gibt Dateiliste UND Traversierungswarnungen zurück.
    pub fn prepare_full_inventory(&self, stop_flag: &Arc<AtomicBool>) -> Box<dyn FnOnce() -> Result<(Vec<FileEntry>, Vec<String>), String>> {
        let traversal = DirTraversalBuilder::new()
            .common_data(&self.common_data)
            .minimal_file_size(0)
            .group_by(|_fe: &FileEntry| ())
            .checking_method(CheckingMethod::Size)
            .stop_flag(stop_flag)
            .build();
        Box::new(move || match traversal.run() {
            DirTraversalResult::SuccessFiles { grouped_file_entries, warnings } => Ok((grouped_file_entries.into_values().flatten().collect(), warnings)),
            DirTraversalResult::Stopped => Err("Inventory scan was cancelled".to_owned()),
        })
    }

"""

HOOK_OLD = """            sd.shared_models.lock().expect("Mutex poisoned").shared_duplication_state = Some(tool);

            let messages_data = MessagesData { critical, messages };

            a.upgrade_in_event_loop(move |app| {
                write_duplicate_results(&app, vector, messages_data, info, sd, stopped_search, duplicates_number, groups_number, lost_space);
            })
"""

HOOK_NEW = """            // Folder Relationships add-on: snapshot of the finished scan (read only), taken before the finder is moved.
            let relations_snapshot = crate::folder_relations::prepare(&tool, &sd.stop_flag);
            let relations_weak = a.clone();
            sd.shared_models.lock().expect("Mutex poisoned").shared_duplication_state = Some(tool);

            let messages_data = MessagesData { critical, messages };

            let post_result = a.upgrade_in_event_loop(move |app| {
                write_duplicate_results(&app, vector, messages_data, info, sd, stopped_search, duplicates_number, groups_number, lost_space);
            });
            crate::folder_relations::publish(relations_weak, relations_snapshot);
            post_result
"""


def replace_once(source: str, needle: str, replacement: str, label: str) -> str:
    hits = source.count(needle)
    if hits != 1:
        raise RuntimeError(f"{label}: expected 1 occurrence, found {hits}. Is this Krokiet 12.0.2?")
    return source.replace(needle, replacement, 1)


def add_locked_trash_dependency(cargo_text: str, lock_text: str) -> tuple[str, str]:
    """Expose native trash operations in Krokiet itself without changing the locked version.

    The source checkout already has trash via czkawka_core, so lockfile changes
    are limited to the root Krokiet package's dependency list. Fail on unknown
    Cargo.lock shapes instead of disabling --locked or silently updating crates.
    """
    matches = re.findall(r'(?ms)^\[\[package\]\]\nname = "trash"\nversion = "([^"]+)"', lock_text)
    if len(matches) != 1:
        raise RuntimeError(f'Expected exactly one locked trash crate, found {matches}.')
    version = matches[0]
    if not re.search(r'(?m)^\[dependencies\]\s*$', cargo_text):
        raise RuntimeError('Expected [dependencies] in krokiet/Cargo.toml')
    if re.search(r'(?m)^trash\s*=', cargo_text):
        raise RuntimeError('Krokiet already has a direct trash dependency.')
    cargo_text = cargo_text.replace('[dependencies]\n', f'[dependencies]\ntrash = "={version}"\n', 1)
    pattern = re.compile(r'(?ms)^\[\[package\]\]\nname = "krokiet"\n(?P<body>.*?)(?=^\[\[package\]\]|\Z)')
    match = pattern.search(lock_text)
    if not match:
        raise RuntimeError('Could not locate krokiet package in Cargo.lock')
    body = match.group('body')
    if '"trash",' in body:
        raise RuntimeError('Krokiet Cargo.lock already lists trash.')
    if 'dependencies = [\n' not in body:
        raise RuntimeError('Unexpected krokiet Cargo.lock entry without dependencies')
    body = body.replace('dependencies = [\n', 'dependencies = [\n "trash",\n', 1)
    lock_text = lock_text[:match.start('body')] + body + lock_text[match.end('body'):]
    return cargo_text, lock_text


def add_locked_blake3_dependency(cargo_text: str, lock_text: str) -> tuple[str, str]:
    """Add the already-locked blake3 version directly to Krokiet's package."""
    matches = re.findall(r'(?ms)^\[\[package\]\]\nname = "blake3"\nversion = "([^"]+)"', lock_text)
    if len(matches) != 1:
        raise RuntimeError(f'Expected one locked blake3 crate, found {matches}.')
    already_direct = re.search(r'(?m)^blake3\s*=', cargo_text) is not None
    if not already_direct:
        cargo_text = cargo_text.replace('[dependencies]\n', f'[dependencies]\nblake3 = "={matches[0]}"\n', 1)
    pattern = re.compile(r'(?ms)^\[\[package\]\]\nname = "krokiet"\n(?P<body>.*?)(?=^\[\[package\]\]|\Z)')
    match = pattern.search(lock_text)
    if not match:
        raise RuntimeError('Could not locate krokiet in Cargo.lock')
    body = match.group('body')
    if '"blake3",' in body:
        if not already_direct:
            raise RuntimeError('Cargo.lock lists blake3 but Cargo.toml does not')
        return cargo_text, lock_text
    if already_direct:
        raise RuntimeError('Cargo.toml lists blake3 but Cargo.lock does not')
    body = body.replace('dependencies = [\n', 'dependencies = [\n "blake3",\n', 1)
    lock_text = lock_text[:match.start('body')] + body + lock_text[match.end('body'):]
    return cargo_text, lock_text


def main() -> None:
    if len(sys.argv) != 2:
        sys.exit("Usage: python3 apply_patch.py /path/to/czkawka")
    root = Path(sys.argv[1]).expanduser().resolve()
    main_rs = root / "krokiet/src/main.rs"
    main_slint = root / "krokiet/ui/main_window.slint"
    cargo = root / "krokiet/Cargo.toml"
    lock = root / "Cargo.lock"
    if not all(p.is_file() for p in (main_rs, main_slint, cargo, lock)):
        sys.exit("Not a full Czkawka/Krokiet source checkout (missing Krokiet source files).")
    if 'version = "12.0.2"' not in cargo.read_text(encoding="utf-8"):
        sys.exit("Version mismatch: expected Krokiet 12.0.2. Do not patch an unknown source version.")
    core_rs = root / "czkawka_core/src/tools/duplicate/core.rs"
    hook_rs = root / "krokiet/src/connect_scan/duplicate.rs"
    if not (core_rs.is_file() and hook_rs.is_file()):
        sys.exit("Missing czkawka_core duplicate core or krokiet duplicate scan source.")
    new_files = [
        ("krokiet/src/folder_compare.rs", root / "krokiet/src/folder_compare.rs"),
        ("krokiet/src/folder_audit_actions.rs", root / "krokiet/src/folder_audit_actions.rs"),
        ("krokiet/src/macos_backup_acl.sh", root / "krokiet/src/macos_backup_acl.sh"),
        ("krokiet/ui/popups/popup_folder_compare.slint", root / "krokiet/ui/popups/popup_folder_compare.slint"),
        ("krokiet/src/folder_relations.rs", root / "krokiet/src/folder_relations.rs"),
        ("krokiet/src/folder_relations_actions.rs", root / "krokiet/src/folder_relations_actions.rs"),
        ("krokiet/ui/popups/popup_folder_relations.slint", root / "krokiet/ui/popups/popup_folder_relations.slint"),
        ("krokiet/ui/popups/popup_folder_workspace.slint", root / "krokiet/ui/popups/popup_folder_workspace.slint"),
    ]
    if any(dest.exists() for _, dest in new_files):
        sys.exit("Existing add-on files found; refusing to overwrite.")
    for relative, _ in new_files:
        if not (BUNDLE / relative).is_file():
            sys.exit(f"Patch incomplete: missing {relative}")

    rust = main_rs.read_text(encoding="utf-8")
    rust = replace_once(rust, "mod file_actions;", "mod file_actions;\nmod folder_compare;\nmod folder_relations;", "main.rs module")
    rust = replace_once(
        rust,
        "    connect_scan_button(&app, progress_sender.clone(), stop_flag.clone(), Arc::clone(&shared_models), Arc::clone(&audio_player));",
        "    connect_scan_button(&app, progress_sender.clone(), stop_flag.clone(), Arc::clone(&shared_models), Arc::clone(&audio_player));\n    folder_compare::connect_folder_compare(&app);\n    folder_relations::connect_folder_relations(&app);",
        "main.rs initialization",
    )

    slint = main_slint.read_text(encoding="utf-8")
    slint = replace_once(
        slint,
        'import { HorizontalBox, LineEdit, Palette, VerticalBox } from "std-widgets.slint";',
        'import { Button, HorizontalBox, LineEdit, Palette, VerticalBox } from "std-widgets.slint";',
        "Slint widget import",
    )
    slint = replace_once(
        slint,
        'import { PopupNewDirectories } from "popups/popup_new_directories.slint";',
        'import { PopupNewDirectories } from "popups/popup_new_directories.slint";\nimport { PopupFolderWorkspace } from "popups/popup_folder_workspace.slint";',
        "Slint popup import",
    )
    slint = replace_once(
        slint,
        "    callback scan_ended(string);",
        "    callback scan_ended(string);\n"
        "    callback folder_compare_choose_left();\n"
        "    callback folder_compare_choose_right();\n"
        "    callback folder_compare_start(string, string, string);\n"
        "    callback folder_compare_preview(string, string);\n"
        "    callback folder_compare_cancel();\n"
        "    callback folder_compare_save_report();\n"
        "    callback folder_audit_action(string, int);\n"
        "    callback folder_relations_analyze(int, int, bool, string, string, int, int);\n"
        "    callback folder_relations_select(int);\n"
        "    callback folder_relations_action(string, int);",
        "Slint callbacks",
    )
    slint = replace_once(
        slint,
        '    in-out property <string> text_summary_text: "";',
        '    in-out property <string> text_summary_text: "";\n'
        '    in-out property <string> folder_compare_left_path: "";\n'
        '    in-out property <string> folder_compare_right_path: "";\n'
        '    in-out property <string> folder_compare_output: "Choose two folders to compare.";\n'
        '    in-out property <string> folder_compare_ignore_patterns: "";\n'
        '    in-out property <string> folder_compare_status: "";\n'
        '    in-out property <string> folder_operation_report: "";\n'
        '    in-out property <string> folder_operation_pause: "";\n'
        '    in-out property <bool> folder_operation_finder_retry: false;\n'
        '    in-out property <bool> folder_operation_confirm_acl: false;\n'
        '    in-out property <bool> folder_compare_has_report: false;\n'
        '    in-out property <bool> folder_compare_busy: false;\n'
        '    in-out property <[[string]]> folder_audit_rows: [];\n'
        '    in-out property <bool> folder_audit_from_index: true;\n'
        '    in-out property <[[string]]> folder_audit_subfolders: [];\n'
        '    in-out property <string> folder_audit_page_info: "Noch kein Audit";\n'
        '    in-out property <int> folder_audit_selected: -1;\n'
        '    in-out property <[int]> folder_audit_counts: [0, 0, 0, 0, 0, 0];\n'
        '    in-out property <int> folder_audit_selected_merge_count: 0;\n'
        '    in-out property <int> folder_audit_selected_merge_back_count: 0;\n'
        '    in-out property <int> folder_audit_selected_same_count: 0;\n'
        '    in-out property <[[string]]> folder_relations_rows: [];\n'
        '    in-out property <string> folder_relations_status: "Zuerst einen Duplikat-Scan mit Prüfmethode Hash ausführen.";\n'
        '    in-out property <[string]> folder_relations_disks: ["Alle Platten"];\n'
        '    in-out property <string> folder_relations_disk_summary: "";\n'
        '    in-out property <string> folder_relations_page_info: "";\n'
        '    in-out property <int> folder_relations_current_page: 0;\n'
        '    in-out property <int> folder_relations_page_count: 1;\n' 
        '    in-out property <string> folder_relations_detail: "";\n'
        '    in-out property <bool> folder_relations_available: false;\n'
        '    in-out property <bool> folder_relations_busy: false;\n'
        '    in-out property <int> folder_relations_selected: -1;\n'
        '    in-out property <[int]> folder_relations_tab_counts: [0, 0, 0, 0];\n'
        '    in-out property <[[string]]> folder_relations_files: [];\n'
        '    in-out property <string> folder_relations_action_status: "";',
        "Slint state",
    )
    slint = replace_once(
        slint,
        "            text_summary := LineEdit {",
        '            Button {\n'
        '                text: "Ordner vergleichen";\n'
        '                enabled: !root.scanning && !root.processing;\n'
        '                clicked => { folder_workspace_popup_window.show_popup(); }\n'
        '            }\n'
        "            text_summary := LineEdit {",
        "Slint toolbar button",
    )
    slint = replace_once(
        slint,
        "    new_directory_popup_window := PopupNewDirectories {",
        '    folder_workspace_popup_window := PopupFolderWorkspace {\n'
        '        x: 0; y: 0; width: root.width; height: root.height;\n'
        '        rows: root.folder_relations_rows;\n'
        '        disks: root.folder_relations_disks;\n'
        '        disk_summary: root.folder_relations_disk_summary;\n'
        '        page_info: root.folder_relations_page_info;\n'
        '        page <=> root.folder_relations_current_page;\n'
        '        page_count: root.folder_relations_page_count;\n'
        '        detail: root.folder_relations_detail;\n'
        '        status: root.folder_relations_status;\n'
        '        available: root.folder_relations_available;\n'
        '        busy: root.folder_relations_busy;\n'
        '        selected <=> root.folder_relations_selected;\n'
        '        tab_counts: root.folder_relations_tab_counts;\n'
        '        files: root.folder_relations_files;\n'
        '        action_status: root.folder_relations_action_status;\n'
        '        left_path <=> root.folder_compare_left_path;\n'
        '        right_path <=> root.folder_compare_right_path;\n'
        '        ignore_patterns <=> root.folder_compare_ignore_patterns;\n'
        '        output <=> root.folder_compare_output;\n'
        '        audit_status <=> root.folder_compare_status;\n'
        '        operation_report: root.folder_operation_report;\n'
        '        operation_pause: root.folder_operation_pause;\n'
        '        operation_finder_retry: root.folder_operation_finder_retry;\n'
        '        operation_confirm_acl: root.folder_operation_confirm_acl;\n'
        '        audit_busy <=> root.folder_compare_busy;\n'
        '        has_report <=> root.folder_compare_has_report;\n'
        '        audit_rows: root.folder_audit_rows;\n'
        '        audit_from_index: root.folder_audit_from_index;\n'
        '        audit_subfolders: root.folder_audit_subfolders;\n'
        '        audit_page_info: root.folder_audit_page_info;\n'
        '        audit_selected <=> root.folder_audit_selected;\n'
        '        audit_counts: root.folder_audit_counts;\n'
        '        selected_merge_count: root.folder_audit_selected_merge_count;\n'
        '        selected_merge_back_count: root.folder_audit_selected_merge_back_count;\n'
        '        selected_same_count: root.folder_audit_selected_same_count;\n'
        '        analyze(threshold, min_files, summarize, disk, sort, page, tab) => { root.folder_relations_analyze(threshold, min_files, summarize, disk, sort, page, tab); }\n'
        '        select_row(position) => { root.folder_relations_select(position); }\n'
        '        action(name, position) => { root.folder_relations_action(name, position); }\n'
        '        open_compare(a, b) => {\n'
        '            root.folder_compare_left_path = a;\n'
        '            root.folder_compare_right_path = b;\n'
        '            root.folder_compare_preview(a, b);\n'
        '        }\n'
        '        choose_left() => { root.folder_compare_choose_left(); }\n'
        '        choose_right() => { root.folder_compare_choose_right(); }\n'
        '        start_compare(a, b, patterns) => { root.folder_compare_start(a, b, patterns); }\n'
        '        cancel_compare() => { root.folder_compare_cancel(); }\n'
        '        save_report() => { root.folder_compare_save_report(); }\n'
        '        audit_action(name, position) => { root.folder_audit_action(name, position); }\n'
        '    }\n'
        "    new_directory_popup_window := PopupNewDirectories {",
        "Slint new popup",
    )

    core = core_rs.read_text(encoding="utf-8")
    core = replace_once(core, '    #[fun_time(message = "check_files_size", level = "debug")]\n', CORE_METHOD + '    #[fun_time(message = "check_files_size", level = "debug")]\n', "core.rs inventory method")

    hook = hook_rs.read_text(encoding="utf-8")
    hook = replace_once(hook, HOOK_OLD, HOOK_NEW, "duplicate.rs scan thread tail")

    # Keep --locked builds reproducible while exposing native trash operations.
    cargo_new, lock_new = add_locked_trash_dependency(cargo.read_text(encoding="utf-8"), lock.read_text(encoding="utf-8"))
    cargo_new, lock_new = add_locked_blake3_dependency(cargo_new, lock_new)

    # Changes are written only after *all* checks pass.
    cargo.write_text(cargo_new, encoding="utf-8")
    lock.write_text(lock_new, encoding="utf-8")
    main_rs.write_text(rust, encoding="utf-8")
    main_slint.write_text(slint, encoding="utf-8")
    core_rs.write_text(core, encoding="utf-8")
    hook_rs.write_text(hook, encoding="utf-8")
    for relative, dest in new_files:
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(BUNDLE / relative, dest)
    print("Applied Krokiet v22.4: folder discovery, conflict recheck, copy and move in both directions.")
    print("Next: cargo test -p krokiet --locked")
    print("Then: cargo build -p krokiet --release --locked")


if __name__ == "__main__":
    main()
