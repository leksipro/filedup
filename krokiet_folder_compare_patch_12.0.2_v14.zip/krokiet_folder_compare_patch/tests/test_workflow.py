"""Static integration regressions. They do not replace Cargo/Slint compilation."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]

class WorkflowTests(unittest.TestCase):
    def test_pair_preview_reuses_existing_index(self):
        core = (ROOT / "krokiet/src/folder_relations.rs").read_text()
        audit = (ROOT / "krokiet/src/folder_compare.rs").read_text()
        installer = (ROOT / "apply_patch.py").read_text()
        self.assertIn("fn index_pair_preview(", core)
        self.assertIn("on_folder_compare_preview", audit)
        self.assertIn("root.folder_compare_preview(a, b)", installer)
        self.assertIn("prepare_index_preview", audit)

    def test_manual_batch_is_bounded_and_rechecks_files(self):
        actions = (ROOT / "krokiet/src/folder_audit_actions.rs").read_text()
        self.assertIn("MAX_BATCH_FILES: usize = 200", actions)
        self.assertIn('"merge_selected"', actions)
        self.assertIn('"trash_selected"', actions)
        self.assertIn("copy_missing(&a, &b", actions)
        self.assertIn("trash_identical_a(&a, &b", actions)
        self.assertIn("BATCH_STOP.load", actions)
        self.assertNotIn("remove_single_folder", actions)

    def test_filter_selection_across_pages_and_separate_confirmations(self):
        ui = (ROOT / "krokiet/ui/popups/popup_folder_workspace.slint").read_text()
        actions = (ROOT / "krokiet/src/folder_audit_actions.rs").read_text()
        self.assertIn("root.audit_action(\"select_all\", 0)", ui)
        self.assertIn("root.audit_action(\"filter:different\", 0)", ui)
        self.assertIn("confirm_trash", ui)
        self.assertIn("confirm_merge", ui)
        self.assertIn("session.selected.extend(shown)", actions)
        self.assertIn("visible_indices(session)", actions)

    def test_folder_cards_present_a_and_b(self):
        ui = (ROOT / "krokiet/ui/popups/popup_folder_workspace.slint").read_text()
        self.assertIn('"A  " + row[3]', ui)
        self.assertIn('"B  " + row[7]', ui)
        self.assertIn('root.open_compare(row[3], row[7])', ui)

if __name__ == "__main__":
    unittest.main()
