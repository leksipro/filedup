# Krokiet v14 – einheitlicher Ordnerarbeitsbereich

**Status:** Quellcode-Patch für Krokiet 12.0.2. Kein nachgewiesener macOS-Release; GitHub Actions muss Rust und Slint kompilieren und alle Tests ausführen.

## Neuer Workflow

1. Krokiets normalen **Duplikat-Scan mit Hash-Prüfung** durchführen.
2. In der Toolbar nur **„Ordner vergleichen“** öffnen. Ein Fenster, im breiten Modus Ordnerpaare links und Dateien rechts; bei schmaler Breite kann zwischen Liste und Details gewechselt werden.
3. Links einen Ordner mit konkretem Partner B wählen. Rechts wird **sofort** eine **unverifizierte Index-Vorschau** gezeigt, ohne neuen Festplattenscan.
4. Rechts über **Alle / Unterschiede / Nur A / Nur B / Konflikte / Identisch** filtern. Zähler zeigen die vollständigen Mengen; nicht nur sichtbare Seiten.
5. Einzeln, seitenspezifisch oder für den gesamten Filter auswählen. **Nur in A**: ausgewählte Dateien nach B kopieren (kein Überschreiben, byteweise Prüfung). **Identisch**: ausgewählte Dateien byteweise erneut prüfen und bei ausdrücklicher Bestätigung in den Papierkorb verschieben. **Keine automatische Ordnerlöschung**.
6. Im Menü **Mehr**: Datenträger, Sortierung, Abdeckungsgrenze, Mindestdateien, Zusammenfassen, Ignoriermuster, Bericht. **Eigene Pfade** und **Neu prüfen** stehen rechts zur Verfügung; der vollständige Audit ist optional, nicht Voraussetzung für eine Index-Vorschau.

## Sicherheitsgrenzen

- **Index-Vorschau ist keine Löschfreigabe.** Veraltete Dateiinhalte, Cache, Ausnahmen und Metadaten können fehlen. Vor jeder Papierkorbaktion wird die jeweilige Datei mit der Gegenkopie frisch byteweise verglichen.
- Es gibt weiterhin keine vollständige Prüfung externer Projektverweise, Finder-Aliase, macOS Extended Attributes oder sämtlicher Symlink-Abhängigkeiten außerhalb der beiden Ordner.
- Der Merge überschreibt niemals Zieldateien; aus A wird nur kopiert. Kopien werden byteweise verifiziert.
- Sammelaktionen sind auf **200 Dateien** begrenzt und zwischen den Dateien abbrechbar. Eine Bestätigung ist zwingend.
- **Global abgedeckt** heißt nicht, dass ein *einziger* B-Ordner alles enthält. Die Trefferübersicht zeigt dies getrennt an.
- Bei verschachtelten A/B-Verzeichnissen, unklaren Wurzelordnern oder Scanfehlern Aktionen nicht durchführen.

## GitHub Actions

ZIP-Datei ins Repository-Hauptverzeichnis: `krokiet_folder_compare_patch_12.0.2_v14.zip`.

Workflow-Datei separat unter `.github/workflows/build-krokiet.yml` hochladen. Sie installiert Rust auf einem macOS-ARM64-Runner, führt Python-/Rust-Tests aus und verpackt ein unsigniertes bzw. ad-hoc signiertes `.app`-Bundle.

**Hinweis:** Vor Nutzung mit wichtigen Daten zunächst mit kleinen Testordnern testen. Das Bestehen syntaktischer/Unit-Tests ist keine umfassende Löschsicherheitsgarantie.
