# Krokiet 12.0.2: Folder Compare und Folder Relationships (Quellcode-Erweiterung), Version 4

**Status: Quellcode, nicht auf macOS kompiliert.** Die Vergleichslogik ist in einem zweiten, unabhängigen Verfahren nachgebaut und gegeneinander getestet (siehe „Validierung“). Die Einbindung in Krokiet (Rust-Typen, Slint-Oberfläche, echter Czkawka-Scanner) konnte nur durch Lesen des Originalquellcodes 12.0.2 geprüft werden. **Der erste Schritt bei dir ist `cargo test`.**

Die Erweiterung fügt Krokiet eine Schaltfläche „Compare folders“ hinzu. Der Vergleich ist **nur lesend**. Er löscht, verschiebt und verändert keine Nutzerdateien. Einzige Schreibaktion: der Bericht, wenn du ihn selbst über „Save report“ speicherst.

## Ziel

**Ist jede Datei aus Ordner A (kleiner, Kandidat zum Löschen) inhaltlich auch in Ordner B (größer, wird behalten) vorhanden, und geht beim Löschen von A nichts kaputt, was in B liegt?**

## Was verglichen wird und was nicht (bewusste Abgrenzung)

Verglichen wird der **Dateiinhalt** (BLAKE3 über die ganze Datei, ohne Hash-Cache) und die **Symlinks** (nie verfolgt).

**Nicht geprüft werden, und das ist so gewollt:**

- **Metadaten:** Datum/Zeit, Finder-Tags, ACLs, Extended Attributes, Ressourcen-Forks
- **Hardlinks:** Eine A-Datei, die ein Hardlink auf eine B-Datei ist, zählt als identischer Inhalt. Zwei A-Dateien mit gleichem Inhalt brauchen zwei B-Exemplare (strenge 1:1-Zuordnung).
- **Projektverweise:** Pfade innerhalb von Projektdateien (Ableton, Final Cut, Logic, Blender usw.) und Finder-Aliase
- **Verweise von außerhalb:** Symlinks oder Aliase irgendwo sonst auf der Platte, die in A hineinzeigen. Nur Symlinks **in B** werden geprüft.

Der Bericht nennt diese Grenzen jedes Mal.

## Die fünf Urteile

| Urteil | Bedeutung | Löschen von A? |
|---|---|---|
| **CONTENT CONTAINMENT CONFIRMED** | Jede reguläre Datei von A hat eine eigene inhaltsgleiche Kopie in B, jeder Symlink von A hat ein Gegenstück in B, nichts wurde übersprungen außer bekanntem Systemmüll. | im geprüften Umfang unbedenklich |
| **CONFIRMED EXCEPT IGNORED FILES** | Wie oben, aber Dateien von A wurden wegen **selbst hinzugefügter** Ignorier-Muster nicht verglichen. | erst die Liste „IGNORED IN A“ prüfen |
| **INCONCLUSIVE** | Reguläre Dateien sind in B, aber etwas in A war nicht vergleichbar (Symlink ohne Gegenstück, Socket/Gerät/FIFO), oder der Scan war unvollständig (Fehler, Warnung, Abbruch, Änderung während des Scans, fehlende Rechte). | nein |
| **DO NOT DELETE A** | Symlinks in B zeigen nach A und würden brechen. | nein |
| **NOT COMPLETE** | Mindestens eine Datei existiert nur in A. Die Liste zeigt sie. | nein |

Fehler führen immer zu „mehr fehlt“, nie zu weniger. Ein falsches „CONFIRMED“ ist nur bei einem BLAKE3-Treffer ohne gleichen Inhalt oder bei unbemerkt geänderten Dateien denkbar. Das Urteil gilt nur für den Zustand zum Scan-Zeitpunkt.

## Änderungen gegenüber Version 2 (Antwort auf das Review)

1. **Symlinks:**
   - Symlinks in B, die nach A zeigen, blockieren jetzt („DO NOT DELETE A“). Geprüft wird der gespeicherte Zielpfad (lexikalisch aufgelöst, `..` eingerechnet) **und** der tatsächlich aufgelöste Ort (zusätzlich ohne Beachtung der Groß-/Kleinschreibung).
   - Symlinks in A zählen nur dann als vertreten, wenn ein Link in B **dasselbe auflöst**: innerhalb des eigenen Baums an derselben relativen Position (und diese Position existiert in B), oder auf denselben Ort außerhalb. Gleicher Linktext mit anderer Verzeichnistiefe (`../x`) gilt nicht mehr als gleich.
2. **Ignorierregeln:**
   - Es werden nur **Dateien** ignoriert, **nie Ordner**. Ein Ordner, der wie ein Muster heißt, wird normal verglichen.
   - Standardliste = bekannter Systemmüll (`.DS_Store, ._*, Thumbs.db, desktop.ini, .localized`). Jede zusätzliche Regel, die in A Dateien erfasst, senkt das Urteil auf „CONFIRMED EXCEPT IGNORED FILES“.
   - Ignorierte Dateien stehen mit Größe im Bericht und werden nie als Treffer benutzt.
3. **Validierung** (siehe unten): unabhängiges Prüfskript, Zufallstests, Rechte- und Abbruchfälle, Headless-Test auf echten Ordnern.

Aus Version 2 weiterhin enthalten: Dateidialog im eigenen Thread, Fortschritt (3 Schritte, Hashing mit Prozent), „Save report“, keine Änderung des OK-Texts anderer Popups.

## Installation auf einem Mac mit Apple Silicon

```bash
git clone --branch 12.0.2 https://github.com/qarmin/czkawka.git
python3 /PFAD/ZU/krokiet_folder_compare_patch/apply_patch.py "$PWD/czkawka"
cd czkawka
cargo test -p krokiet folder_ --locked
cargo build -p krokiet --release --locked
./target/release/krokiet
```

Rust mindestens 1.94.1 (rustup). Das Skript prüft die Version und bricht ab, wenn die erwarteten Textstellen nicht genau einmal vorkommen. **Nicht auf `master` patchen.** Falls `cargo test` oder der Build Fehler meldet, schick mir die Ausgabe, dann korrigiere ich gezielt.

## So gehst du sicher vor (empfohlene Reihenfolge)

1. **`cargo test -p krokiet folder_ --locked`** muss grün sein. Die Tests laufen mit dem echten Czkawka-Scanner und decken u. a. Mehrfachkopien, leere Dateien, Umbenennungen, Symlinks (inkl. Verweise von B nach A), Ignorierregeln, fehlende Leserechte und Abbruch ab.
2. **Probelauf an zwei kleinen Testordnern** (Kopien, nicht deine Originale): Datei in A ändern, eine Datei nur in A anlegen, einen Symlink in B auf A legen. Das Tool muss jeweils NOT COMPLETE / DO NOT DELETE A melden.
3. **Zweite Meinung mit dem unabhängigen Skript** für jedes Ordnerpaar, das du löschen willst:

   ```bash
   python3 verify_folders.py "/Volumes/Platte/A" "/Volumes/Platte/B"
   ```

   Gleiche Regeln, eigener Code, SHA-256, nur Standardbibliothek, nur lesend. Zwei verschiedene Programme müssen zum selben Urteil kommen (Exit-Code 0 nur bei CONFIRMED). Etwas langsamer, weil ein Thread.
4. **Ohne Oberfläche auf echten Ordnern** (z. B. für Skripte):

   ```bash
   FC_A="/Volumes/Platte/A" FC_B="/Volumes/Platte/B" \
   cargo test -p krokiet folder_compare::tests::real_folders --release -- --ignored --nocapture
   ```

   Optional `FC_IGNORE=".DS_Store, ._*"`.
5. **Beim Löschen:** erst in den Papierkorb bzw. in einen Ordner `_zu_loeschen` verschieben, einige Tage warten, dann endgültig löschen. Das Tool prüft nicht, was außerhalb von A und B auf A verweist (Aliase, Projektdateien).

## Neu in Version 4: Folder Relationships (Ordnerbeziehungen)

Nach einem Duplikat-Scan mit der Methode **Hash** (empfohlen: Blake3) listet die Schaltfläche „Folder relationships“ automatisch Ordnerpaare A und B. Die Ergebnisse des normalen Scans werden wiederverwendet, es wird nichts neu gehasht.

- **Identical**: gleiche Inhalte und gleiche Dateianzahl.
- **Contained**: alle verschiedenen Inhalte von A sind in B vorhanden, B hat mehr (Namen dürfen abweichen, z. B. „allefotos“ 2025 in einem Ordner von 2026). Steht „copy counts differ“ dabei, hat A Dateien mehrfach, B weniger oft.
- **Partial**: mindestens die eingestellte Abdeckung (Standard 90 %, einstellbar 50 bis 100 %), mit Anzeige, wie viele Dateien und Bytes von A nicht in B liegen.

Pro Zeile siehst du die Abdeckung nach Inhalten, Kopien und Bytes, Dateianzahl und Größe beider Ordner sowie Erstellungsdatum und neueste Datei von A und B (so erkennst du 2025 gegen 2026). Ein Klick auf eine Zeile öffnet den strengen „Compare folders“ Vergleich mit beiden Pfaden. **Nur dieser Vergleich liefert ein Urteil.** Die Liste ist ein Hinweis, keine Freigabe zum Löschen.

Regeln: Pro Ordner A wird nur der beste Partner B gezeigt (höchste Abdeckung, dann weniger Dateien, dann tieferer Ordner). Verschachtelte Ordner (A in B oder umgekehrt) werden nie gepaart. „Hide sub folders“ blendet Unterordner aus, wenn ein übergeordneter Ordner schon mindestens genauso stark gemeldet ist. Sehr häufige Inhalte (über 200 Kopien, z. B. Icons) werden nur nicht zur Kandidatensuche genutzt, zählen aber bei der Bewertung voll mit. Die Liste zeigt höchstens 3000 Zeilen.

Grenzen, bitte beachten:

- Es zählen nur Dateien, die der Scan nach seinen Filtern (Ordner, Ausschlüsse, Dateigröße, Endungen) betrachtet. Ein zusätzlicher Verzeichnisdurchlauf liest dazu die Ordnerstruktur nochmal ein (nur Metadaten, kein Hashing).
- Hardlinks, die der Scan ausblendet, gelten als „ohne Duplikat“ und senken die Abdeckung. Das Ergebnis wird dadurch vorsichtiger, nie großzügiger.
- Funktioniert nicht mit Referenzordnern und nicht bei abgebrochenem Scan. Bei anderen Prüfmethoden als Hash oder anderem Hash als Blake3 steht der verwendete Hash in der Statuszeile.
- Der Scan-Hook ändert die Duplikatanzeige nicht. Die Beziehungsliste erscheint kurz nach dem Scan-Ende. Starte währenddessen keinen neuen Scan.

Technische Änderungen an Czkawka: eine neue, nur lesende Methode `prepare_full_inventory` in `czkawka_core/src/tools/duplicate/core.rs` und ein kleiner Haken am Ende von `krokiet/src/connect_scan/duplicate.rs`.

Validierung der Engine (Linux-Sandbox): 1500 zufällige Ordnerbäume gegen eine unabhängige Python-Referenz, 0 Abweichungen. Leistungstest mit 530.000 Dateien und 15.000 Ordnern: unter einer Sekunde, mit und ohne Begrenzung häufiger Inhalte identisches Ergebnis. Fünf Unit-Tests im Modul. **Nicht geprüft:** Kompilierung, Oberfläche, echter Scan auf macOS. Die Folder-Compare-Validierung unten gilt unverändert.

## Validierung (was geprüft ist und was nicht)

**Hier ausgeführt (Linux-Sandbox):**

- Patch lässt sich auf frisches Original 12.0.2 anwenden, zweiter Lauf wird abgelehnt.
- Reine Vergleichslogik (Inventar, Zuordnung, Symlink-Regeln, Ignorierregeln, Urteil) gegen das unabhängige Python-Skript: 4500 zufällige Ordnerbäume mit Symlinks (relativ, absolut, in A, in B, außerhalb, verschiedene Tiefen), leeren Dateien, Mehrfachkopien, Systemmüll, `.mov`-Sonderregel und FIFOs. **0 Abweichungen**, alle fünf Urteile kamen vor.
- Unlesbares Verzeichnis und unlesbare Datei als normaler Benutzer: kein Urteil (INCONCLUSIVE). Abbruch: kein Urteil.

**Nicht geprüft, bitte bei dir testen:**

- Kompilierung der Rust- und Slint-Teile und der echte Czkawka-Scanner (Schritt 1 oben).
- Echte macOS-Dateisysteme (APFS, exFAT, HFS+), Netzlaufwerke, TCC-Rechtedialoge auf externen Volumes. Die Logik verwendet nur Dateiinhalt, Pfade und Symlinks, keine Inodes. Bei exFAT/APFS-Unterschieden (Unicode-Normalisierung, Groß-/Kleinschreibung, 2-Sekunden-Zeitstempel) fällt das Ergebnis im Zweifel auf „INCONCLUSIVE“ oder „fehlt“, nicht auf „bestätigt“. Das wurde aber nicht auf echten Laufwerken verifiziert.
- Beide Prüfverfahren stammen aus derselben Spezifikation. Der Test findet Implementierungsfehler, aber keine Denkfehler in den Regeln selbst.

## Quellcode, auf den sich die Erweiterung bezieht

- `krokiet/src/main.rs`, `krokiet/ui/main_window.slint`, `krokiet/src/connect_rfd.rs`
- `czkawka_core/src/tools/duplicate/{mod.rs,core.rs,traits.rs}`
- `czkawka_core/src/common/{tool_data.rs,progress_data.rs}`

Die GPL-3.0-Pflichten für eine Weitergabe eines gesamten Krokiet-Builds sind zu beachten. Original: https://github.com/qarmin/czkawka
