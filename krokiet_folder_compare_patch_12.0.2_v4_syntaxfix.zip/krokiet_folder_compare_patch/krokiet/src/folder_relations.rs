//! "Folder Relationships": finds folders whose content is identical, completely contained, or
//! mostly contained in another folder, on top of the result of a normal Krokiet duplicate scan.
//!
//! Read-only. Nothing is deleted, moved or changed. The result is a HINT for where to look:
//! the final decision belongs to the strict "Compare folders" check (click on a row).
//!
//! How it works
//! 1. After a duplicate scan (check method "Hash") the add-on lists every file the scan considered
//!    (same filters as the scan, via `DuplicateFinder::prepare_full_inventory`). Files in a duplicate
//!    group share a content id. Files without duplicate get their own id and can never match.
//! 2. Every folder gets, recursively, the multiset of content ids below it.
//! 3. An inverted index (content id -> folders containing it) finds candidate folder pairs without
//!    comparing every folder with every other one. Candidates are then evaluated exactly.
//! 4. For each folder A the best partner B is kept (highest coverage, then smallest B). Results of
//!    sub folders that are already covered by a reported parent folder are summarized.

use std::cmp::Ordering;
use std::collections::HashMap;
use std::ffi::OsString;
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::atomic::AtomicBool;
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{SystemTime, UNIX_EPOCH};

use chrono::{Local, TimeZone, Utc};
use czkawka_core::common::model::{CheckingMethod, FileEntry};
use czkawka_core::common::tool_data::CommonData;
use czkawka_core::tools::duplicate::DuplicateFinder;
use humansize::{BINARY, format_size};
use slint::{ComponentHandle, ModelRc, SharedString, VecModel, Weak};

use crate::MainWindow;

/// Content ids that occur more often than this are not used to FIND candidates (they are common
/// files such as icons or licence texts). They still count fully when a candidate is evaluated.
const DEFAULT_COMMON_CAP: u32 = 200;
/// Maximum number of rows handed to the user interface.
const ROW_LIMIT: usize = 3000;

// ---- PURE-BEGIN (no Czkawka, no Slint: extracted and tested separately) ----

pub(crate) struct InputFile {
    pub path: PathBuf,
    pub size: u64,
    pub modified: u64,
    /// Number of the duplicate group (files with identical content), None for files without duplicate.
    pub group: Option<u32>,
}

struct Node {
    parent: Option<u32>,
    name: OsString,
    total_files: u64,
    total_bytes: u64,
    /// Files below this folder that have no identical file anywhere in the scan (cannot be matched).
    unique_files: u64,
    newest: u64,
    /// Recursive multiset of content ids that occur at least twice in the scan: (id, copies), sorted by id.
    shared: Vec<(u32, u32)>,
}

pub(crate) struct FolderIndex {
    nodes: Vec<Node>,
    id_size: Vec<u64>,
    id_count: Vec<u32>,
    tin: Vec<u32>,
    tout: Vec<u32>,
    pub(crate) hash_label: String,
    pub(crate) file_count: u64,
}

fn node_for(dir: &Path, nodes: &mut Vec<Node>, dirs: &mut HashMap<PathBuf, u32>, direct: &mut Vec<Vec<u32>>) -> u32 {
    if let Some(&index) = dirs.get(dir) {
        return index;
    }
    let mut chain: Vec<&Path> = Vec::new();
    let mut current = dir;
    let mut parent_index: Option<u32> = None;
    loop {
        if let Some(&index) = dirs.get(current) {
            parent_index = Some(index);
            break;
        }
        chain.push(current);
        match current.parent() {
            Some(parent) if !parent.as_os_str().is_empty() => current = parent,
            _ => break,
        }
    }
    for directory in chain.into_iter().rev() {
        let index = nodes.len() as u32;
        let name = directory.file_name().map_or_else(|| directory.as_os_str().to_os_string(), std::ffi::OsStr::to_os_string);
        nodes.push(Node {
            parent: parent_index,
            name,
            total_files: 0,
            total_bytes: 0,
            unique_files: 0,
            newest: 0,
            shared: Vec::new(),
        });
        direct.push(Vec::new());
        dirs.insert(directory.to_path_buf(), index);
        parent_index = Some(index);
    }
    parent_index.unwrap_or(0)
}

pub(crate) fn build_index(files: Vec<InputFile>, hash_label: String) -> FolderIndex {
    // Raw content ids: duplicate group g -> g + 1, zero byte files -> 0, everything else has no id.
    let max_group = files.iter().filter_map(|f| f.group).max().map_or(0, |g| g as usize + 1);
    let id_space = max_group + 1;
    let raw_id = |f: &InputFile| -> Option<u32> {
        match f.group {
            Some(g) => Some(g + 1),
            None if f.size == 0 => Some(0),
            None => None,
        }
    };
    let mut id_count = vec![0u32; id_space];
    let mut id_size = vec![0u64; id_space];
    for file in &files {
        if let Some(id) = raw_id(file) {
            id_count[id as usize] += 1;
            id_size[id as usize] = file.size;
        }
    }

    let mut nodes: Vec<Node> = Vec::new();
    let mut dirs: HashMap<PathBuf, u32> = HashMap::new();
    let mut direct: Vec<Vec<u32>> = Vec::new();
    let file_count = files.len() as u64;
    for file in &files {
        let dir = file.path.parent().unwrap_or_else(|| Path::new("/"));
        let index = node_for(dir, &mut nodes, &mut dirs, &mut direct) as usize;
        let node = &mut nodes[index];
        node.total_files += 1;
        node.total_bytes += file.size;
        node.newest = node.newest.max(file.modified);
        match raw_id(file) {
            Some(id) if id_count[id as usize] >= 2 => direct[index].push(id),
            _ => node.unique_files += 1,
        }
    }
    drop(dirs);

    // Bottom-up aggregation. Children always have a larger index than their parent.
    let count = nodes.len();
    let mut acc: Vec<Vec<(u32, u32)>> = vec![Vec::new(); count];
    for n in (0..count).rev() {
        let mut list = std::mem::take(&mut acc[n]);
        list.extend(direct[n].iter().map(|&id| (id, 1)));
        list.sort_unstable_by_key(|entry| entry.0);
        let mut merged: Vec<(u32, u32)> = Vec::with_capacity(list.len());
        for (id, copies) in list {
            match merged.last_mut() {
                Some(last) if last.0 == id => last.1 += copies,
                _ => merged.push((id, copies)),
            }
        }
        merged.shrink_to_fit();
        if let Some(parent) = nodes[n].parent {
            let parent = parent as usize;
            acc[parent].extend(merged.iter().copied());
            let (files_n, bytes_n, unique_n, newest_n) = (nodes[n].total_files, nodes[n].total_bytes, nodes[n].unique_files, nodes[n].newest);
            nodes[parent].total_files += files_n;
            nodes[parent].total_bytes += bytes_n;
            nodes[parent].unique_files += unique_n;
            nodes[parent].newest = nodes[parent].newest.max(newest_n);
        }
        nodes[n].shared = merged;
    }

    // Euler tour numbers for O(1) "is nested" tests.
    let mut children: Vec<Vec<u32>> = vec![Vec::new(); count];
    let mut roots: Vec<u32> = Vec::new();
    for (index, node) in nodes.iter().enumerate() {
        match node.parent {
            Some(parent) => children[parent as usize].push(index as u32),
            None => roots.push(index as u32),
        }
    }
    let mut tin = vec![0u32; count];
    let mut tout = vec![0u32; count];
    let mut clock = 0u32;
    let mut stack: Vec<(u32, usize)> = Vec::new();
    for root in roots {
        tin[root as usize] = clock;
        clock += 1;
        stack.push((root, 0));
        while let Some((node, position)) = stack.last().copied() {
            if let Some(&child) = children[node as usize].get(position) {
                if let Some(top) = stack.last_mut() {
                    top.1 += 1;
                }
                tin[child as usize] = clock;
                clock += 1;
                stack.push((child, 0));
            } else {
                tout[node as usize] = clock;
                stack.pop();
            }
        }
    }

    FolderIndex {
        nodes,
        id_size,
        id_count,
        tin,
        tout,
        hash_label,
        file_count,
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub(crate) enum Kind {
    /// At least the threshold of A's distinct contents exist in B, but not all.
    Partial,
    /// All distinct contents of A exist in B (B has more).
    Contained,
    /// A and B hold exactly the same contents with the same number of copies.
    Identical,
}

#[derive(Debug, Clone)]
pub(crate) struct Relation {
    a: u32,
    b: u32,
    kind: Kind,
    content_common: u64,
    content_total: u64,
    copies_common: u64,
    copies_total: u64,
    bytes_common: u64,
    bytes_total: u64,
    b_files: u64,
    b_bytes: u64,
}

pub(crate) struct Params {
    pub min_files: u64,
    pub threshold_permille: u32,
    pub common_cap: u32,
    pub summarize: bool,
}

impl FolderIndex {
    fn nested(&self, a: u32, b: u32) -> bool {
        let (a, b) = (a as usize, b as usize);
        a == b || (self.tin[a] < self.tin[b] && self.tin[b] < self.tout[a]) || (self.tin[b] < self.tin[a] && self.tin[a] < self.tout[b])
    }

    fn depth(&self, n: u32) -> usize {
        let mut depth = 0;
        let mut current = self.nodes[n as usize].parent;
        while let Some(index) = current {
            depth += 1;
            current = self.nodes[index as usize].parent;
        }
        depth
    }

    fn node_path(&self, n: u32) -> PathBuf {
        let mut names: Vec<&OsString> = Vec::new();
        let mut current = Some(n);
        while let Some(index) = current {
            let node = &self.nodes[index as usize];
            names.push(&node.name);
            current = node.parent;
        }
        let mut path = PathBuf::new();
        for name in names.into_iter().rev() {
            path.push(name);
        }
        path
    }

    fn evaluate(&self, a: u32, b: u32, params: &Params) -> Option<Relation> {
        let (node_a, node_b) = (&self.nodes[a as usize], &self.nodes[b as usize]);
        let (mut content_common, mut copies_common, mut bytes_common) = (0u64, 0u64, 0u64);
        for &(id, copies_a) in &node_a.shared {
            if let Ok(position) = node_b.shared.binary_search_by_key(&id, |entry| entry.0) {
                let copies_b = node_b.shared[position].1;
                let matched = u64::from(copies_a.min(copies_b));
                content_common += 1;
                copies_common += matched;
                bytes_common += matched * self.id_size[id as usize];
            }
        }
        let content_total = node_a.shared.len() as u64 + node_a.unique_files;
        if content_total == 0 || u128::from(content_common) * 1000 < u128::from(params.threshold_permille) * u128::from(content_total) {
            return None;
        }
        let kind = if copies_common == node_a.total_files && node_a.total_files == node_b.total_files {
            Kind::Identical
        } else if content_common == content_total {
            Kind::Contained
        } else {
            Kind::Partial
        };
        Some(Relation {
            a,
            b,
            kind,
            content_common,
            content_total,
            copies_common,
            copies_total: node_a.total_files,
            bytes_common,
            bytes_total: node_a.total_bytes,
            b_files: node_b.total_files,
            b_bytes: node_b.total_bytes,
        })
    }

    /// Is `x` a better partner for the same A than `y`? Higher coverage, then fewer files in B, then the deeper (more specific) folder, then path.
    fn better(&self, x: &Relation, y: &Relation) -> bool {
        x.content_common
            .cmp(&y.content_common)
            .then(x.copies_common.cmp(&y.copies_common))
            .then(y.b_files.cmp(&x.b_files))
            .then_with(|| self.depth(x.b).cmp(&self.depth(y.b)))
            .then_with(|| self.node_path(y.b).cmp(&self.node_path(x.b)))
            == Ordering::Greater
    }
}

pub(crate) fn analyze(index: &FolderIndex, params: &Params) -> Vec<Relation> {
    let node_count = index.nodes.len();
    // Inverted index: content id -> folders (on every level) whose subtree contains it.
    let mut occurrences: Vec<Vec<u32>> = vec![Vec::new(); index.id_count.len()];
    for (n, node) in index.nodes.iter().enumerate() {
        for &(id, _) in &node.shared {
            occurrences[id as usize].push(n as u32);
        }
    }

    let mut hits = vec![0u32; node_count];
    let mut touched: Vec<u32> = Vec::new();
    let mut best: Vec<Relation> = Vec::new();
    for a in 0..node_count as u32 {
        let node_a = &index.nodes[a as usize];
        if node_a.total_files < params.min_files || node_a.total_bytes == 0 {
            continue;
        }
        let content_total = node_a.shared.len() as u64 + node_a.unique_files;
        let needed = (u128::from(params.threshold_permille) * u128::from(content_total)).div_ceil(1000).max(1) as u64;
        let mut capped_in_a = 0u64;
        for &(id, _) in &node_a.shared {
            if index.id_count[id as usize] > params.common_cap {
                capped_in_a += 1;
                continue;
            }
            for &b in &occurrences[id as usize] {
                if hits[b as usize] == 0 {
                    touched.push(b);
                }
                hits[b as usize] += 1;
            }
        }
        let mut chosen: Option<Relation> = None;
        for &b in &touched {
            let enough = u64::from(hits[b as usize]) + capped_in_a >= needed;
            hits[b as usize] = 0;
            if !enough || index.nested(a, b) {
                continue;
            }
            if let Some(relation) = index.evaluate(a, b, params) {
                let replace = chosen.as_ref().is_none_or(|current| index.better(&relation, current));
                if replace {
                    chosen = Some(relation);
                }
            }
        }
        touched.clear();
        if let Some(relation) = chosen {
            best.push(relation);
        }
    }

    // Kind of the chosen partner per folder, before any summarizing.
    let kind_of: HashMap<u32, Kind> = best.iter().map(|r| (r.a, r.kind)).collect();
    let mut keep: Vec<Relation> = Vec::new();
    for relation in &best {
        if params.summarize {
            // Hide a folder if one of its parents is already reported with at least the same strength.
            let mut parent = index.nodes[relation.a as usize].parent;
            let mut covered = false;
            while let Some(p) = parent {
                if kind_of.get(&p).is_some_and(|kind| *kind >= relation.kind) {
                    covered = true;
                    break;
                }
                parent = index.nodes[p as usize].parent;
            }
            if covered {
                continue;
            }
        }
        keep.push(relation.clone());
    }

    // An identical pair is found from both sides: report it once.
    let pairs: HashMap<(u32, u32), ()> = keep.iter().map(|r| ((r.a, r.b), ())).collect();
    keep.retain(|r| r.kind != Kind::Identical || !pairs.contains_key(&(r.b, r.a)) || index.node_path(r.a) < index.node_path(r.b));

    keep.sort_by(|x, y| {
        y.kind
            .cmp(&x.kind)
            .then_with(|| (u128::from(y.content_common) * u128::from(x.content_total)).cmp(&(u128::from(x.content_common) * u128::from(y.content_total))))
            .then(y.bytes_total.cmp(&x.bytes_total))
            .then_with(|| index.node_path(x.a).cmp(&index.node_path(y.a)))
    });
    keep
}

// ---- PURE-END ----

fn kind_label(relation: &Relation) -> &'static str {
    match relation.kind {
        Kind::Identical => "Identical",
        Kind::Contained if relation.copies_common == relation.copies_total => "Contained",
        Kind::Contained => "Contained (copy counts differ)",
        Kind::Partial => "Partial",
    }
}

fn permille(part: u64, total: u64) -> String {
    if total == 0 {
        return "-".to_owned();
    }
    // Round DOWN so that 99.96 % never shows as 100.0 %.
    let value = (u128::from(part) * 1000 / u128::from(total)) as f64 / 10.0;
    format!("{value:.1} %")
}

fn day(seconds: u64) -> String {
    Utc.timestamp_opt(seconds as i64, 0).single().unwrap_or_default().with_timezone(&Local).format("%Y-%m-%d").to_string()
}

fn created_day(path: &Path) -> String {
    fs::metadata(path)
        .and_then(|m| m.created())
        .ok()
        .and_then(|t| t.duration_since(UNIX_EPOCH).ok())
        .map_or_else(|| "?".to_owned(), |d| day(d.as_secs()))
}

fn to_rows(index: &FolderIndex, relations: &[Relation]) -> Vec<Vec<String>> {
    relations
        .iter()
        .take(ROW_LIMIT)
        .map(|r| {
            let (path_a, path_b) = (index.node_path(r.a), index.node_path(r.b));
            let missing_files = r.copies_total - r.copies_common;
            let missing_bytes = r.bytes_total - r.bytes_common;
            let dates = format!(
                "A: created {}, newest file {}   |   B: created {}, newest file {}",
                created_day(&path_a),
                day(index.nodes[r.a as usize].newest),
                created_day(&path_b),
                day(index.nodes[r.b as usize].newest)
            );
            vec![
                kind_label(r).to_owned(),
                path_a.display().to_string(),
                path_b.display().to_string(),
                permille(r.content_common, r.content_total),
                permille(r.copies_common, r.copies_total),
                permille(r.bytes_common, r.bytes_total),
                format!("{} files, {}", r.copies_total, format_size(r.bytes_total, BINARY)),
                format!("{} files, {}", r.b_files, format_size(r.b_bytes, BINARY)),
                if missing_files == 0 { "nothing missing".to_owned() } else { format!("not covered: {missing_files} files, {}", format_size(missing_bytes, BINARY)) },
                dates,
            ]
        })
        .collect()
}

fn to_model(rows: Vec<Vec<String>>) -> ModelRc<ModelRc<SharedString>> {
    let rows: Vec<ModelRc<SharedString>> = rows.into_iter().map(|row| ModelRc::new(VecModel::from(row.into_iter().map(SharedString::from).collect::<Vec<_>>()))).collect();
    ModelRc::new(VecModel::from(rows))
}

static INDEX: Mutex<Option<Arc<FolderIndex>>> = Mutex::new(None);

fn store_index(index: Option<Arc<FolderIndex>>) {
    if let Ok(mut guard) = INDEX.lock() {
        *guard = index;
    }
}

fn run_analysis(index: &FolderIndex, params: &Params) -> (Vec<Vec<String>>, String) {
    let started = SystemTime::now();
    let relations = analyze(index, params);
    let (identical, contained, partial) = relations.iter().fold((0, 0, 0), |(i, c, p), r| match r.kind {
        Kind::Identical => (i + 1, c, p),
        Kind::Contained => (i, c + 1, p),
        Kind::Partial => (i, c, p + 1),
    });
    let shown = relations.len().min(ROW_LIMIT);
    let seconds = started.elapsed().map_or(0.0, |d| d.as_secs_f32());
    let summary = format!(
        "{} folders, {} files evaluated (hash: {}). Found {identical} identical, {contained} contained, {partial} partial. Showing {shown}. ({seconds:.1} s). Hints only: click a row for the strict check.",
        index.nodes.len(),
        index.file_count,
        index.hash_label
    );
    (to_rows(index, &relations), summary)
}

fn default_params() -> Params {
    Params {
        min_files: 5,
        threshold_permille: 900,
        common_cap: DEFAULT_COMMON_CAP,
        summarize: true,
    }
}

fn publish_state(weak: &Weak<MainWindow>, available: bool, status: String, rows: Option<Vec<Vec<String>>>) {
    let _ = weak.upgrade_in_event_loop(move |app| {
        app.set_folder_relations_available(available);
        app.set_folder_relations_status(status.into());
        if let Some(rows) = rows {
            app.set_folder_relations_rows(to_model(rows));
        }
    });
}

/// Everything captured from a finished duplicate scan. Created BEFORE the finder is moved into Krokiet's shared state.
pub(crate) struct ScanSnapshot {
    group_of: HashMap<PathBuf, u32>,
    hash_label: String,
    inventory_job: Box<dyn FnOnce() -> Option<Vec<FileEntry>>>,
}

pub(crate) fn prepare(tool: &DuplicateFinder, stop_flag: &Arc<AtomicBool>) -> Result<ScanSnapshot, String> {
    if tool.get_stopped_search() {
        return Err("The scan was stopped: no folder relationships.".to_owned());
    }
    let params = tool.get_params();
    if !matches!(params.check_method, CheckingMethod::Hash) {
        return Err("Folder relationships need the check method \"Hash\" in the duplicate scan.".to_owned());
    }
    if tool.get_use_reference() {
        return Err("Folder relationships do not support reference folders.".to_owned());
    }
    let mut group_of: HashMap<PathBuf, u32> = HashMap::new();
    for (group_number, group) in tool.get_files_sorted_by_hash().values().flatten().enumerate() {
        for entry in group {
            group_of.insert(entry.path.clone(), group_number as u32);
        }
    }
    Ok(ScanSnapshot {
        group_of,
        hash_label: format!("{:?}", params.hash_type),
        inventory_job: tool.prepare_full_inventory(stop_flag),
    })
}

/// Runs in the scan thread after the normal results were handed to the interface.
pub(crate) fn publish(weak: Weak<MainWindow>, snapshot: Result<ScanSnapshot, String>) {
    let snapshot = match snapshot {
        Ok(snapshot) => snapshot,
        Err(reason) => {
            store_index(None);
            publish_state(&weak, false, reason, Some(Vec::new()));
            return;
        }
    };
    let ScanSnapshot { group_of, hash_label, inventory_job } = snapshot;
    publish_state(&weak, false, "Folder relationships: reading the folder structure ...".to_owned(), None);
    let Some(files) = inventory_job() else {
        store_index(None);
        publish_state(&weak, false, "Folder relationships: stopped while reading the folder structure.".to_owned(), Some(Vec::new()));
        return;
    };
    let input: Vec<InputFile> = files
        .into_iter()
        .map(|file| {
            let group = group_of.get(&file.path).copied();
            InputFile {
                path: file.path,
                size: file.size,
                modified: file.modified_date,
                group,
            }
        })
        .collect();
    drop(group_of);
    let index = Arc::new(build_index(input, hash_label));
    store_index(Some(Arc::clone(&index)));
    let (rows, summary) = run_analysis(&index, &default_params());
    publish_state(&weak, true, summary, Some(rows));
}

pub(crate) fn connect_folder_relations(app: &MainWindow) {
    let weak = app.as_weak();
    app.on_folder_relations_analyze(move |threshold_percent, min_files, summarize| {
        let Some(app) = weak.upgrade() else { return };
        if app.get_folder_relations_busy() {
            return;
        }
        let index = INDEX.lock().ok().and_then(|guard| guard.clone());
        let Some(index) = index else {
            app.set_folder_relations_status("No scan data yet: run a duplicate scan with check method \"Hash\" first.".into());
            return;
        };
        app.set_folder_relations_busy(true);
        let weak = app.as_weak();
        thread::spawn(move || {
            let params = Params {
                min_files: u64::try_from(min_files.max(1)).unwrap_or(1),
                threshold_permille: u32::try_from(threshold_percent.clamp(50, 100)).unwrap_or(90) * 10,
                common_cap: DEFAULT_COMMON_CAP,
                summarize,
            };
            let (rows, summary) = run_analysis(&index, &params);
            let _ = weak.upgrade_in_event_loop(move |app| {
                app.set_folder_relations_rows(to_model(rows));
                app.set_folder_relations_status(summary.into());
                app.set_folder_relations_busy(false);
            });
        });
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    fn file(path: &str, size: u64, group: Option<u32>) -> InputFile {
        InputFile { path: PathBuf::from(path), size, modified: 1, group }
    }

    fn params(threshold_permille: u32) -> Params {
        Params { min_files: 1, threshold_permille, common_cap: DEFAULT_COMMON_CAP, summarize: false }
    }

    #[test]
    fn summarizing_reports_the_parent_instead_of_the_sub_folder() {
        let index = build_index(scenario(), "Blake3".to_owned());
        let relations = analyze(&index, &Params { summarize: true, ..params(900) });
        assert!(relations.iter().any(|r| index.node_path(r.a).ends_with("2025") && r.kind == Kind::Contained));
        assert!(relations.iter().all(|r| !index.node_path(r.a).ends_with("allefotos")));
    }

    /// 2025 folder with 10 files, 2026 folder with the same 10 files (other names) plus 5 new ones.
    fn scenario() -> Vec<InputFile> {
        let mut files = Vec::new();
        for i in 0..10u32 {
            files.push(file(&format!("/d/2025/allefotos/a{i}.jpg"), 100 + u64::from(i), Some(i)));
            files.push(file(&format!("/d/2026/neu/b{i}.jpg"), 100 + u64::from(i), Some(i)));
        }
        for i in 0..5u64 {
            files.push(file(&format!("/d/2026/neu/extra{i}.jpg"), 500 + i, None));
        }
        files
    }

    #[test]
    fn contained_with_different_names() {
        let index = build_index(scenario(), "Blake3".to_owned());
        let relations = analyze(&index, &params(900));
        let hit = relations.iter().find(|r| index.node_path(r.a).ends_with("allefotos")).expect("allefotos must be reported");
        assert_eq!(hit.kind, Kind::Contained);
        assert!(index.node_path(hit.b).ends_with("neu"));
        assert_eq!((hit.copies_common, hit.copies_total), (10, 10));
        assert_eq!(hit.b_files, 15);
    }

    #[test]
    fn partial_when_one_file_missing() {
        let mut files = scenario();
        files.push(file("/d/2025/allefotos/only_here.jpg", 999, None));
        let index = build_index(files, "Blake3".to_owned());
        assert!(analyze(&index, &params(1000)).iter().all(|r| !index.node_path(r.a).ends_with("allefotos")));
        let relations = analyze(&index, &params(900));
        let hit = relations.iter().find(|r| index.node_path(r.a).ends_with("allefotos")).expect("90 % threshold reports it");
        assert_eq!(hit.kind, Kind::Partial);
        assert_eq!(hit.copies_total - hit.copies_common, 1);
    }

    #[test]
    fn identical_is_reported_once() {
        let mut files = Vec::new();
        for i in 0..4u32 {
            files.push(file(&format!("/x/one/f{i}"), 10 + u64::from(i), Some(i)));
            files.push(file(&format!("/x/two/g{i}"), 10 + u64::from(i), Some(i)));
        }
        let index = build_index(files, "Blake3".to_owned());
        let relations = analyze(&index, &params(900));
        assert_eq!(relations.iter().filter(|r| r.kind == Kind::Identical).count(), 1);
    }

    #[test]
    fn unrelated_folders_report_nothing() {
        let files = vec![file("/x/a/f1", 5, None), file("/x/a/f2", 6, None), file("/x/b/f3", 7, None)];
        let index = build_index(files, "Blake3".to_owned());
        assert!(analyze(&index, &params(500)).is_empty());
    }
}
