#!/usr/bin/env python3
"""Independent cross-check for the Krokiet "Compare folders" audit.

Same question, separate implementation (Python standard library only, SHA-256):
"Does every file of folder A exist, by content, in folder B?"

    python3 verify_folders.py /path/to/A /path/to/B [--ignore ".DS_Store, ._*"] [--json]

Read-only. Never writes, moves or deletes anything. Slower than Krokiet (single thread),
so use it as a second opinion on the folder pairs you are about to delete.
Exit code 0 only for a full confirmation, 1 for everything else.

Rules (identical to the Krokiet add-on):
- Only file CONTENT is compared (not metadata, hardlink topology, references inside project files).
- Every A file needs its own B copy (strict 1:1, multiplicities count).
- Only regular FILES can be ignored by name, never folders. Patterns beyond the default junk list
  make the verdict "CONFIRMED EXCEPT IGNORED FILES".
- Symlinks are never followed. Links in B that point into A block the verdict. Links in A need an
  equivalent link in B that resolves to the same place.
- Any read error, special file in A or cancelled run is INCONCLUSIVE.
"""
import argparse
import hashlib
import json
import os
import posixpath
import re
import sys

DEFAULT_IGNORE = ".DS_Store, ._*, Thumbs.db, desktop.ini, .localized"


def parse_patterns(raw):
    out = []
    for item in re.split(r"[,\n]", raw):
        item = item.strip()
        if not item:
            continue
        if "/" in item or "\\" in item:
            raise ValueError(f"Ignore pattern '{item}' must be a file NAME, not a path.")
        if set(item) == {"*"}:
            raise ValueError(f"Ignore pattern '{item}' would ignore everything.")
        out.append(item)
    return out


def glob_match(pattern, name):
    regex = ".*".join(re.escape(part) for part in pattern.split("*"))
    return re.fullmatch(regex, name, flags=re.IGNORECASE | re.DOTALL) is not None


def is_ignored(name, patterns):
    return any(glob_match(p, name) for p in patterns)


class ScanError(Exception):
    pass


def inventory(root, patterns):
    inv = {"files": {}, "dirs": set(), "links": {}, "special": set(), "ignored": {}}
    stack = [root]
    while stack:
        current = stack.pop()
        try:
            entries = list(os.scandir(current))
        except OSError as exc:
            raise ScanError(f"Cannot list {current}: {exc}")
        for entry in entries:
            path = entry.path
            try:
                if entry.is_symlink():
                    target = os.readlink(path)
                    try:
                        canonical = os.path.realpath(path, strict=True)
                    except OSError:
                        canonical = None
                    inv["links"][path] = (target, canonical)
                elif entry.is_dir(follow_symlinks=False):
                    inv["dirs"].add(path)
                    stack.append(path)
                elif entry.is_file(follow_symlinks=False):
                    size = entry.stat(follow_symlinks=False).st_size
                    if is_ignored(entry.name, patterns):
                        inv["ignored"][path] = size
                    else:
                        inv["files"][path] = size
                else:
                    inv["special"].add(path)
            except OSError as exc:
                raise ScanError(f"Cannot stat {path}: {exc}")
    return inv


def file_hash(path):
    digest = hashlib.sha256()
    try:
        with open(path, "rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
    except OSError as exc:
        raise ScanError(f"Cannot read {path}: {exc}")
    return digest.hexdigest()


def resolve_target(link, target):
    if os.path.isabs(target):
        return posixpath.normpath(target)
    return posixpath.normpath(posixpath.join(posixpath.dirname(link), target))


def starts_with_ci(path, root):
    p = [c.lower() for c in path.split("/") if c]
    r = [c.lower() for c in root.split("/") if c]
    return len(p) >= len(r) and p[: len(r)] == r


def link_key(link, target, root):
    resolved = resolve_target(link, target)
    prefix = root.rstrip("/") + "/"
    if resolved == root:
        return ("in", "")
    if resolved.startswith(prefix):
        return ("in", resolved[len(prefix):])
    return ("out", resolved)


def exists_in(inv, root, rel):
    if rel == "":
        return True
    p = posixpath.join(root, rel)
    return p in inv["files"] or p in inv["dirs"] or p in inv["links"] or p in inv["ignored"] or p in inv["special"]


def audit(a, b, patterns):
    ia, ib = inventory(a, patterns), inventory(b, patterns)

    # files: group by size first (different sizes can never be equal), hash only candidates
    by_size_b = {}
    for path, size in ib["files"].items():
        by_size_b.setdefault(size, []).append(path)
    available = {}  # (size, hash) -> count of B copies
    sizes_in_a = {s for s in ia["files"].values()}
    for size in sizes_in_a:
        for path in by_size_b.get(size, []):
            key = (size, file_hash(path) if size > 0 else "")
            available[key] = available.get(key, 0) + 1
    missing = []
    for path in sorted(ia["files"]):
        size = ia["files"][path]
        if size not in by_size_b:
            missing.append(path)
            continue
        key = (size, file_hash(path) if size > 0 else "")
        if available.get(key, 0) > 0:
            available[key] -= 1
        else:
            missing.append(path)
    extra = len(ib["files"]) - (len(ia["files"]) - len(missing))

    # links
    avail_links = {}
    for link, (target, _c) in ib["links"].items():
        k = link_key(link, target, b)
        avail_links[k] = avail_links.get(k, 0) + 1
    missing_links = []
    for link in sorted(ia["links"]):
        target, _c = ia["links"][link]
        k = link_key(link, target, a)
        ok = avail_links.get(k, 0) > 0 and (k[0] == "out" or exists_in(ib, b, k[1]))
        if ok:
            avail_links[k] -= 1
        else:
            missing_links.append(link)
    deps = []
    for link, (target, canonical) in ib["links"].items():
        if starts_with_ci(resolve_target(link, target), a) or (canonical is not None and starts_with_ci(canonical, a)):
            deps.append(link)

    junk = parse_patterns(DEFAULT_IGNORE)
    custom_ignored = [p for p in ia["ignored"] if not is_ignored(os.path.basename(p), junk)]

    if missing:
        verdict = "NOT COMPLETE"
    elif deps:
        verdict = "DEPENDENCY ON A"
    elif missing_links or ia["special"]:
        verdict = "INCONCLUSIVE"
    elif custom_ignored:
        verdict = "CONFIRMED EXCEPT IGNORED FILES"
    else:
        verdict = "CONFIRMED"
    return {
        "verdict": verdict,
        "files_a": len(ia["files"]),
        "files_b": len(ib["files"]),
        "missing": len(missing),
        "extra": extra,
        "missing_links": len(missing_links),
        "links_into_a": len(deps),
        "special_a": len(ia["special"]),
        "ignored_a": len(ia["ignored"]),
        "custom_ignored_a": len(custom_ignored),
        "missing_files": [os.path.relpath(p, a) for p in missing],
        "missing_link_list": [os.path.relpath(p, a) for p in missing_links],
        "links_into_a_list": [os.path.relpath(p, b) for p in deps],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("a", help="folder A (candidate to remove)")
    parser.add_argument("b", help="folder B (folder to keep)")
    parser.add_argument("--ignore", default=DEFAULT_IGNORE, help="file NAME patterns to ignore, comma separated")
    parser.add_argument("--json", action="store_true", help="machine readable output")
    args = parser.parse_args()
    try:
        patterns = parse_patterns(args.ignore)
        a, b = os.path.realpath(args.a), os.path.realpath(args.b)
        if not (os.path.isdir(a) and os.path.isdir(b)):
            raise ScanError("A and B must both be directories.")
        if a == b or a.startswith(b + "/") or b.startswith(a + "/"):
            raise ScanError("A and B must be separate, non-nested directories.")
        result = audit(a, b, patterns)
    except (ScanError, ValueError) as exc:
        result = {"verdict": "INCONCLUSIVE", "error": str(exc)}
    if args.json:
        print(json.dumps(result))
    else:
        print(f"RESULT: {result['verdict']}")
        if "error" in result:
            print(result["error"])
        else:
            print(f"A: {result['files_a']} files | B: {result['files_b']} files | missing from B: {result['missing']} | symlinks without equivalent: {result['missing_links']} | links in B into A: {result['links_into_a']}")
            for title, key in (("FILES ONLY IN A", "missing_files"), ("SYMLINKS IN A WITHOUT EQUIVALENT", "missing_link_list"), ("SYMLINKS IN B POINTING INTO A", "links_into_a_list")):
                if result[key]:
                    print(f"\n{title}:")
                    for item in result[key]:
                        print("  " + item)
    sys.exit(0 if result["verdict"] == "CONFIRMED" else 1)


if __name__ == "__main__":
    main()
