//! Best-effort, local stability log. Never stores file contents or credentials.
use std::backtrace::Backtrace;
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::PathBuf;
use std::sync::OnceLock;
use std::time::{SystemTime, UNIX_EPOCH};

static LOG: OnceLock<PathBuf> = OnceLock::new();
fn now() -> u128 { SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_millis() }

pub(crate) fn install() {
    let Some(home) = std::env::var_os("HOME") else { return; };
    let dir = PathBuf::from(home).join("Library/Logs/Krokiet Folder Compare");
    if fs::create_dir_all(&dir).is_err() { return; }
    let path = dir.join(format!("stability-{}-{}.txt", now(), std::process::id()));
    if LOG.set(path).is_err() { return; }
    let original = std::panic::take_hook();
    std::panic::set_hook(Box::new(move |info| {
        // Best effort: OOM/abort may prevent this hook from running. Write the
        // message BEFORE attempting backtrace allocation; no shared mutex.
        event(&format!("PANIC {info}"));
        event(&format!("PANIC backtrace:\n{}", Backtrace::force_capture()));
        original(info);
    }));
    checkpoint(&format!("START v22.5.1 pid={} rust={} slint={}", std::process::id(),
        option_env!("KROKIET_RUST_VERSION").unwrap_or("unknown"),
        option_env!("KROKIET_SLINT_VERSION").unwrap_or("unknown")));
}

pub(crate) fn event(message: &str) {
    let Some(path) = LOG.get() else { return; };
    let mut opts = OpenOptions::new();
    opts.create(true).append(true);
    #[cfg(unix)] { use std::os::unix::fs::OpenOptionsExt; opts.mode(0o600); }
    if let Ok(mut f) = opts.open(path) {
        let _ = writeln!(f, "{} {:?} {}", now(), std::thread::current().id(), message);
        let _ = f.flush();
    }
}

/// RSS is sampled only at major stages, not at every GUI click or file. The
/// measurement is best-effort; unavailable RSS is explicitly labelled.
pub(crate) fn checkpoint(message: &str) {
    if LOG.get().is_none() { return; }
    let rss = std::process::Command::new("/bin/ps").args(["-o", "rss=", "-p", &std::process::id().to_string()])
        .output().ok().filter(|o| o.status.success()).and_then(|o| String::from_utf8(o.stdout).ok())
        .and_then(|s| s.trim().parse::<u64>().ok());
    event(&format!("{message} | RSS KiB={}", rss.map(|n| n.to_string()).unwrap_or_else(|| "unavailable".into())));
}
