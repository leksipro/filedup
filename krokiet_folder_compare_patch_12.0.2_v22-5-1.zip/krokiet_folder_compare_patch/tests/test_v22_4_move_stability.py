"""Static release wiring tests. Cargo executes real Rust fixtures on macOS CI."""
from pathlib import Path
import unittest
import re
R=Path(__file__).resolve().parents[1]
RUST=(R/'krokiet/src/folder_audit_actions.rs').read_text()
UI=(R/'krokiet/ui/popups/popup_folder_workspace.slint').read_text()
YML=(R/'.github/workflows/build-krokiet.yml').read_text()
class MoveStabilityTests(unittest.TestCase):
    def test_move_acl_requires_explicit_opt_in_in_both_directions(self):
        self.assertIn('private property <bool> move_acl: false',UI)
        self.assertEqual(UI.count('root.merge_is_move = true; root.move_acl = false;'),2)
        for action in ('move_selected_a_to_b:acl','move_selected_b_to_a:acl'):
            self.assertIn(action,RUST)
        self.assertIn('&& action.ends_with(":acl")',RUST)
        self.assertIn('from,to,&batch,&links,mode,&mut acl_excluded,is_move,merge_to_a',RUST)
        self.assertIn('let left = (if from_b { entry.b.as_deref() } else { entry.a.as_deref() })',RUST)
    def test_move_acl_preflight_has_no_target_yet(self):
        plan=RUST[RUST.index('fn prepare_backup_acl_batch('):RUST.index('// Native macOS trash:')]
        self.assertIn('if move_source {',plan)
        self.assertIn('preview_destination(b, left.strip_prefix(a)',plan)
        self.assertIn('preflight_trash_pair_with_mode(a,b,left,right,mode,entry.fast_proof)?',plan)
        self.assertIn('await_operation_decision(weak,message,false,true)',plan)
        self.assertNotIn('remove_verified_source(',plan)
    def test_transfer_still_verifies_before_source_removal(self):
        region=RUST[RUST.index('Ok(MoveStage::PendingTrash(dest)) => {'):RUST.index('Err(e) => { failed_count+=1; if !policy.failed',RUST.index('Ok(MoveStage::PendingTrash(dest)) => {'))]
        self.assertLess(region.index('ZIEL VERIFIZIERT'),region.index('remove_verified_source(src, false, false)'))
        self.assertLess(region.index('preflight_trash_pair_with_mode(from,to,src,&dest,TrashCheckMode::Bytes,None)?'),region.index('remove_verified_source(src, false, false)'))
        self.assertIn('verify_mac_extra(src, &dest, true)?',region)
        self.assertIn('FINDER WIEDERHOLUNG MOVE',region)
        self.assertIn('NUR KOPIERT',region)
    def test_gui_no_virtual_listview_and_group_page_is_bounded(self):
        self.assertNotIn('ListView',UI)
        self.assertEqual(len(re.findall(r'\bScrollView\s*\{',UI)),3)
        self.assertIn('for group in root.audit_subfolders',UI)
        self.assertIn('session.groups.iter().skip(start).take(end-start)',RUST)
        self.assertIn('(start+40).min(len)',RUST)
        self.assertIn('const PAGE: usize = 120;',RUST)
        self.assertIn('const INITIAL_VISIBLE: usize = PAGE;',RUST)
        self.assertNotIn('saturating_add(VISIBLE_INCREMENT)',RUST)
    def test_page_mapping_and_same_path_filter(self):
        for token in ('page_bounds(session, displayed.len())','page_bounds(session,visible.len())','page_bounds(session,shown.len())','"same_path" => e.kind == Kind::Same && same_relative_path(session,e)','fn v22_4_paging_is_bounded_and_nonoverlapping()','fn v22_4_nested_copy_preserves_relative_paths_both_directions()','fn v22_4_same_path_filter_excludes_other_relative_paths()'):
            self.assertIn(token,RUST)
        self.assertIn('root.audit_action("filter:same_path", 0)',UI)
    def test_build_reuses_release_profile_and_dependencies(self):
        self.assertIn('Swatinem/rust-cache@v2',YML)
        self.assertIn('czkawka -> target',YML)
        self.assertIn('shared-key: krokiet-12-0-2-macos-arm64-release-v1',YML)
        self.assertIn('cargo test -p krokiet --locked --release --target aarch64-apple-darwin',YML)
        self.assertIn('cargo build -p krokiet --release --locked --target aarch64-apple-darwin',YML)
        self.assertNotIn('rm -rf czkawka/target',YML)
        self.assertIn('tests/test_macos_backup_acl.sh',YML)
        self.assertIn('python3 -m unittest discover',YML)
if __name__=='__main__': unittest.main()
