"""Static wiring regressions; Rust and real macOS ACL tests run on the CI runner."""
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[1]
RUST=(ROOT/'krokiet/src/folder_audit_actions.rs').read_text()
UI=(ROOT/'krokiet/ui/popups/popup_folder_workspace.slint').read_text()
SH=(ROOT/'krokiet/src/macos_backup_acl.sh').read_text()
INSTALL=(ROOT/'apply_patch.py').read_text()
YML=(ROOT/'.github/workflows/build-krokiet.yml').read_text()
ACL=RUST[RUST.index('fn acl_text_has_deny('):RUST.index('// Native macOS trash:')]

class ACLModes(unittest.TestCase):
    def test_mode_selector_independent_of_action(self):
        selector=next(line for line in UI.splitlines() if 'model: ["Schnell (Index)", "Aktueller Hash", "Bytevergleich"]' in line)
        self.assertNotIn('enabled:',selector)
        for operation in ('trash_selected','backup_acl_trash_selected','finder_retry_selected','force_delete_selected'):
            self.assertIn(f'"{operation}:" + root.trash_check_suffix', UI)
        self.assertIn('removal_check_mode(action.as_str())', RUST)
        self.assertNotIn('else if backup_acl { TrashCheckMode::Bytes }', RUST)

    def test_same_verification_before_and_after_acl(self):
        self.assertIn('preflight_trash_pair_with_mode(a,b,left,right,mode,entry.fast_proof)?', ACL)
        self.assertIn('verified_remove_pair(&a, &b, left, right, mode, entry.fast_proof',RUST)
        self.assertIn('verified_remove_pair(&a,&b,left,right,mode,entry.fast_proof,&links,false,true)',RUST)
        self.assertIn('verify_mac_extra(left, right, false)?',RUST)
        self.assertIn('let Some(p) = proof else',RUST)

    def test_backup_name_and_xattrs_no_longer_required(self):
        for code in (ACL,SH):
            self.assertNotIn('_CCC SafetyNet',code)
            self.assertNotIn('_kTimeMachineNewestSnapshot',code)
        self.assertIn('/Users/',SH)
        self.assertIn('backups.backupdb',SH)
        self.assertIn('[ "$path" = "$boundary" ]',SH)
        self.assertIn('parent == boundary.as_path()',ACL)

    def test_exclusions_never_reenter_batch(self):
        self.assertIn('excluded.insert(*index);',ACL)
        self.assertIn('ACL WEITERHIN GESCHÜTZT / NICHT PRÜFBAR',ACL)
        self.assertIn('batch.retain(|(index,_)| !acl_excluded.contains(index))',RUST)
        self.assertIn('failed_count += excluded',RUST)
        self.assertIn('übrige Dateien ohne weitere ACL-Änderung versuchen?',RUST)

    def test_acl_authorization_is_separate_from_error_skipping(self):
        self.assertIn('await_operation_decision(weak,message,false,true) != 1',ACL)
        self.assertIn('enabled: !root.operation_confirm_acl && root.operation_pause != ""',UI)
        self.assertIn('ACL ändern + fortfahren',UI)
        self.assertIn('operation_confirm_acl: root.folder_operation_confirm_acl',INSTALL)
        self.assertIn('"error_skip_all" if !app.get_folder_operation_confirm_acl()',RUST)

    def test_control_names_and_identity_checks(self):
        self.assertIn('arg("-blde")',ACL)
        self.assertIn('/bin/ls -blde "$path"',SH)
        self.assertIn('ACL SKIP changed before chmod',SH)
        self.assertIn('ACL SKIP shared inode',SH)
        fixture=(ROOT/'tests/test_macos_backup_acl.sh').read_text()
        self.assertIn("$'Icon\\r'",fixture)
        self.assertIn('Ordinary Archive',fixture)
        self.assertIn('/bin/rm "$file" "$control"',fixture)
        self.assertNotIn('xattr -w',fixture)

    def test_release_workflow(self):
        self.assertIn('v22-5-1.zip',YML)
        self.assertIn('CFBundleVersion</key><string>225.1',YML)
        self.assertIn('local.krokiet.foldercompare.v22</string>',YML)
        self.assertIn('tests/test_macos_backup_acl.sh',YML)

if __name__=='__main__': unittest.main()
