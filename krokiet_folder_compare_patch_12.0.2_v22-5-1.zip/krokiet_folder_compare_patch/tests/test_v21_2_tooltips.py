"""Regression test: Tooltip.text is styled-text in Slint 1.17+."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / "krokiet/ui/popups/popup_folder_workspace.slint"

class TestSlintTooltips(unittest.TestCase):
    def test_every_tooltip_uses_styled_text(self):
        source = UI.read_text()
        total = len(re.findall(r"Tooltip\s*\{", source))
        self.assertGreaterEqual(total, 16)
        self.assertEqual(len(re.findall(r"Tooltip\s*\{\s*text:\s*@markdown\(", source)), total)

    def test_dynamic_tooltips_preserve_values(self):
        source = UI.read_text()
        for snippet in (
            '@markdown("\\{root.left_path}")',
            '@markdown("\\{root.right_path}")',
            '@markdown("A: \\{root.left_path}/\\{file[0]}',
            '@markdown("\\{root.audit_rows[root.audit_selected][5]}")',
            '@markdown("\\{root.audit_status != ',
        ):
            self.assertIn(snippet, source)

if __name__ == "__main__": unittest.main()
