"""Contract checks for the v20 three-pane A-first native Slint workspace.
These structural tests do NOT substitute for a real Slint build.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / 'krokiet/ui/popups/popup_folder_workspace.slint'

class WorkspaceUI(unittest.TestCase):
    def test_three_pane_responsive_structure(self):
        t = UI.read_text()
        for value in ('export component PopupFolderWorkspace', 'popup_min_height: 0px',
                      'root.width < 1050px', 'ORDNERPAARE', 'UNTERORDNER IN A',
                      'DATEI A (relativ)', 'audit_subfolders', 'root.show_pairs',
                      'root.show_groups', 'vertical-stretch: 1', 'Tooltip { text:'):
            self.assertIn(value, t)
        self.assertIn('root.open_compare(row[3], row[7])', t)

    def test_action_bar_and_safety(self):
        t = UI.read_text()
        for value in ('"filter:only_a"', '"filter:only_b"', '"filter:conflict"',
                      '"filter:same"', '"filter:all_pairs"',
                      '"merge_selected_a_to_b"', '"merge_selected_b_to_a"',
                      '"trash_selected:"', '"select_all"', '"select_page"',
                      '"clear_selection"', '"verify_selected"', '"verify_conflicts"',
                      '"select_scope:"', '"scope:"', '"load_more"', 'confirm_trash',
                      'confirm_merge', '"A/B tauschen"', '"Schnell (Index)"',
                      '"Aktueller Hash"', '"Bytevergleich"'):
            self.assertIn(value, t)
        self.assertNotIn('"remove_single_folder"', t)
        # Moving is restored; link rewriting remains absent.
        self.assertIn('"move_selected_a_to_b"', t)
        self.assertIn('"move_selected_b_to_a"', t)

    def test_session_refresh_does_not_relock(self):
        actions = (ROOT/'krokiet/src/folder_audit_actions.rs').read_text()
        block = actions.split('fn refresh_selection(weak: &Weak<MainWindow>) {',1)[1].split('pub(super) fn connect',1)[0]
        self.assertNotIn('update_metrics(&app)', block)
        self.assertIn('let values = SESSION.lock()', block)
        self.assertIn('set_audit_groups(&app, groups)', block)
        self.assertIn('set_counts(&app, counts)', block)

    def test_only_one_workspace_entry(self):
        installer=(ROOT/'apply_patch.py').read_text()
        self.assertIn('PopupFolderWorkspace', installer)
        self.assertNotIn('folder_compare_popup_window.show_popup()', installer)
        self.assertNotIn('folder_relations_popup_window.show_popup()', installer)
        self.assertIn('root.folder_compare_preview(a, b)', installer)
        self.assertIn('audit_subfolders: root.folder_audit_subfolders', installer)

if __name__ == '__main__': unittest.main()
