"""Source wiring guards; Rust tests run on the real macOS CI build."""
from pathlib import Path
import unittest
R=Path(__file__).resolve().parents[1]
INDEX=(R/'krokiet/src/folder_relations.rs').read_text()
AUDIT=(R/'krokiet/src/folder_audit_actions.rs').read_text()
UI=(R/'krokiet/ui/popups/popup_folder_workspace.slint').read_text()
DIAG=(R/'krokiet/src/folder_diagnostics.rs').read_text()
INSTALL=(R/'apply_patch.py').read_text()
YML=(R/'.github/workflows/build-krokiet.yml').read_text()
class StabilityTests(unittest.TestCase):
    def test_changed_paths_static_uses_lazy_initialization(self):
        # E0015 regression: HashSet::new is not a const initializer.
        self.assertIn('use std::sync::{Arc, LazyLock, Mutex};', INDEX)
        self.assertIn('static CHANGED_PATHS: LazyLock<Mutex<HashSet<PathBuf>>> = LazyLock::new(|| Mutex::new(HashSet::new()));', INDEX)
        self.assertNotIn('static CHANGED_PATHS: Mutex<HashSet<PathBuf>>', INDEX)
        self.assertIn('CHANGED_PATHS.lock()', INDEX)

    def test_operation_completion_only_queues_index_updates(self):
        part=INDEX.split('pub(crate) fn apply_manual_changes(',1)[1].split('fn rebuild_pending_index(',1)[0]
        self.assertIn('pending.extend(recorded)',part)
        self.assertIn('snapshot_path()',part)
        self.assertIn('VIEW.lock()',part)
        self.assertNotIn('build_index_checked(',part)
        self.assertNotIn('run_analysis(',part)
        self.assertIn('Ordnerindex aktualisieren',UI)
    def test_pending_replay_is_ordered_and_rejects_stale_fast_proofs(self):
        preview=INDEX.split('pub(crate) fn index_pair_preview(',1)[1].split('fn to_model(',1)[0]
        self.assertIn('PENDING_CHANGES.lock()',preview)
        self.assertIn('RECONCILING.load',preview)
        self.assertIn('file.fast_eligible = false',preview)
        self.assertIn('validate_final_changes(changes)?',INDEX)
        self.assertIn('fn v225_deferred_copy_then_trash_replays_without_old_source()',INDEX)
        self.assertIn('fn v225_deferred_removal_matches_fresh_analysis()',INDEX)
        self.assertIn('untouched.sort_unstable_by',INDEX)
    def test_rebuild_releases_old_index_before_replacement(self):
        part=INDEX.split('fn rebuild_pending_index(',1)[1].split('fn mark_uncertain_after_manual_change(',1)[0]
        self.assertLess(part.index('store_state(None, None)'),part.index('build_index_checked('))
        self.assertLess(part.index('drop(index)'),part.index('build_index_checked('))
        self.assertIn('STATE_WRITE.lock()',part)
    def test_paged_models_and_cache(self):
        self.assertIn('downcast_ref::<VecModel<ModelRc<SharedString>>>()',INDEX)
        self.assertIn('cells.set_row_data(j, value)',INDEX)
        self.assertIn('visible_cache.get_mut().take()',AUDIT)
        self.assertIn('counts_cache.set(None)',AUDIT)
        self.assertIn('fn v225_cache_reused_on_selection_and_invalidated_on_edit()',AUDIT)
        self.assertIn('group_page_bounds(session)',AUDIT)
        self.assertIn('folder_audit_group_page_info',INSTALL)
    def test_error_panel_permanent_and_diagnostic_hook(self):
        self.assertNotIn('if root.operation_pause != "" : Rectangle',UI)
        self.assertIn('visible: root.operation_pause != ""',UI)
        self.assertIn('enabled: !root.operation_confirm_acl && root.operation_pause != ""',UI)
        self.assertIn('folder_diagnostics::install();',INSTALL)
        self.assertIn('std::panic::set_hook',DIAG)
        self.assertIn('Backtrace::force_capture()',DIAG)
        self.assertIn('RSS KiB=',DIAG)
        self.assertIn('OPERATION worker done:',AUDIT)
    def test_ci_keeps_build_and_actual_dependency_versions(self):
        self.assertIn('KROKIET_SLINT_VERSION',YML)
        self.assertIn('KROKIET_RUST_VERSION',YML)
        self.assertIn('cargo test -p krokiet --locked --release',YML)
        self.assertIn('cargo build -p krokiet --release --locked',YML)
        self.assertIn('Swatinem/rust-cache@v2',YML)
        self.assertIn('test_macos_backup_acl.sh',YML)
if __name__=='__main__': unittest.main()
