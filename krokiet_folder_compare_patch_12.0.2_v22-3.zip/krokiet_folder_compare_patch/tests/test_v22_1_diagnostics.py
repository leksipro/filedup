"""Structural regression checks; macOS runtime tests belong to GitHub Actions."""
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
RUST=(ROOT/'krokiet/src/folder_audit_actions.rs').read_text()
UI=(ROOT/'krokiet/ui/popups/popup_folder_workspace.slint').read_text()
INSTALL=(ROOT/'apply_patch.py').read_text()
SWIFT=(ROOT/'macos_trash_diagnostics.swift').read_text()
YML=(ROOT/'.github/workflows/build-krokiet.yml').read_text()
class DiagnosticsTests(unittest.TestCase):
    def test_preflight_is_read_only_and_confirms_remaining(self):
        region=RUST[RUST.index('fn preview_destination('):RUST.index('fn checked_destination(')]
        self.assertNotIn('create_dir',region)
        self.assertIn('symlink_metadata',region)
        self.assertIn('Vorabprüfung: {failed_count} Dateien ausgeschlossen',RUST)
        self.assertIn('let mut batch = eligible;',RUST)
    def test_reports_created_before_batch_and_no_twelve_error_cap(self):
        region=RUST[RUST.index('if finder_retry && batch.len() != 1'):RUST.index('if action == "finder_folder_a"')]
        self.assertIn('new_operation_report()',region)
        self.assertIn('VORAB AUSGESCHLOSSEN',region)
        self.assertIn('BEGIN {:?}',region)
        self.assertNotIn('failed.len()',region)
        self.assertIn('file.flush()',RUST)
        self.assertIn('error.raw_os_error()',RUST.replace('e.raw_os_error()','error.raw_os_error()'))
    def test_decisions_connected_and_systemic_warning(self):
        for token in ('error_continue','error_skip_all','error_abort','error_retry_finder','open_operation_report'):
            self.assertIn(token,RUST); self.assertIn(token,UI)
        for token in ('operation_pause','operation_report','operation_finder_retry'):
            self.assertIn(token,INSTALL); self.assertIn(token,UI)
        self.assertIn('self.streak >= 5',RUST)
        self.assertIn('mode,entry.fast_proof,&links,false,true',RUST)
    def test_helper_is_bundled_and_error_codes_preserved(self):
        self.assertIn('NSUnderlyingErrorKey',SWIFT)
        self.assertIn('error.domain',SWIFT)
        self.assertIn('error.code',SWIFT)
        self.assertIn('trashItem(at:',SWIFT)
        self.assertNotIn('removeItem',SWIFT)
        self.assertIn('xcrun swiftc -target arm64-apple-macos13.0',YML)
        self.assertIn('domain=NSPOSIXErrorDomain code=2',YML)
        self.assertIn('local.krokiet.foldercompare.v22</string>',YML)
    def test_extra_data_protected(self):
        self.assertIn('com.apple.ResourceFork',RUST)
        self.assertIn('com.apple.FinderInfo',RUST)
        self.assertIn('verify_mac_extra(left, right, false)?',RUST)
        self.assertIn('verify_mac_extra(source, &dest, true)?',RUST)
        self.assertIn('verify_mac_extra(src, &dest, true)?',RUST)
if __name__=='__main__': unittest.main()
