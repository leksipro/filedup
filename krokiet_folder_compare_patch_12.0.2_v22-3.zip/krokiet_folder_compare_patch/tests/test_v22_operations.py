from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
class V22Operations(unittest.TestCase):
    def test_native_per_item_not_argv_batches(self):
        rust=(ROOT/'krokiet/src/folder_audit_actions.rs').read_text()
        self.assertIn('DeleteMethod::NsFileManager',rust)
        self.assertNotIn('delete_all(&paths)',rust)
        self.assertIn('remove_verified_source(left, permanent, finder_retry)',rust)
        self.assertIn('remove_verified_source(src, false, false)',rust)
        self.assertIn('update_session_trashed(index)',rust)
    def test_partial_scan_reports_and_continues(self):
        rust=(ROOT/'krokiet/src/folder_audit_actions.rs').read_text()
        self.assertIn('result.skip(&path, &e); continue;',rust)
        self.assertIn('result.skip(&dir, &e); continue;',rust)
        self.assertIn('links.check_path(src)',rust)
        self.assertIn('links.check_path(left)',rust)
        self.assertIn('link_warning',rust)
        self.assertIn('v22_link_dependency_does_not_block_unrelated_file',rust)
    def test_explicit_force_and_finder(self):
        rust=(ROOT/'krokiet/src/folder_audit_actions.rs').read_text()
        ui=(ROOT/'krokiet/ui/popups/popup_folder_workspace.slint').read_text()
        self.assertIn('removal_check_mode(action.as_str())',rust)
        self.assertIn('finder_retry && batch.len() != 1',rust)
        self.assertIn('Endgültig löschen bestätigen',ui)
        self.assertIn('root.removal_method = "Papierkorb"',ui)
        self.assertIn('force_delete_selected',ui)
        self.assertIn('finder_retry_selected',ui)
    def test_both_move_directions(self):
        ui=(ROOT/'krokiet/ui/popups/popup_folder_workspace.slint').read_text()
        self.assertIn('"move_selected_a_to_b"',ui)
        self.assertIn('"move_selected_b_to_a"',ui)
        self.assertIn('Verschieben bestätigen',ui)
