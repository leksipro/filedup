#!/bin/bash
# CI integration of real macOS chmod semantics. Never uses the user's data.
set -euo pipefail
[ "$(uname -s)" = Darwin ] || exit 0
base=$(sudo -n /usr/bin/mktemp -d /Volumes/KrokietACL.XXXXXX)
manifest=$(mktemp)
cleanup() { sudo -n /bin/rm -rf -- "$base"; rm -f -- "$manifest"; }
trap cleanup EXIT
sudo -n /bin/chmod 755 "$base"
scope="$base/Ordinary Archive"
parent="$scope/Example parent"
file="$parent/verified file.song"
control="$parent/"$'Icon\r'
other="$parent/not selected.song"
shared="$parent/hardlinked.song"
symlink="$parent/link.song"
sudo -n mkdir -p "$parent"
sudo -n touch "$file" "$other" "$shared" "$control"
# The CI user owns this data tree, just as on the noowners external archive.
sudo -n chown -R "$(id -u):$(id -g)" "$scope"
sudo -n ln "$shared" "$base/other-hardlink"
sudo -n ln -s "$other" "$symlink"
# No Time Machine attributes are needed. Verify the original protection using
# the ordinary non-root CI user, then repeat after narrowly removing the ACLs.

for p in "$file" "$other" "$shared" "$control"; do sudo -n /bin/chmod +a 'group:everyone deny write,delete,append,writeattr,writeextattr,chown' "$p"; done
sudo -n /bin/chmod +a 'group:everyone deny add_file,delete,add_subdirectory,delete_child,writeattr,writeextattr,chown' "$parent"
if /bin/rm "$file" 2>/dev/null; then echo 'Expected deny ACL to block ordinary unlink' >&2; exit 1; fi
identity() { /usr/bin/stat -f '%d:%i' "$1"; }
script=$(dirname "$0")/../krokiet/src/macos_backup_acl.sh
printf 'file\0%s\0%s\0file\0%s\0%s\0parent\0%s\0%s\0' "$(identity "$file")" "$file" "$(identity "$control")" "$control" "$(identity "$parent")" "$parent" > "$manifest"
chmod 600 "$manifest"
result=$(sudo -n /bin/bash "$script" "$manifest" "$scope" "$(identity "$scope")")
printf '%s\n' "$result"
grep -q 'ACL_RESULT=0' <<< "$result"
# Read back the ACL: remove only the two targeted rights; keep the rest.
/bin/ls -blde "$file" | grep -q 'deny write,append,writeattr,writeextattr,chown'
/bin/ls -blde "$control" | grep -q 'deny write,append,writeattr,writeextattr,chown'
/bin/ls -lde "$parent" | grep -q 'deny add_file,delete,add_subdirectory,writeattr,writeextattr,chown'
/bin/ls -lde "$other" | grep -q 'deny write,delete,append,writeattr,writeextattr,chown'
[ -f "$file" ] && [ -f "$other" ] && [ -f "$control" ]
# Both formerly protected selected files can now be removed without root.
/bin/rm "$file" "$control"
[ ! -e "$file" ] && [ ! -e "$control" ] && [ -f "$other" ]
# Hardlinks, symlinks and out-of-scope paths must remain protected.
printf 'file\0%s\0%s\0file\0%s\0%s\0file\0%s\0%s\0' "$(identity "$shared")" "$shared" "$(identity "$symlink")" "$symlink" "$(identity "$base/other-hardlink")" "$base/other-hardlink" > "$manifest"
result=$(sudo -n /bin/bash "$script" "$manifest" "$scope" "$(identity "$scope")")
printf '%s\n' "$result"
grep -q 'ACL_RESULT=1' <<< "$result"
/bin/ls -lde "$shared" | grep -q 'deny write,delete,append,writeattr,writeextattr,chown'
/bin/ls -lde "$other" | grep -q 'deny write,delete,append,writeattr,writeextattr,chown'

# Partial administrative failures must not prevent unrelated valid records.
partial="$parent/partial success.song"
sudo -n touch "$partial"
sudo -n chown "$(id -u):$(id -g)" "$partial"
sudo -n /bin/chmod +a 'group:everyone deny write,delete,append,writeattr,writeextattr,chown' "$partial"
printf 'file\0%s\0%s\0file\0%s\0%s\0' "$(identity "$shared")" "$shared" "$(identity "$partial")" "$partial" > "$manifest"
result=$(sudo -n /bin/bash "$script" "$manifest" "$scope" "$(identity "$scope")")
grep -q 'ACL_RESULT=1' <<< "$result"
/bin/ls -lde "$partial" | grep -q 'deny write,append,writeattr,writeextattr,chown'
/bin/ls -lde "$shared" | grep -q 'deny write,delete,append,writeattr,writeextattr,chown'

# Volume root and system areas are never modified, even when A is the root.
sudo -n /bin/chmod +a 'group:everyone deny delete_child' "$base"
printf 'parent\0%s\0%s\0' "$(identity "$base")" "$base" > "$manifest"
result=$(sudo -n /bin/bash "$script" "$manifest" "$base" "$(identity "$base")")
grep -q 'ACL_RESULT=1' <<< "$result"
/bin/ls -lde "$base" | grep -q 'deny delete_child'
