"""Static regression for ACL opt-in; real chmod is exercised on macOS CI."""
from pathlib import Path
import subprocess
import unittest
ROOT=Path(__file__).resolve().parents[1]
RUST=(ROOT/'krokiet/src/folder_audit_actions.rs').read_text()
UI=(ROOT/'krokiet/ui/popups/popup_folder_workspace.slint').read_text()
SCRIPT=ROOT/'krokiet/src/macos_backup_acl.sh'
SH=SCRIPT.read_text()
class BackupACL(unittest.TestCase):
    def test_opt_in_and_recheck(self):
        self.assertIn('backup_acl_trash_selected', UI)
        self.assertIn('DAUERHAFTE ACL-Aufhebung', UI)
        self.assertIn('removal_check_mode(action.as_str())', RUST)
        self.assertIn('preflight_trash_pair_with_mode(a,b,left,right,mode,entry.fast_proof)?', RUST)
        self.assertIn('if backup_acl && !batch.is_empty()', RUST)
        self.assertIn('verified_remove_pair(&a, &b', RUST)
    def test_scope_and_identity(self):
        for token in ('scope_id', 'scope_dev', 'noncanonical', 'changed inode', 'protected boundary', 'single-link regular file'):
            self.assertIn(token, SH)
        self.assertIn('lm.nlink() != 1', RUST)
        self.assertIn('BTreeMap::<PathBuf, (u64, u64)>::new()', RUST)
    def test_admin_only_acl_data_not_code(self):
        self.assertIn('include_str!("macos_backup_acl.sh")', RUST)
        self.assertIn('with administrator privileges', RUST)
        self.assertIn('create_new(true).mode(0o600)', RUST)
        self.assertIn('quoted form of', RUST)
        self.assertIn('/bin/chmod -h -a "group:everyone deny $perm"', SH)
        for forbidden in ('chmod -R', 'chmod -N', '/bin/rm ', 'eval ', 'source "$manifest"'):
            self.assertNotIn(forbidden, SH)
        self.assertIn('ACL_RESULT=', SH)
    def test_shell_syntax_and_ci(self):
        subprocess.run(['bash','-n',str(SCRIPT)],check=True)
        subprocess.run(['bash','-n',str(ROOT/'tests/test_macos_backup_acl.sh')],check=True)
        self.assertIn('tests/test_macos_backup_acl.sh',(ROOT/'.github/workflows/build-krokiet.yml').read_text())
        self.assertIn('krokiet/src/macos_backup_acl.sh',(ROOT/'apply_patch.py').read_text())
if __name__=='__main__': unittest.main()
