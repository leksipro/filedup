# Fixed code passed to /bin/bash -c by osascript; never execute a user-written script.
# Input is a NUL-separated DATA manifest: kind, device:inode, absolute path.
# No elevated trash, unlink, recursive chmod, or broad ACL removal.
set -u
export PATH=/usr/bin:/bin:/usr/sbin:/sbin LC_ALL=C
manifest=$1
scope=$2
scope_id=$3
# Scope independent of backup name/metadata; protect system paths and the
# boundary directory itself. Console identity comes from macOS, not the manifest.
case "$scope" in
    /Volumes/*)
        rest=${scope#/Volumes/}; volume=${rest%%/*}
        case "$volume" in ''|.*) exit 64;; esac
        boundary="/Volumes/$volume"; home_scope=0;;
    /Users/*)
        console_user=$(/usr/bin/stat -f '%Su' /dev/console) || exit 64
        case "$console_user" in ''|root|loginwindow|*/*) exit 64;; esac
        boundary="/Users/$console_user"; home_scope=1;;
    *) exit 64;;
esac
path_allowed() {
    local candidate="$1" relative lower first
    case "$candidate" in *$'\n'*) return 1;; esac
    case "$candidate" in
        "$boundary") relative=;;
        "$boundary"/*) relative=${candidate#"$boundary"/};;
        *) return 1;;
    esac
    lower=$(printf '%s' "$relative" | /usr/bin/tr '[:upper:]' '[:lower:]') || return 1
    case "/$lower/" in
        */backups.backupdb/*|*/.trashes/*|*/.trash/*|*/.temporaryitems/*|*/.spotlight-v100/*|*/.fseventsd/*|*/.timemachine/*) return 1;;
    esac
    if [ "$home_scope" = 1 ]; then
        first=${lower%%/*}
        case "$first" in library|.*) return 1;; esac
    fi
    return 0
}
path_allowed "$scope" || exit 64
[ -d "$scope" ] && [ ! -L "$scope" ] || exit 64
[ "$(cd -P -- "$scope" && pwd -P)" = "$scope" ] || exit 64
[ "$(/usr/bin/stat -f '%d:%i' "$scope")" = "$scope_id" ] || exit 64
scope_dev=${scope_id%%:*}
[ -f "$manifest" ] && [ ! -L "$manifest" ] || exit 64
[ "$(/usr/bin/stat -f '%Lp' "$manifest")" = 600 ] || exit 64
exec 3< "$manifest" || exit 64
errors=0
while IFS= read -r -d '' kind <&3; do
    IFS= read -r -d '' identity <&3 && IFS= read -r -d '' path <&3 || { echo 'Invalid manifest record'; exit 65; }
    printf 'ACL BEGIN %q %q\n' "$kind" "$path"
    [ "$(/usr/bin/stat -f '%d:%i' "$scope")" = "$scope_id" ] || { echo 'ACL SKIP changed scope'; errors=1; break; }
    case "$kind" in file) perm=delete;; parent) perm=delete_child;; *) echo 'ACL SKIP invalid record'; errors=1; continue;; esac
    case "$path" in "$scope"/*) ;; "$scope") [ "$kind" = parent ] || { errors=1; continue; };; *) echo 'ACL SKIP outside scope'; errors=1; continue;; esac
    if ! path_allowed "$path" || [ "$path" = "$boundary" ]; then echo 'ACL SKIP protected boundary'; errors=1; continue; fi
    # Refuse noncanonical paths, links, crossed mounts, replacements and shared inodes.
    if [ -L "$path" ] || [ "${identity%%:*}" != "$scope_dev" ]; then echo 'ACL SKIP link or device'; errors=1; continue; fi
    if [ "$kind" = file ]; then
        [ -f "$path" ] && [ "$(/usr/bin/stat -f '%l' "$path")" = 1 ] || { echo 'ACL SKIP not a single-link regular file'; errors=1; continue; }
        physical=$(cd -P -- "${path%/*}" && pwd -P) || { errors=1; continue; }
        [ "$physical/${path##*/}" = "$path" ] || { echo 'ACL SKIP noncanonical path'; errors=1; continue; }
    else
        [ -d "$path" ] && [ "$(cd -P -- "$path" && pwd -P)" = "$path" ] || { echo 'ACL SKIP noncanonical directory'; errors=1; continue; }
    fi
    [ "$(/usr/bin/stat -f '%d:%i' "$path")" = "$identity" ] || { echo 'ACL SKIP changed inode'; errors=1; continue; }
    # Match the actual deny ACL, irrespective of the archive's provenance.
    # -b escapes filename control characters; the path itself stays unchanged.
    before=$(/bin/ls -blde "$path") || { errors=1; continue; }
    printf '%s\n' "$before"
    # Do not accept a substring of delete_child as delete. Only everyone deny entries.
    has_deny() {
        /usr/bin/awk -v perm="$perm" 'NR > 1 && $1 ~ /^[0-9]+:$/ && ($2 == "group:everyone" || toupper($2) == "ABCDEFAB-CDEF-ABCD-EFAB-CDEF0000000C") && $3 == "deny" {n=split($4,a,","); for(i=1;i<=n;i++) if(a[i]==perm) found=1} END {exit !found}'
    }
    if ! printf '%s\n' "$before" | has_deny; then echo 'ACL OK already absent'; continue; fi
    # Recheck identity/link count immediately before chmod (still not atomic).
    [ ! -L "$path" ] && [ "$(/usr/bin/stat -f '%d:%i' "$path")" = "$identity" ] || { echo 'ACL SKIP changed before chmod'; errors=1; continue; }
    if [ "$kind" = file ] && [ "$(/usr/bin/stat -f '%l' "$path")" != 1 ]; then echo 'ACL SKIP shared inode'; errors=1; continue; fi
    if /bin/chmod -h -a "group:everyone deny $perm" "$path"; then
        after=$(/bin/ls -blde "$path") || { errors=1; continue; }
        printf '%s\n' "$after"
        if printf '%s\n' "$after" | has_deny; then echo 'ACL ERROR deny still present'; errors=1; else echo 'ACL OK'; fi
    else
        echo 'ACL ERROR chmod'; errors=1
    fi
done
printf 'ACL_RESULT=%s\n' "$errors"
# Preserve per-item stdout through AppleScript even on partial failure.
exit 0
