# Krokiet 12.0.2 – Folder Relationships & Compare & Merge v10

**Quellcode-Erweiterung, noch kein geprüfter Release.** Enthält keine ausführbare macOS-Anwendung. Für GitHub Actions liegt `build-krokiet-v10.yml` bei.

## Sicherheitsnachbesserung nach v10-Review

Ein zusätzlicher Schutz vor veralteten Audit-Sessions ist eingebaut: Ändert sich nach einem Audit der Ordner A, Ordner B oder das Filterfeld, werden manuelle Dateiaktionen blockiert und die Anzeige als prüfungsbedürftig zurückgesetzt. Das betrifft auch den Wechsel eines A/B-Paares aus der globalen Ordnerübersicht. Erst ein neues „Inhalte prüfen“ erlaubt Aktionen.

## Änderungen gegenüber v9

1. **Kompilierfehler behoben:** `prepare` gab ein Slint-`ModelRc` aus dem Hintergrundthread zurück, das in `upgrade_in_event_loop` verschoben wurde. `ModelRc` ist nicht `Send`, das hätte den Build abgebrochen. Jetzt werden nur Strings über den Thread gereicht und das Modell im UI-Thread gebaut.
2. **Bytevergleich korrigiert:** Ein einzelner `read`-Aufruf darf weniger Bytes liefern (externe Platten, Netzlaufwerke). Die Schleife verglich dann gleiche Dateien als verschieden. Das hätte beim Merge die gerade kopierte Datei wieder gelöscht und beim Papierkorb zufällig verweigert. Jetzt wird bis zum vollen Puffer gelesen, mit Test.
3. **Merge übernimmt Änderungsdatum und Zugriffsrechte** (bestmöglich, nach der Inhaltsprüfung). Finder-Tags und erweiterte Attribute werden weiterhin nicht kopiert.
4. **Kein Komplett-Scan nach jeder Aktion:** Nach Merge oder Papierkorb wird nur die betroffene Zeile angepasst (Merge: Nur in A wird Identisch, Papierkorb: Identisch wird Nur in B). Jede Aktion prüft beim Ausführen selbst neu (Kopie ohne Überschreiben, frischer Bytevergleich, Link-Prüfung). Die globale Ordnerübersicht wird weiterhin ungültig gemacht. Der gespeicherte Bericht zeigt den Stand vor der Aktion.
5. **Dateifilter wieder mit Systemmüll vorbelegt** (`.DS_Store`, `._*`, `Thumbs.db`, `desktop.ini`, `.localized`): Diese Dateien erscheinen nicht als "Nur in A" und werden nie kopiert. Leeres Feld bleibt völlig streng. Das Python-Skript ist unverändert streng (`--ignore ".DS_Store, ._*"` für dasselbe Verhalten).
6. **Unterordner zusammenfassen** in der Ordnerübersicht ist wieder standardmäßig an.

## Funktionen (aus v9)

- **Keine Löschliste, keine Stapel-Papierkorbaktion für ganze Ordner.**
- **Zweispaltiges Datei-Audit:** A und B nebeneinander. Hash-identische Dateien stehen auch bei abweichenden Namen und Unterordnern in derselben Zeile. Vier Zustände: `Identisch`, `Nur in A`, `Nur in B`, `Konflikt` (gleicher relativer Pfad, anderer Inhalt).
- **Manueller Merge:** Nur eine ausgewählte `Nur in A`-Datei wird am relativen Pfad nach B kopiert, nie überschrieben, danach byteweise geprüft. A bleibt unverändert.
- **Manuelles Löschen:** Nur eine ausgewählte `Identisch`-Datei aus A, mit Bestätigung, erneutem Bytevergleich und Link-Prüfung, nur in den Papierkorb.
- 120 Zeilen pro Seite.

## Wichtige Grenzen

- Verglichen wird **Dateiinhalt**, nicht Metadaten, ACLs, Tags, Resource Forks, Finder-Aliase, Hardlink-Topologie oder Referenzen innerhalb von Musik- und anderen Projektdateien.
- Der Merge kopiert Dateiinhalt (byteweise verifiziert) sowie Änderungsdatum und Zugriffsrechte. Finder-Tags, erweiterte Attribute und Resource Forks werden nicht übertragen. Leere Ordner in A werden nicht angelegt.
- Die Link-Prüfung vor dem Papierkorb sieht nur Symlinks innerhalb von A und B. Aliase, Projektverweise und Links an anderen Orten werden nicht erkannt.
- Die Link-Prüfung liest vor jeder Papierkorb-Aktion beide Ordnerbäume neu ein. Bei sehr großen Ordnern dauert das.
- Symlinks und Spezialdateien werden nicht gemerged. Dateien können sich zwischen Prüfung und Aktion verändern; die Kontrollprüfungen reduzieren, eliminieren aber nicht alle Race Conditions.
- Auf externen Platten und Netzwerkfreigaben kann das Verschieben in den Systempapierkorb fehlschlagen. Es wird **kein** endgültiges Löschen als Fallback ausgeführt.
- Die globale Ordnerübersicht ist ein **Vorschlagswerkzeug**, keine Löschfreigabe. Die Side-by-Side-Ansicht hat einen unabhängigen, frischen Hashscan.
- `Konflikt` muss manuell im Finder aufgelöst werden. v10 überschreibt oder benennt Dateien nie automatisch um.

## Benutzung

1. In Krokiet `Duplicate Files` mit **Hash** über eine Platte scannen; anschließend `Ordnerbeziehungen` öffnen.
2. Ein interessantes A/B-Paar auswählen und `A/B vergleichen und manuell zusammenführen` anklicken – oder `Compare folders` direkt öffnen.
3. **A** ist der ältere/zu ergänzende Ordner, **B** der Ordner, der langfristig bleiben soll. Der Filter ist mit Systemmüll vorbelegt; leer = völlig streng.
4. `Inhalte prüfen` → Dateipaare in der Tabelle ansehen. `Identisch` erkennt auch abweichende Dateinamen/Pfade. `Konflikt` zeigt gleiche relative Pfade mit verschiedenen Daten.
5. Bei `Nur in A` eine Zeile wählen und `Ausgewählte Datei A nach B kopieren (Merge)` klicken. Bei Namenskonflikt findet keine Kopie statt. Die Zeile wird danach `Identisch`.
6. Optional bei einer **eindeutig identischen** Dateizeile die separate Aktion `Identische Datei A manuell in Papierkorb ...` auslösen, die Bestätigung lesen und bestätigen. Dies ist keine Ordner-Löschung.
7. Ganze Ordner nur unabhängig, bewusst und nach Prüfung über den **Finder** bearbeiten. Nie allein wegen einer grünen Abdeckung löschen.

## GitHub Actions – ohne lokale Rust-Installation

In das Hauptverzeichnis eines GitHub-Repositories hochladen:

`krokiet_folder_compare_patch_12.0.2_v10.zip`

Zusätzlich als Datei erstellen:

`.github/workflows/build-krokiet-v10.yml`

Der Workflow entpackt die ZIP, klont den originalen `12.0.2`-Tag, wendet den Patch an, führt die Python-Tests und `cargo test -p krokiet --locked` durch, kompiliert den ARM64-Release und veröffentlicht ein Artifact `krokiet-v10-macos-arm64`.

Bei einem Fehler das **erste** `error:` im Build-Log prüfen; kein Test-/Build-Erfolg ist vorab garantiert. Auch ein erfolgreicher Compilerlauf ersetzt keine macOS/APFS/exFAT-Funktionstests.

## Lokaler Build

```bash
unzip krokiet_folder_compare_patch_12.0.2_v10.zip

git clone --depth 1 --branch 12.0.2 https://github.com/qarmin/czkawka.git czkawka
python3 krokiet_folder_compare_patch/apply_patch.py "$PWD/czkawka"
cd czkawka
cargo test -p krokiet --locked
cargo build -p krokiet --release --locked
```

## Entwickler-Hinweis

- `krokiet/src/folder_compare.rs` enthält den frischen inhaltsbasierten Scanner und den Textbericht.
- `krokiet/src/folder_audit_actions.rs` enthält ausschließlich die interaktiven Dateipaar-Modelle und **manuell** ausgelöste Aktionen.
- `krokiet/src/folder_relations_actions.rs` enthält nur Finder/Quick Look für die globale Übersicht.
- `krokiet/src/folder_relations.rs` bleibt der Vorschlags-/Index-Scanner.
- Beide Slint-Popups verwenden bei der Größenberechnung `root.width`, nicht `parent.width` in der Wurzelkomponente.

## Teststatus v10

- Audit-Datei mit Platzhaltern für Slint/Czkawka vom Rust-Compiler typgeprüft (inklusive der `Send`-Regel) und ihre 8 Dateisystem-Tests ausgeführt: Merge ohne Überschreiben, Konflikt, Zeitstempel, Symlink-Ziel, Papierkorb-Verweigerung bei abweichendem Inhalt und bei Link-Abhängigkeit, Kurz-Reads, Zeilen-Update. Nicht ausgeführt wurde ein erfolgreiches Verschieben in den Papierkorb.
- Engine der Ordnerübersicht: 17 Tests und 1500 Zufallsfälle gegen die Python-Referenz.
- Python-Tests des Verifiers und des Installers bestanden. Patch auf frischem Krokiet-12.0.2-Klon angewendet.
- Nicht geprüft: Kompilieren mit echtem Slint/Krokiet, Oberfläche, echter Papierkorb auf macOS, Workflow-Lauf.
