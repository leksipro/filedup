//! "Ordner-Übersicht": beantwortet pro Ordner die eine Frage "Wie viel davon liegt schon woanders?".
//!
//! Die Ampel ist nur ein HINWEIS; die manuelle Detailprüfung erfolgt in Folder Compare.
//! v10 entfernt die automatische Löschliste und sämtliche Ordner-Papierkorbaktionen.
//!
//! Prinzip
//! 1. Nach einem Duplikat-Scan (Methode Hash) wird jede Datei, die der Scan betrachtet, aufgelistet
//!    (ohne Mindestgröße). Dateien einer Duplikatgruppe haben dieselbe Inhalts-ID, alle anderen sind einmalig.
//! 2. Jeder Ordner bekommt rekursiv die Menge seiner Inhalts-IDs (mit Anzahl der Kopien).
//! 3. Eine Datei in Ordner A gilt als "gedeckt", wenn es von ihrem Inhalt mindestens eine Kopie
//!    AUSSERHALB von A gibt (egal auf welcher Platte). Das ist reine Zählerei, ohne Paarvergleiche.
//! 4. Globale Inhaltsdeckung und 1:1-Kopienanzahl werden getrennt bewertet.
//! 5. Für bis zu 40 sichtbare Kandidaten werden konkrete A/B-Paare berechnet.
//! 6. Bei Cache, Scanwarnungen oder Hashdrift niemals grüne Vollständigkeit behaupten.

use std::cmp::Ordering;
use std::collections::{BTreeSet, HashMap, HashSet};
use std::ffi::{OsStr, OsString};
use std::path::{Component, Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering as AtomicOrdering};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{SystemTime, UNIX_EPOCH};
use std::fs;
use serde::{Serialize, Deserialize};

use chrono::{Local, TimeZone, Utc};
use czkawka_core::common::model::{CheckingMethod, FileEntry};
use czkawka_core::common::tool_data::CommonData;
use czkawka_core::tools::duplicate::DuplicateFinder;
use humansize::{BINARY, format_size};
use slint::{ComponentHandle, ModelRc, SharedString, VecModel, Weak};

use crate::MainWindow;

#[path = "folder_relations_actions.rs"]
mod actions;

/// Paginated display size, not a global result truncation.
const PAGE_SIZE: usize = 40;
const MAX_PERSIST_FILES: usize = 250_000;
/// Fundstellen pro Ordner.
const PARTNER_COUNT: usize = 3;
/// Zeilen der Dateiliste im Detailbereich.
const FILE_LIST_LIMIT: usize = 300;

/// Maximale Zeilen "nur hier" im Detail.
const ONLY_HERE_LIMIT: usize = 200;
const ALL_DISKS: &str = "Alle Platten";

// ---- PURE-BEGIN (kein Czkawka, kein Slint: wird separat extrahiert und getestet) ----

// No content-frequency cutoff: identical-content folders must not be silently skipped.

#[derive(Debug, Clone, Serialize, Deserialize)]
pub(crate) struct InputFile {
    pub path: PathBuf,
    pub size: u64,
    pub modified: u64,
    /// Nummer der Duplikatgruppe (Dateien mit gleichem Inhalt), None für Dateien ohne Duplikat.
    pub group: Option<u32>,
}

/// Systemmüll, der nicht mitgezählt wird (wie beim strengen Vergleich).
pub(crate) fn is_junk(name: &OsStr) -> bool {
    let name = name.to_string_lossy().to_lowercase();
    name == ".ds_store" || name == "thumbs.db" || name == "desktop.ini" || name == ".localized" || name.starts_with("._")
}

/// Platte eines Pfades: /Volumes/NAME, /mnt/NAME, /media/BENUTZER/NAME, sonst "Startvolume".
pub(crate) fn disk_of(path: &Path) -> String {
    let parts: Vec<String> = path
        .components()
        .filter_map(|component| match component {
            Component::Normal(name) => Some(name.to_string_lossy().into_owned()),
            _ => None,
        })
        .collect();
    let found = match parts.first().map(String::as_str) {
        Some("Volumes" | "mnt") => parts.get(1).cloned(),
        Some("media") => parts.get(2).or_else(|| parts.get(1)).cloned(),
        _ => None,
    };
    found.unwrap_or_else(|| "Startvolume".to_owned())
}

struct FileRec {
    dir: u32,
    name: OsString,
    size: u64,
    modified: u64,
    /// Inhalts-ID, nur wenn es mindestens zwei Dateien mit diesem Inhalt gibt.
    id: Option<u32>,
}

struct Node {
    parent: Option<u32>,
    name: OsString,
    disk: u16,
    total_files: u64,
    total_bytes: u64,
    newest: u64,
    /// Rekursive Menge der geteilten Inhalts-IDs: (id, Anzahl Kopien in diesem Ordner), nach id sortiert.
    shared: Vec<(u32, u32)>,
}

pub(crate) struct DiskStat {
    pub name: String,
    pub files: u64,
    pub bytes: u64,
    /// Bytes von Dateien, deren Inhalt auch auf einer anderen Platte liegt.
    pub other_disk_bytes: u64,
    /// Bytes von Dateien mit Kopie, aber nur auf derselben Platte.
    pub same_disk_bytes: u64,
}

pub(crate) struct FolderIndex {
    nodes: Vec<Node>,
    recs: Vec<FileRec>,
    direct_files: Vec<Vec<u32>>,
    children: Vec<Vec<u32>>,
    occurrences: Vec<Vec<u32>>,
    id_size: Vec<u64>,
    id_count: Vec<u32>,
    tin: Vec<u32>,
    tout: Vec<u32>,
    pub(crate) disks: Vec<DiskStat>,
    pub(crate) hash_label: String,
    pub(crate) file_count: u64,
    pub(crate) junk_skipped: u64,
    pub(crate) skipped_small: u64,
    pub(crate) min_size: u64,
    pub(crate) warnings: Vec<String>,
    pub(crate) stale_groups: usize,
    pub(crate) from_cache: bool,
    /// Ordner, in denen (oder unterhalb von denen) laut Scanwarnung etwas nicht gelesen werden konnte.
    warned: Vec<bool>,
    /// Eine Warnung ohne erkennbaren Pfad: dann ist nichts belastbar.
    global_warning: bool,
}

fn node_for(dir: &Path, nodes: &mut Vec<Node>, dirs: &mut HashMap<PathBuf, u32>) -> u32 {
    if let Some(&index) = dirs.get(dir) {
        return index;
    }
    let mut chain: Vec<&Path> = Vec::new();
    let mut current = dir;
    let mut parent_index: Option<u32> = None;
    loop {
        if let Some(&index) = dirs.get(current) {
            parent_index = Some(index);
            break;
        }
        chain.push(current);
        match current.parent() {
            Some(parent) if !parent.as_os_str().is_empty() => current = parent,
            _ => break,
        }
    }
    for directory in chain.into_iter().rev() {
        let index = nodes.len() as u32;
        let name = directory.file_name().map_or_else(|| directory.as_os_str().to_os_string(), OsStr::to_os_string);
        nodes.push(Node {
            parent: parent_index,
            name,
            disk: 0,
            total_files: 0,
            total_bytes: 0,
            newest: 0,
            shared: Vec::new(),
        });
        dirs.insert(directory.to_path_buf(), index);
        parent_index = Some(index);
    }
    parent_index.unwrap_or(0)
}

fn path_of(nodes: &[Node], n: u32) -> PathBuf {
    let mut names: Vec<&OsString> = Vec::new();
    let mut current = Some(n);
    while let Some(index) = current {
        let node = &nodes[index as usize];
        names.push(&node.name);
        current = node.parent;
    }
    let mut path = PathBuf::new();
    for name in names.into_iter().rev() {
        path.push(name);
    }
    path
}

/// Ordnet Scanwarnungen (Ordner nicht lesbar usw.) den Ordnerknoten zu. Ein Ordner A ist unsicher, wenn unterhalb
/// von A etwas nicht gelesen werden konnte: dort könnten Dateien liegen, die der Index nicht kennt. Warnungen
/// außerhalb von A machen nur die Abdeckung kleiner, nie größer. Warnungen ohne Pfad gelten für alles.
fn mark_warned_nodes(nodes: &[Node], children: &[Vec<u32>], warnings: &[String]) -> (Vec<bool>, bool) {
    let mut warned = vec![false; nodes.len()];
    let mut global = false;
    // Wurzelknoten ("/"): alle absoluten Pfade beginnen dort.
    let root: Option<u32> = nodes.iter().position(|n| n.parent.is_none()).map(|i| i as u32);
    for warning in warnings {
        let Some(start) = warning.find('/') else {
            global = true;
            continue;
        };
        let mut current = root;
        for component in warning[start..].split('/').filter(|c| !c.is_empty()) {
            let Some(node) = current else { break };
            match children[node as usize].iter().copied().find(|&c| nodes[c as usize].name.to_string_lossy() == component) {
                Some(child) => current = Some(child),
                // Rest der Meldung (z. B. ", reason ...") oder unbekannter Ordner: hier endet der bekannte Teil.
                None => break,
            }
        }
        // Tiefster bekannter Ordner auf dem Weg: er und alle Oberordner enthalten den nicht lesbaren Bereich.
        let mut node = current;
        while let Some(n) = node {
            if warned[n as usize] {
                break;
            }
            warned[n as usize] = true;
            node = nodes[n as usize].parent;
        }
    }
    (warned, global)
}

pub(crate) fn build_index(files: Vec<InputFile>, hash_label: String, min_size: u64) -> FolderIndex {
    build_index_checked(files, hash_label, min_size, Vec::new(), 0, false)
}

pub(crate) fn build_index_checked(files: Vec<InputFile>, hash_label: String, min_size: u64, warnings: Vec<String>, stale_groups: usize, from_cache: bool) -> FolderIndex {
    let before = files.len();
    let files: Vec<InputFile> = files.into_iter().filter(|f| !f.path.file_name().is_some_and(is_junk)).collect();
    let junk_skipped = (before - files.len()) as u64;
    let skipped_small = files.iter().filter(|f| f.group.is_none() && f.size > 0 && f.size < min_size).count() as u64;

    // Rohe Inhalts-IDs: Duplikatgruppe g -> g + 1, leere Dateien -> 0, alles andere hat keine ID.
    let max_group = files.iter().filter_map(|f| f.group).max().map_or(0, |g| g as usize + 1);
    let id_space = max_group + 1;
    let raw_id = |f: &InputFile| -> Option<u32> {
        match f.group {
            Some(g) => Some(g + 1),
            None if f.size == 0 => Some(0),
            None => None,
        }
    };
    let mut id_count = vec![0u32; id_space];
    let mut id_size = vec![0u64; id_space];
    for file in &files {
        if let Some(id) = raw_id(file) {
            id_count[id as usize] += 1;
            id_size[id as usize] = file.size;
        }
    }

    let mut nodes: Vec<Node> = Vec::new();
    let mut dirs: HashMap<PathBuf, u32> = HashMap::new();
    let mut direct_ids: Vec<Vec<u32>> = Vec::new();
    let mut direct_files: Vec<Vec<u32>> = Vec::new();
    let mut recs: Vec<FileRec> = Vec::with_capacity(files.len());
    let file_count = files.len() as u64;
    for file in &files {
        let dir = file.path.parent().unwrap_or_else(|| Path::new("/"));
        let index = node_for(dir, &mut nodes, &mut dirs) as usize;
        while direct_ids.len() < nodes.len() {
            direct_ids.push(Vec::new());
            direct_files.push(Vec::new());
        }
        let shared_id = raw_id(file).filter(|&id| id_count[id as usize] >= 2);
        let rec = recs.len() as u32;
        recs.push(FileRec {
            dir: index as u32,
            name: file.path.file_name().map(OsStr::to_os_string).unwrap_or_default(),
            size: file.size,
            modified: file.modified,
            id: shared_id,
        });
        direct_files[index].push(rec);
        if let Some(id) = shared_id {
            direct_ids[index].push(id);
        }
        let node = &mut nodes[index];
        node.total_files += 1;
        node.total_bytes += file.size;
        node.newest = node.newest.max(file.modified);
    }
    drop(dirs);
    drop(files);

    // Von unten nach oben aufsummieren. Kinder haben immer einen größeren Index als ihr Elternknoten.
    let count = nodes.len();
    let mut acc: Vec<Vec<(u32, u32)>> = vec![Vec::new(); count];
    for n in (0..count).rev() {
        let mut list = std::mem::take(&mut acc[n]);
        list.extend(direct_ids[n].iter().map(|&id| (id, 1)));
        list.sort_unstable_by_key(|entry| entry.0);
        let mut merged: Vec<(u32, u32)> = Vec::with_capacity(list.len());
        for (id, copies) in list {
            match merged.last_mut() {
                Some(last) if last.0 == id => last.1 += copies,
                _ => merged.push((id, copies)),
            }
        }
        merged.shrink_to_fit();
        if let Some(parent) = nodes[n].parent {
            let parent = parent as usize;
            acc[parent].extend(merged.iter().copied());
            let (files_n, bytes_n, newest_n) = (nodes[n].total_files, nodes[n].total_bytes, nodes[n].newest);
            nodes[parent].total_files += files_n;
            nodes[parent].total_bytes += bytes_n;
            nodes[parent].newest = nodes[parent].newest.max(newest_n);
        }
        nodes[n].shared = merged;
    }
    drop(direct_ids);

    // Euler-Tour für schnelle "liegt darin"-Tests.
    let mut children: Vec<Vec<u32>> = vec![Vec::new(); count];
    let mut roots: Vec<u32> = Vec::new();
    for (index, node) in nodes.iter().enumerate() {
        match node.parent {
            Some(parent) => children[parent as usize].push(index as u32),
            None => roots.push(index as u32),
        }
    }
    let mut tin = vec![0u32; count];
    let mut tout = vec![0u32; count];
    let mut clock = 0u32;
    let mut stack: Vec<(u32, usize)> = Vec::new();
    for root in roots {
        tin[root as usize] = clock;
        clock += 1;
        stack.push((root, 0));
        while let Some((node, position)) = stack.last().copied() {
            if let Some(&child) = children[node as usize].get(position) {
                if let Some(top) = stack.last_mut() {
                    top.1 += 1;
                }
                tin[child as usize] = clock;
                clock += 1;
                stack.push((child, 0));
            } else {
                tout[node as usize] = clock;
                stack.pop();
            }
        }
    }

    // Platten (höchstens 63, der Rest wird zusammengefasst).
    let node_disk_names: Vec<String> = (0..count).map(|n| disk_of(&path_of(&nodes, n as u32))).collect();
    let mut names: Vec<String> = node_disk_names.iter().cloned().collect::<BTreeSet<_>>().into_iter().collect();
    if names.len() > 63 {
        names.truncate(62);
        names.push("Weitere Platten".to_owned());
    }
    let last = names.len().saturating_sub(1) as u16;
    {
        let lookup: HashMap<&str, u16> = names.iter().enumerate().map(|(i, name)| (name.as_str(), i as u16)).collect();
        for (n, node) in nodes.iter_mut().enumerate() {
            node.disk = lookup.get(node_disk_names[n].as_str()).copied().unwrap_or(last);
        }
    }
    let mut id_disks = vec![0u64; id_space];
    for rec in &recs {
        if let Some(id) = rec.id {
            id_disks[id as usize] |= 1u64 << nodes[rec.dir as usize].disk;
        }
    }
    let mut disks: Vec<DiskStat> = names
        .iter()
        .map(|name| DiskStat {
            name: name.clone(),
            files: 0,
            bytes: 0,
            other_disk_bytes: 0,
            same_disk_bytes: 0,
        })
        .collect();
    for rec in &recs {
        let disk = nodes[rec.dir as usize].disk as usize;
        disks[disk].files += 1;
        disks[disk].bytes += rec.size;
        if let Some(id) = rec.id {
            if id_disks[id as usize] & !(1u64 << disk) != 0 {
                disks[disk].other_disk_bytes += rec.size;
            } else {
                disks[disk].same_disk_bytes += rec.size;
            }
        }
    }

    let mut occurrences: Vec<Vec<u32>> = vec![Vec::new(); id_space];
    for (n, node) in nodes.iter().enumerate() {
        for &(id, _) in &node.shared {
            occurrences[id as usize].push(n as u32);
        }
    }

    let (warned, global_warning) = mark_warned_nodes(&nodes, &children, &warnings);

    FolderIndex {
        nodes,
        recs,
        direct_files,
        children,
        occurrences,
        id_size,
        id_count,
        tin,
        tout,
        disks,
        hash_label,
        file_count,
        junk_skipped,
        skipped_small,
        min_size,
        warnings,
        stale_groups,
        from_cache,
        warned,
        global_warning,
    }
}

#[derive(Debug, Clone)]
pub(crate) struct Partner {
    pub node: u32,
    /// True pairwise matched byte count, not marginal greedy coverage.
    pub bytes: u64,
    pub files: u64,
    pub distinct: u64,
    pub kind: u8, // 2 identical multiset; 1 A in B; 0 partial
}

#[derive(Debug, Clone)]
pub(crate) struct Row {
    pub a: u32,
    /// 2 = grün (alles gedeckt), 1 = gelb (über der Schwelle).
    pub class: u8,
    pub covered_files: u64,
    pub total_files: u64,
    pub covered_bytes: u64,
    pub total_bytes: u64,
    pub copy_files: u64,
    pub copy_bytes: u64,
    pub distinct: u64,
    /// Anzahl gleichartiger Zwillingsordner inklusive diesem (0 = kein Zwilling).
    pub twins: u32,
    pub partners: Vec<Partner>,
    /// Bytes, deren Kopien in keiner der genannten Fundstellen liegen (weitere oder übergeordnete Ordner).
    pub rest_bytes: u64,
}

pub(crate) struct Params {
    pub min_files: u64,
    pub threshold_permille: u32,
    pub summarize: bool,
    pub disk: Option<u16>,
    pub sort: String,
    pub page: usize,
}

impl FolderIndex {
    pub(crate) fn node_path(&self, n: u32) -> PathBuf {
        path_of(&self.nodes, n)
    }

    pub(crate) fn node_disk_name(&self, n: u32) -> &str {
        &self.disks[self.nodes[n as usize].disk as usize].name
    }

    pub(crate) fn node_newest(&self, n: u32) -> u64 {
        self.nodes[n as usize].newest
    }

    /// Ist `b` ein echter Unterordner von `a`?
    fn inside(&self, b: u32, a: u32) -> bool {
        let (a, b) = (a as usize, b as usize);
        self.tin[a] < self.tin[b] && self.tin[b] < self.tout[a]
    }

    fn depth(&self, n: u32) -> usize {
        let mut depth = 0;
        let mut current = self.nodes[n as usize].parent;
        while let Some(index) = current {
            depth += 1;
            current = self.nodes[index as usize].parent;
        }
        depth
    }

    fn copies_in(&self, n: u32, id: u32) -> u32 {
        let shared = &self.nodes[n as usize].shared;
        shared.binary_search_by_key(&id, |entry| entry.0).map_or(0, |position| shared[position].1)
    }

    /// (covered file count, covered bytes) even when the external copies are spread across many folders.
    /// A contains three duplicates while only one external copy exists: coverage=3 (unique content),
    /// but copy_coverage below is only 1. Both metrics must be presented distinctly.
    fn coverage(&self, a: u32) -> (u64, u64) {
        let (mut files, mut bytes) = (0u64, 0u64);
        for &(id, copies) in &self.nodes[a as usize].shared {
            if self.id_count[id as usize] > copies {
                files += u64::from(copies);
                bytes += u64::from(copies) * self.id_size[id as usize];
            }
        }
        (files, bytes)
    }

    /// Gespeicherter Stand oder unterhalb von a wurde laut Scanwarnung etwas nicht gelesen.
    pub(crate) fn is_uncertain(&self, a: u32) -> bool {
        self.from_cache || INDEX_DIRTY.load(AtomicOrdering::SeqCst) || self.global_warning || self.warned[a as usize]
    }

    fn copy_coverage(&self, a: u32) -> (u64, u64) {
        self.nodes[a as usize].shared.iter().fold((0, 0), |(files, bytes), &(id, copies)| {
            let elsewhere = self.id_count[id as usize].saturating_sub(copies);
            let matched = u64::from(copies.min(elsewhere));
            (files + matched, bytes + matched * self.id_size[id as usize])
        })
    }

    fn distinct_contents(&self, a: u32) -> u64 {
        let node = &self.nodes[a as usize];
        let duplicated: u64 = node.shared.iter().map(|(_, count)| u64::from(*count)).sum();
        node.shared.len() as u64 + node.total_files.saturating_sub(duplicated)
    }

    fn pair_metrics(&self, a: u32, b: u32) -> (u64, u64, u64) {
        let (mut copies, mut bytes, mut distinct) = (0u64, 0u64, 0u64);
        for &(id, ac) in &self.nodes[a as usize].shared {
            let bc = self.copies_in(b, id);
            if bc > 0 {
                distinct += 1;
                let matched = u64::from(ac.min(bc));
                copies += matched;
                bytes += matched * self.id_size[id as usize];
            }
        }
        (copies, bytes, distinct)
    }

    /// Liegt von Inhalt `id` eine Kopie in Ordner b? Ordner, die a enthalten oder in a liegen, zählen nicht
    /// (ein Oberordner enthält ja a selbst und wäre als Fundstelle nutzlos).
    fn outside_copy_in(&self, b: u32, a: u32, id: u32) -> bool {
        b != a && !self.inside(b, a) && !self.inside(a, b) && self.copies_in(b, id) > 0
    }

    /// Exact A/B comparison using shared content IDs, NOT marginal gains of a greedy cover.
    /// Called only for visible rows, not for every folder on the disk.
    pub(crate) fn partners(&self, a: u32, max: usize) -> (Vec<Partner>, u64) {
        // Candidate B has to contain at least one content ID of A. Inverted index avoids
        // comparing each folder against every other folder.
        let mut candidates: HashMap<u32, (u64, u64, u64)> = HashMap::new();
        for &(id, copies_a) in &self.nodes[a as usize].shared {
            let size = self.id_size[id as usize];
            for &b in &self.occurrences[id as usize] {
                if !self.outside_copy_in(b, a, id) { continue; }
                let copies_b = self.copies_in(b, id);
                let copies = u64::from(copies_a.min(copies_b));
                let entry = candidates.entry(b).or_insert((0, 0, 0));
                entry.0 += copies;
                entry.1 += copies * size;
                entry.2 += 1;
            }
        }
        let files_a = self.nodes[a as usize].total_files;
        let mut result: Vec<Partner> = candidates.into_iter().filter_map(|(b, (files, bytes, distinct))| {
            if files == 0 { return None; }
            let all_copies = files == files_a;
            let identical = all_copies && self.nodes[b as usize].total_files == files_a;
            let kind = if identical { 2 } else if all_copies { 1 } else { 0 };
            Some(Partner { node: b, bytes, files, distinct, kind })
        }).collect();
        result.sort_unstable_by(|a_p, b_p| {
            b_p.kind.cmp(&a_p.kind)
                .then_with(|| b_p.files.cmp(&a_p.files))
                .then_with(|| b_p.bytes.cmp(&a_p.bytes))
                // Prefer the smallest useful containing folder rather than the entire volume.
                .then_with(|| self.nodes[a_p.node as usize].total_bytes.cmp(&self.nodes[b_p.node as usize].total_bytes))
                .then_with(|| self.depth(b_p.node).cmp(&self.depth(a_p.node)))
                .then_with(|| self.node_path(a_p.node).cmp(&self.node_path(b_p.node)))
        });
        let mut selected: Vec<Partner> = Vec::new();
        for partner in result {
            if selected.len() >= max { break; }
            let redundant_ancestor = selected.iter().any(|previous| {
                previous.files == partner.files &&
                (self.inside(partner.node, previous.node) || self.inside(previous.node, partner.node))
            });
            if !redundant_ancestor {
                selected.push(partner);
            }
        }
        // Remaining unique content copies in other, unlisted folders. This is an advisory.
        let remaining = self.nodes[a as usize].shared.iter()
            .filter(|&&(id, copies)| self.id_count[id as usize] > copies &&
                !selected.iter().any(|p| self.copies_in(p.node, id) > 0))
            .map(|&(id, copies)| u64::from(copies) * self.id_size[id as usize])
            .sum();
        (selected, remaining)
    }

    /// Dateien in a, deren Inhalt nirgends außerhalb von a vorkommt: (Pfad relativ zu a, Größe), größte zuerst.
    pub(crate) fn only_here(&self, a: u32) -> Vec<(PathBuf, u64)> {
        let mut result: Vec<(PathBuf, u64)> = Vec::new();
        let mut stack: Vec<(u32, PathBuf)> = vec![(a, PathBuf::new())];
        while let Some((n, relative)) = stack.pop() {
            for &rec_index in &self.direct_files[n as usize] {
                let rec = &self.recs[rec_index as usize];
                let covered = rec.id.is_some_and(|id| self.id_count[id as usize] > self.copies_in(a, id));
                if !covered {
                    result.push((relative.join(&rec.name), rec.size));
                }
            }
            for &child in &self.children[n as usize] {
                stack.push((child, relative.join(&self.nodes[child as usize].name)));
            }
        }
        result.sort_by(|x, y| y.1.cmp(&x.1).then_with(|| x.0.cmp(&y.0)));
        result
    }

    /// Alle Dateien in a: (Pfad relativ zu a, Größe, Inhalt liegt auch außerhalb von a). Ohne Kopie zuerst, dann nach Größe.
    pub(crate) fn files_of(&self, a: u32) -> Vec<(PathBuf, u64, bool)> {
        let mut result: Vec<(PathBuf, u64, bool)> = Vec::new();
        let mut stack: Vec<(u32, PathBuf)> = vec![(a, PathBuf::new())];
        while let Some((n, relative)) = stack.pop() {
            for &rec_index in &self.direct_files[n as usize] {
                let rec = &self.recs[rec_index as usize];
                let covered = rec.id.is_some_and(|id| self.id_count[id as usize] > self.copies_in(a, id));
                result.push((relative.join(&rec.name), rec.size, covered));
            }
            for &child in &self.children[n as usize] {
                stack.push((child, relative.join(&self.nodes[child as usize].name)));
            }
        }
        result.sort_by(|x, y| x.2.cmp(&y.2).then_with(|| y.1.cmp(&x.1)).then_with(|| x.0.cmp(&y.0)));
        result
    }
}

pub(crate) fn analyze(index: &FolderIndex, params: &Params) -> Vec<Row> {
    let mut all: Vec<Row> = Vec::new();
    for a in 0..index.nodes.len() as u32 {
        let node = &index.nodes[a as usize];
        // Ordner ohne Dateiinhalt (nur leere Dateien) geben keinen Platz frei und würden die Liste nur füllen.
        if node.total_files < params.min_files || node.total_bytes == 0 {
            continue;
        }
        let (covered_files, covered_bytes) = index.coverage(a);
        let (copy_files, copy_bytes) = index.copy_coverage(a);
        let provisional_class = if covered_files == node.total_files {
            2
        } else if covered_bytes > 0 && u128::from(covered_bytes) * 1000 >= u128::from(params.threshold_permille) * u128::from(node.total_bytes) {
            1
        } else {
            continue;
        };
        // Unsicher nur, wenn der Stand gespeichert ist oder unterhalb dieses Ordners etwas nicht gelesen werden konnte.
        // Geänderte oder fehlende Hash-Zuordnungen machen einzelne Dateien "einmalig" und lassen die Abdeckung schrumpfen:
        // das ist vorsichtig und braucht keine globale Warnung.
        let class = if index.is_uncertain(a) { 0 } else { provisional_class };
        all.push(Row {
            a,
            class,
            covered_files,
            total_files: node.total_files,
            covered_bytes,
            total_bytes: node.total_bytes,
            copy_files,
            copy_bytes,
            distinct: index.distinct_contents(a),
            twins: 0,
            partners: Vec::new(),
            rest_bytes: 0,
        });
    }

    let class_of: HashMap<u32, u8> = all.iter().map(|row| (row.a, row.class)).collect();
    let mut rows: Vec<Row> = if params.summarize {
        all.into_iter()
            .filter(|row| {
                // Ausblenden, wenn ein übergeordneter Ordner schon mindestens genauso stark gemeldet ist.
                let mut parent = index.nodes[row.a as usize].parent;
                while let Some(p) = parent {
                    if class_of.get(&p).is_some_and(|class| *class >= row.class) {
                        return false;
                    }
                    parent = index.nodes[p as usize].parent;
                }
                true
            })
            .collect()
    } else {
        all
    };

    // Zwillinge: grüne Ordner mit exakt gleicher Inhaltsmenge. Ineinander verschachtelte zählen nicht doppelt.
    let mut groups: HashMap<(&[(u32, u32)], u64), Vec<usize>> = HashMap::new();
    for (position, row) in rows.iter().enumerate() {
        if row.class == 2 {
            groups.entry((index.nodes[row.a as usize].shared.as_slice(), row.total_files)).or_default().push(position);
        }
    }
    let mut twin_updates: Vec<(usize, u32)> = Vec::new();
    for members in groups.values() {
        let tops: Vec<usize> = members
            .iter()
            .copied()
            .filter(|&m| !members.iter().any(|&other| other != m && index.inside(rows[m].a, rows[other].a)))
            .collect();
        if tops.len() >= 2 {
            for &position in &tops {
                twin_updates.push((position, tops.len() as u32));
            }
        }
    }
    for (position, size) in twin_updates {
        rows[position].twins = size;
    }

    if let Some(disk) = params.disk {
        rows.retain(|row| index.nodes[row.a as usize].disk == disk);
    }
    rows.sort_by(|x, y| {
        let primary = match params.sort.as_str() {
            "Größe" => y.total_bytes.cmp(&x.total_bytes),
            "Dateianzahl" => y.total_files.cmp(&x.total_files),
            "Pfad" => index.node_path(x.a).cmp(&index.node_path(y.a)),
            "Neueste Datei" => index.node_newest(y.a).cmp(&index.node_newest(x.a)),
            _ => y.class.cmp(&x.class).then(y.covered_bytes.cmp(&x.covered_bytes)),
        };
        primary.then_with(|| index.node_path(x.a).cmp(&index.node_path(y.a)))
    });
    rows
}

pub(crate) fn fill_partners(index: &FolderIndex, rows: &mut [Row], max: usize) {
    for row in rows {
        let (partners, rest) = index.partners(row.a, max);
        row.partners = partners;
        row.rest_bytes = rest;
    }
}

// ---- PURE-END ----

fn permille(part: u64, total: u64) -> String {
    if total == 0 {
        return "-".to_owned();
    }
    // Abgerundet, damit 99,96 % nie als 100,0 % erscheint.
    let value = (u128::from(part) * 1000 / u128::from(total)) as f64 / 10.0;
    format!("{value:.1} %")
}

fn day(seconds: u64) -> String {
    if seconds == 0 {
        return "?".to_owned();
    }
    Utc.timestamp_opt(seconds as i64, 0).single().unwrap_or_default().with_timezone(&Local).format("%Y-%m-%d").to_string()
}

fn short_path(path: &Path) -> String {
    let names: Vec<String> = path
        .components()
        .filter_map(|c| match c {
            Component::Normal(name) => Some(name.to_string_lossy().into_owned()),
            _ => None,
        })
        .collect();
    let start = names.len().saturating_sub(2);
    names[start..].join("/")
}

fn size_text(files: u64, bytes: u64) -> String {
    format!("{} ({files} Dateien)", format_size(bytes, BINARY))
}

fn to_rows(index: &FolderIndex, rows: &[Row]) -> Vec<Vec<String>> {
    rows.iter()
        .take(PAGE_SIZE)
        .map(|row| {
            let first_partner = row.partners.first();
            let partner_text = if row.partners.is_empty() {
                "Fundstelle nicht bestimmbar".to_owned()
            } else {
                let parts: Vec<String> = row.partners.iter().map(|p| {
                    let label = match p.kind { 2 => "identisch", 1 => "A in B", _ => "teilweise" };
                    format!("{label}: {} ({} / {} Dateien)", short_path(&index.node_path(p.node)), p.files, row.total_files)
                }).collect();
                let more = if row.rest_bytes > 0 { format!(", weitere {}", permille(row.rest_bytes, row.total_bytes)) } else { String::new() };
                format!("auch in: {}{more}", parts.join(", "))
            };
            let a_newest = index.node_newest(row.a);
            let dates = match first_partner {
                Some(p) => {
                    let b_newest = index.node_newest(p.node);
                    let hint = match a_newest.cmp(&b_newest) {
                        Ordering::Less => "  (Fundstelle ist neuer)",
                        Ordering::Greater => "  (dieser Ordner ist neuer)",
                        Ordering::Equal => "",
                    };
                    format!("neueste Datei: hier {}, Fundstelle {}{hint}", day(a_newest), day(b_newest))
                }
                None => format!("neueste Datei: hier {}", day(a_newest)),
            };
            let twin = if row.twins >= 2 { format!("ZWILLING: {} Ordner mit gleichem Inhalt – manuell vergleichen", row.twins) } else { String::new() };
            let pair_ratio = first_partner.map(|p| {
                let b_files = index.nodes[p.node as usize].total_files;
                let a_part = permille(p.files, row.total_files);
                let b_part = permille(p.files, b_files);
                format!("A→B {a_part} · B→A {b_part}")
            }).unwrap_or_default();
            let best_kind = row.partners.first().map(|p| p.kind);
            let (headline, color) = match (row.class, best_kind) {
                (0, _) => ("UNGEPRÜFT (gespeicherter Stand oder Ordner nicht vollständig gelesen)".to_owned(), "x"),
                (2, Some(2)) => ("IDENTISCH mit einem anderen Ordner".to_owned(), "g"),
                (2, Some(1)) => ("KOMPLETT IN EINEM ANDEREN ORDNER".to_owned(), "g"),
                (2, _) => ("KOMPLETT VORHANDEN, aber auf mehrere Ordner verteilt".to_owned(), "t"),
                _ => (format!("TEILWEISE {} der Bytes", permille(row.covered_bytes, row.total_bytes)), "a"),
            };
            vec![
                row.class.to_string(),
                row.a.to_string(),
                index.node_disk_name(row.a).to_owned(),
                index.node_path(row.a).display().to_string(),
                size_text(row.total_files, row.total_bytes),
                format!("Inhalt {} · Kopien {} / {}", permille(row.covered_bytes, row.total_bytes), row.copy_files, row.total_files),
                partner_text,
                first_partner.map(|p| index.node_path(p.node).display().to_string()).unwrap_or_default(),
                dates,
                twin,
                headline,
                color.to_owned(),
                pair_ratio,
                "0".to_owned(),
            ]
        })
        .collect()
}


/// A read-only projection of the existing scan index. Content ids are derived from
/// previously verified duplicate groups; unique records have no content id.
/// This is NOT a fresh audit and cannot certify an entire directory for deletion.
#[derive(Clone, Debug)]
pub(crate) struct IndexedFile {
    pub path: PathBuf,
    pub size: u64,
    pub modified: u64,
    pub content_id: Option<u32>,
    pub fast_eligible: bool,
}

impl FolderIndex {
    fn indexed_files_under(&self, root: u32, fast_eligible: bool) -> Vec<IndexedFile> {
        let mut found = Vec::new();
        let mut todo = vec![root];
        while let Some(node) = todo.pop() {
            let base = self.node_path(node);
            for &record in &self.direct_files[node as usize] {
                let file = &self.recs[record as usize];
                found.push(IndexedFile {
                    path: base.join(&file.name),
                    size: file.size,
                    modified: file.modified,
                    content_id: file.id,
                    fast_eligible,
                });
            }
            todo.extend(self.children[node as usize].iter().copied());
        }
        found.sort_by(|a, b| a.path.cmp(&b.path));
        found
    }
}

/// Reuses a finished in-memory scan (or a labelled stale snapshot). No disk scan
/// and no new content hashes are performed here. Reject overlapping roots.
pub(crate) fn index_pair_preview(a: &Path, b: &Path) -> Result<(Vec<IndexedFile>, Vec<IndexedFile>, String), String> {
    if a == b || a.starts_with(b) || b.starts_with(a) {
        return Err("A und B müssen zwei unterschiedliche, nicht verschachtelte Ordner sein.".into());
    }
    let index = INDEX.lock().map_err(|_| "Index gesperrt")?
        .clone().ok_or("Kein Analyseindex vorhanden. Zuerst einen Hash-Scan ausführen.")?;
    let a_node = (0..index.nodes.len()).find(|&n| index.node_path(n as u32) == a)
        .ok_or("Ordner A wurde im Index nicht gefunden")? as u32;
    let b_node = (0..index.nodes.len()).find(|&n| index.node_path(n as u32) == b)
        .ok_or("Ordner B wurde im Index nicht gefunden")? as u32;
    let mut limitations = Vec::new();
    if index.from_cache { limitations.push("gespeicherter, möglicherweise veralteter Index"); }
    if index.is_uncertain(a_node) || index.is_uncertain(b_node) { limitations.push("Scanwarnungen / unvollständige Erfassung"); }
    if index.min_size > 0 { limitations.push("eventuell kleinere Dateien nicht gehasht"); }
    if index.junk_skipped > 0 { limitations.push("Systemdateien wurden im Index ausgelassen"); }
    let note = if limitations.is_empty() {
        "Index-Vorschau: keine erneute Festplattenanalyse. Übereinstimmungen gelten für den Scanzeitpunkt; vor Aktionen wird jede Datei erneut geprüft.".to_owned()
    } else {
        format!("UNVOLLSTÄNDIGE / UNVERIFIZIERTE Index-Vorschau: {}. Für eine vollständige Aussage 'Inhalte neu prüfen' wählen.", limitations.join("; "))
    };
    // Fast mode is offered only for a current, clean BLAKE3 scan. Saved/stale
    // snapshots and scan warnings are never sufficient for the fast shortcut.
    let fast_eligible = index.hash_label == "Blake3" && !index.from_cache
        && !index.is_uncertain(a_node) && !index.is_uncertain(b_node);
    Ok((index.indexed_files_under(a_node, fast_eligible), index.indexed_files_under(b_node, fast_eligible), note))
}

fn to_model(rows: Vec<Vec<String>>) -> ModelRc<ModelRc<SharedString>> {
    let rows: Vec<ModelRc<SharedString>> = rows.into_iter().map(|row| ModelRc::new(VecModel::from(row.into_iter().map(SharedString::from).collect::<Vec<_>>()))).collect();
    ModelRc::new(VecModel::from(rows))
}

fn disk_summary(index: &FolderIndex) -> String {
    let mut lines: Vec<String> = index
        .disks
        .iter()
        .filter(|d| d.files > 0)
        .map(|d| {
            format!(
                "{}: {} in {} Dateien. Inhalt auch auf anderer Platte: {} ({}). Kopie nur auf derselben Platte: {}.",
                d.name,
                format_size(d.bytes, BINARY),
                d.files,
                format_size(d.other_disk_bytes, BINARY),
                permille(d.other_disk_bytes, d.bytes),
                format_size(d.same_disk_bytes, BINARY)
            )
        })
        .collect();
    if lines.is_empty() {
        lines.push("Keine Dateien im Scan.".to_owned());
    }
    lines.join("\n")
}

fn warnings(index: &FolderIndex) -> String {
    let mut text = String::new();
    if index.from_cache {
        text.push_str(" GESPEICHERTER STAND: Daten können veraltet sein. Neu scannen und streng prüfen.");
    }
    if !index.warnings.is_empty() {
        let affected = index.warned.iter().filter(|w| **w).count();
        text.push_str(&format!(
            " {} Scanwarnungen (z. B. nicht lesbare Ordner). Betroffen sind {affected} Ordner samt Oberordnern: sie erscheinen als UNGEPRÜFT. Alle anderen bleiben gültig.{}",
            index.warnings.len(),
            if index.global_warning { " Mindestens eine Warnung hatte keinen Pfad: dann ist ALLES ungeprüft." } else { "" }
        ));
    }
    if index.stale_groups > 0 {
        text.push_str(&format!(" {} Dateien haben sich seit dem Hashen geändert oder fehlen und zählen als einmalig (das ist vorsichtig).", index.stale_groups));
    }
    if index.hash_label != "Blake3" {
        text.push_str(&format!(" ACHTUNG: Hash {} ist nicht Blake3. Für Löschentscheidungen Blake3 verwenden.", index.hash_label));
    }
    if index.skipped_small > 0 {
        text.push_str(&format!(
            " ACHTUNG: {} Dateien unter {} Bytes hat der Scan nicht verglichen. Sie zählen als \"nur hier\". Für genaue Werte im Scan die Mindestgröße auf 0 setzen.",
            index.skipped_small, index.min_size
        ));
    }
    if index.junk_skipped > 0 {
        text.push_str(&format!(" Systemdateien (.DS_Store, ._*, Thumbs.db, desktop.ini, .localized) ignoriert: {}.", index.junk_skipped));
    }
    text
}

fn summary(index: &FolderIndex, rows: &[Row], seconds: f32) -> String {
    let green = rows.iter().filter(|r| r.class == 2).count();
    let yellow = rows.iter().filter(|r| r.class == 1).count();
    let uncertain = rows.len().saturating_sub(green + yellow);
    format!(
        "{} angezeigte Kandidaten (global voll gedeckt {green}, teilweise {yellow}, unsicher {uncertain}), {} Dateien, Hash {}, {seconds:.1} s.{} GLOBALE ABDECKUNG != ORDNER B. Erst konkrete A/B-Beziehung ansehen, anschließend streng prüfen.",
        rows.len(),
        index.file_count,
        index.hash_label,
        warnings(index)
    )
}

fn detail_text(index: &FolderIndex, row: &Row) -> String {
    let path = index.node_path(row.a);
    let mut text = format!(
        "{}\nPlatte: {}\nGröße: {}, neueste Datei {}\nAnderswo vorhanden: {} der Bytes, {} von {} Dateien\n",
        path.display(),
        index.node_disk_name(row.a),
        size_text(row.total_files, row.total_bytes),
        day(index.node_newest(row.a)),
        permille(row.covered_bytes, row.total_bytes),
        row.covered_files,
        row.total_files
    );
    text.push_str(&format!("Externe Dateikopien (1:1): {} von {} ({} der Bytes). Unterschiedliche Inhalte insgesamt: {}.\n", row.copy_files, row.total_files, permille(row.copy_bytes, row.total_bytes), row.distinct));
    if index.is_uncertain(row.a) {
        text.push_str("ACHTUNG: Gespeicherter Stand oder dieser Ordner wurde nicht vollständig gelesen. Alle Paarangaben nur Hinweise!\n");
    }
    if row.twins >= 2 {
        text.push_str(&format!("ZWILLING: {} Ordner haben genau denselben Inhalt. Löschst du alle, ist der Inhalt weg.\n", row.twins));
    }
    text.push_str("\nKonkrete Ordnerpaare (Anteil der Datei-Bytes aus A, die B selbst enthält):\n");
    if row.partners.is_empty() {
        text.push_str("  keine Fundstelle bestimmbar\n");
    }
    for p in &row.partners {
        let b_files = index.nodes[p.node as usize].total_files;
        let label = if p.kind == 2 { "IDENTISCH" }
            else if p.files == row.total_files { "A VOLLSTÄNDIG IN B" }
            else if p.files == b_files { "B VOLLSTÄNDIG IN A" }
            else { "TEILWEISE" };
        text.push_str(&format!(
            "  {label}: {}\n    A→B {} / {} Dateien ({}), B→A {} / {} Dateien ({})\n    {} / {} Inhalte, Platte {}, neueste Datei {}\n",
            index.node_path(p.node).display(),
            p.files, row.total_files, permille(p.files, row.total_files),
            p.files, b_files, permille(p.files, b_files),
            p.distinct, row.distinct, index.node_disk_name(p.node), day(index.node_newest(p.node))
        ));
    }
    if row.rest_bytes > 0 {
        text.push_str(&format!("  {}  zusätzliche Fundstellen außerhalb der ersten drei Paarvorschläge\n", permille(row.rest_bytes, row.total_bytes)));
    }
    let only = index.only_here(row.a);
    let only_bytes: u64 = only.iter().map(|(_, size)| *size).sum();
    if only.is_empty() {
        text.push_str("\nNur hier im aktuellen Index: nichts. Das ist keine Löschfreigabe.\n");
    } else {
        text.push_str(&format!("\nOhne Kopie im analysierten Bestand ({} Dateien, {}), separat prüfen:\n", only.len(), format_size(only_bytes, BINARY)));
        for (relative, size) in only.iter().take(ONLY_HERE_LIMIT) {
            text.push_str(&format!("  {}  {}\n", format_size(*size, BINARY), relative.display()));
        }
        if only.len() > ONLY_HERE_LIMIT {
            text.push_str(&format!("  ... und {} weitere\n", only.len() - ONLY_HERE_LIMIT));
        }
    }
    text
}

struct View {
    index: Arc<FolderIndex>,
    rows: Vec<Row>,
    /// Kandidaten je Fall: alle, voll gedeckt, teilweise, ungeprüft (nach Plattenfilter, vor Fallfilter).
    counts: [usize; 4],
    total_rows: usize,
    page: usize,
    pages: usize,
}

static INDEX: Mutex<Option<Arc<FolderIndex>>> = Mutex::new(None);
static VIEW: Mutex<Option<Arc<View>>> = Mutex::new(None);
static GENERATION: AtomicU64 = AtomicU64::new(0);
// Keep a previous index as a navigable hint after file changes, but never treat it as verified.
static INDEX_DIRTY: AtomicBool = AtomicBool::new(false);

#[derive(Serialize, Deserialize)]
struct SavedSnapshot {
    version: u32,
    saved_at: u64,
    files: Vec<InputFile>,
    hash_label: String,
    min_size: u64,
    warnings: Vec<String>,
    stale_groups: usize,
}

/// Gespeicherte Ansicht im Cache-Ordner von Krokiet (enthält lokale Dateipfade, aber keine Dateiinhalte).
fn snapshot_path() -> Option<PathBuf> {
    // Der Konfigpfad wird in main() gesetzt, bevor diese Funktion aufgerufen werden kann.
    if let Some(paths) = czkawka_core::common::config_cache_path::get_config_cache_path() {
        return Some(paths.cache_folder.join("folder_relations_snapshot_v8.json"));
    }
    let home = PathBuf::from(std::env::var_os("HOME")?);
    #[cfg(target_os = "macos")]
    let folder = home.join("Library/Application Support/pl.Qarmin.Krokiet");
    #[cfg(not(target_os = "macos"))]
    let folder = home.join(".local/share/krokiet");
    Some(folder.join("folder_relations_snapshot_v8.json"))
}

fn persist_snapshot(files: Vec<InputFile>, hash_label: String, min_size: u64, warnings: Vec<String>, stale_groups: usize, generation: u64) {
    if files.len() > MAX_PERSIST_FILES || generation != GENERATION.load(AtomicOrdering::SeqCst) { return; }
    let Some(destination) = snapshot_path() else { return };
    let Some(parent) = destination.parent() else { return };
    if fs::create_dir_all(parent).is_err() { return; }
    let snapshot = SavedSnapshot {
        version: 8,
        saved_at: SystemTime::now().duration_since(UNIX_EPOCH).map_or(0, |d| d.as_secs()),
        files, hash_label, min_size, warnings, stale_groups,
    };
    let temp = destination.with_extension("json.tmp");
    if let Ok(file) = fs::File::create(&temp) {
        if serde_json::to_writer(file, &snapshot).is_ok() && generation == GENERATION.load(AtomicOrdering::SeqCst) {
            let _ = fs::rename(&temp, &destination); // atomic on the same filesystem
            return;
        }
    }
    let _ = fs::remove_file(&temp);
}

fn load_snapshot() -> Result<FolderIndex, String> {
    let file = fs::File::open(snapshot_path().ok_or("Kein HOME-Verzeichnis".to_owned())?).map_err(|e| e.to_string())?;
    let saved: SavedSnapshot = serde_json::from_reader(file).map_err(|e| format!("Snapshot beschädigt: {e}"))?;
    if saved.version != 8 || saved.files.len() > MAX_PERSIST_FILES {
        return Err("Inkompatibler oder zu großer Snapshot".to_owned());
    }
    Ok(build_index_checked(saved.files, saved.hash_label, saved.min_size, saved.warnings, saved.stale_groups, true))
}

fn store_state(index: Option<Arc<FolderIndex>>, view: Option<Arc<View>>) {
    if let Ok(mut guard) = INDEX.lock() {
        *guard = index;
    }
    if let Ok(mut guard) = VIEW.lock() {
        *guard = view;
    }
}

fn default_params() -> Params {
    Params {
        min_files: 1,
        threshold_permille: 900,
        summarize: false,
        disk: None,
        sort: "Größe".to_owned(),
        page: 0,
    }
}

/// `tab`: 0 alle, 1 voll gedeckt, 2 teilweise, 3 ungeprüft.
fn run_analysis(index: &Arc<FolderIndex>, params: &Params, tab: i32) -> (Arc<View>, String) {
    let started = SystemTime::now();
    let mut rows = analyze(index, params);
    // Identical content groups are symmetric: A=B and B=A must not be separate hits.
    // Choose the deepest representative (folder rather than its encompassing volume).
    // Do NOT collapse merely "globally covered" folders whose contents are split
    // over different destinations; this requires an exact multiset signature.
    let mut groups: HashMap<(Vec<(u32, u32)>, u64), Vec<usize>> = HashMap::new();
    for (position, row) in rows.iter().enumerate() {
        if row.class == 2 && row.total_files > 0
            && index.nodes[row.a as usize].shared.iter().map(|(_, count)| u64::from(*count)).sum::<u64>() == row.total_files {
            groups.entry((index.nodes[row.a as usize].shared.clone(), row.total_files)).or_default().push(position);
        }
    }
    let mut hidden = BTreeSet::new();
    let mut representative_count = Vec::<(usize, u32)>::new();
    for members in groups.into_values() {
        if members.len() < 2 { continue; }
        // Prefer leaf groups. Mark ancestors through parent pointers in O(n * tree depth),
        // avoiding O(n²) when thousands of folders share the same content signature.
        let member_nodes: HashSet<u32> = members.iter().map(|&i| rows[i].a).collect();
        let mut ancestors = HashSet::new();
        for &member in &members {
            let mut parent = index.nodes[rows[member].a as usize].parent;
            while let Some(p) = parent {
                if member_nodes.contains(&p) { ancestors.insert(p); }
                parent = index.nodes[p as usize].parent;
            }
        }
        let leaves: Vec<usize> = members.iter().copied()
            .filter(|&i| !ancestors.contains(&rows[i].a)).collect();
        if leaves.len() < 2 { continue; }
        let keep = leaves[0]; // row order is already stable according to the chosen sort order
        representative_count.push((keep, leaves.len() as u32));
        for member in members { if member != keep { hidden.insert(member); } }
    }
    for (keep, count) in representative_count { rows[keep].twins = count; }
    rows = rows.into_iter().enumerate().filter_map(|(i, row)| (!hidden.contains(&i)).then_some(row)).collect();
    let counts = [rows.len(), rows.iter().filter(|r| r.class == 2).count(), rows.iter().filter(|r| r.class == 1).count(), rows.iter().filter(|r| r.class == 0).count()];
    match tab {
        1 => rows.retain(|r| r.class == 2),
        2 => rows.retain(|r| r.class == 1),
        3 => rows.retain(|r| r.class == 0),
        _ => {}
    }
    let total_rows = rows.len();
    let pages = total_rows.div_ceil(PAGE_SIZE).max(1);
    let page = params.page.min(pages - 1);
    let from = page * PAGE_SIZE;
    let mut visible = rows.into_iter().skip(from).take(PAGE_SIZE).collect::<Vec<_>>();
    fill_partners(index, &mut visible, PARTNER_COUNT);
    let seconds = started.elapsed().map_or(0.0, |d| d.as_secs_f32());
    let text = format!("{} Seite {} / {} · {} Kandidaten in diesem Reiter.", summary(index, &visible, seconds), page + 1, pages, total_rows);
    (Arc::new(View { index: Arc::clone(index), rows: visible, counts, total_rows, page, pages }), text)
}

fn publish_view(weak: &Weak<MainWindow>, view: &Arc<View>, status: String, reset_disks: bool) {
    let rows = to_rows(&view.index, &view.rows);
    let page_display = format!("Seite {} / {} ({} Kandidaten)", view.page + 1, view.pages, view.total_rows);
    let current_page = i32::try_from(view.page).unwrap_or(i32::MAX);
    let total_pages = i32::try_from(view.pages).unwrap_or(i32::MAX);
    let summary_text = disk_summary(&view.index);
    let tab_counts: Vec<i32> = view.counts.iter().map(|c| i32::try_from(*c).unwrap_or(i32::MAX)).collect();
    let mut disk_names: Vec<String> = vec![ALL_DISKS.to_owned()];
    disk_names.extend(view.index.disks.iter().filter(|d| d.files > 0).map(|d| d.name.clone()));
    let generation = GENERATION.load(AtomicOrdering::SeqCst);
    let _ = weak.upgrade_in_event_loop(move |app| {
        if generation != GENERATION.load(AtomicOrdering::SeqCst) { return; }
        app.set_folder_relations_rows(to_model(rows));
        app.set_folder_relations_status(status.into());
        app.set_folder_relations_page_info(page_display.into());
        app.set_folder_relations_current_page(current_page);
        app.set_folder_relations_page_count(total_pages);
        app.set_folder_relations_disk_summary(summary_text.into());
        app.set_folder_relations_tab_counts(ModelRc::new(VecModel::from(tab_counts)));
        app.set_folder_relations_detail("Wähle eine Zeile, um Details zu sehen.".into());
        app.set_folder_relations_files(to_model(Vec::new()));
        if reset_disks {
            app.set_folder_relations_disks(ModelRc::new(VecModel::from(disk_names.into_iter().map(SharedString::from).collect::<Vec<_>>())));
        }
        app.set_folder_relations_available(true);
        app.set_folder_relations_busy(false);
    });
}

fn publish_message(weak: &Weak<MainWindow>, available: bool, status: String) {
    let generation = GENERATION.load(AtomicOrdering::SeqCst);
    let _ = weak.upgrade_in_event_loop(move |app| {
        if generation != GENERATION.load(AtomicOrdering::SeqCst) { return; }
        app.set_folder_relations_available(available);
        app.set_folder_relations_status(status.into());
        app.set_folder_relations_busy(false);
        if !available {
            app.set_folder_relations_rows(to_model(Vec::new()));
            app.set_folder_relations_disk_summary(SharedString::new());
            app.set_folder_relations_detail(SharedString::new());
            app.set_folder_relations_files(to_model(Vec::new()));
            app.set_folder_relations_page_info(SharedString::new());
        }
    });
}

/// Alles aus einem fertigen Duplikat-Scan. Wird erstellt, BEVOR der Finder in Krokiets gemeinsamen Zustand wandert.
pub(crate) struct ScanSnapshot {
    group_of: HashMap<PathBuf, (u32, u64, u64)>,
    hash_label: String,
    min_size: u64,
    scan_warnings: Vec<String>,
    generation: u64,
    inventory_job: Box<dyn FnOnce() -> Result<(Vec<FileEntry>, Vec<String>), String>>,
}

pub(crate) fn prepare(tool: &DuplicateFinder, stop_flag: &Arc<AtomicBool>) -> Result<ScanSnapshot, String> {
    // New generation invalidates older recalculations, even if they finish later.
    let generation = GENERATION.fetch_add(1, AtomicOrdering::SeqCst) + 1;
    store_state(None, None);
    INDEX_DIRTY.store(false, AtomicOrdering::SeqCst);
    if tool.get_stopped_search() {
        return Err("Der Scan wurde abgebrochen: keine Ordner-Übersicht.".to_owned());
    }
    let params = tool.get_params();
    if !matches!(params.check_method, CheckingMethod::Hash) {
        return Err("Die Ordner-Übersicht braucht im Duplikat-Scan die Prüfmethode \"Hash\".".to_owned());
    }
    if tool.get_use_reference() {
        return Err("Die Ordner-Übersicht unterstützt keine Referenzordner.".to_owned());
    }
    let mut group_of: HashMap<PathBuf, (u32, u64, u64)> = HashMap::new();
    for (group_number, group) in tool.get_files_sorted_by_hash().values().flatten().enumerate() {
        for entry in group {
            group_of.insert(entry.path.clone(), (group_number as u32, entry.size, entry.modified_date));
        }
    }
    Ok(ScanSnapshot {
        group_of,
        hash_label: format!("{:?}", params.hash_type),
        min_size: tool.get_minimal_file_size_for_addon(),
        scan_warnings: tool.get_addon_scan_warnings(),
        generation,
        inventory_job: tool.prepare_full_inventory(stop_flag),
    })
}

/// Läuft im Scan-Thread, nachdem die normalen Ergebnisse an die Oberfläche übergeben wurden.
pub(crate) fn publish(weak: Weak<MainWindow>, snapshot: Result<ScanSnapshot, String>) {
    let snapshot = match snapshot {
        Ok(snapshot) => snapshot,
        Err(reason) => {
            store_state(None, None);
            publish_message(&weak, false, reason);
            return;
        }
    };
    let ScanSnapshot { group_of, hash_label, min_size, scan_warnings, generation, inventory_job } = snapshot;
    let _ = weak.upgrade_in_event_loop(|app| {
        app.set_folder_relations_available(false);
        app.set_folder_relations_status("Ordner-Übersicht: Inventar wird geprüft ...".into());
    });
    let (files, inventory_warnings) = match inventory_job() {
        Ok(result) => result,
        Err(error) => {
            if generation == GENERATION.load(AtomicOrdering::SeqCst) {
                store_state(None, None);
                publish_message(&weak, false, format!("Inventarisierung abgebrochen: {error}"));
            }
            return;
        }
    };
    if generation != GENERATION.load(AtomicOrdering::SeqCst) { return; }
    let mut seen_grouped = 0usize;
    let mut stale_groups = 0usize;
    let input: Vec<InputFile> = files.into_iter().map(|file| {
        let group = group_of.get(&file.path).and_then(|&(group, size, modified)| {
            seen_grouped += 1;
            if size == file.size && modified == file.modified_date { Some(group) } else {
                stale_groups += 1;
                None
            }
        });
        InputFile { path: file.path, size: file.size, modified: file.modified_date, group }
    }).collect();
    stale_groups += group_of.len().saturating_sub(seen_grouped);
    let mut all_warnings = scan_warnings;
    all_warnings.extend(inventory_warnings);
    let input_for_cache = if input.len() <= MAX_PERSIST_FILES { Some(input.clone()) } else { None };
    let index = Arc::new(build_index_checked(input, hash_label.clone(), min_size, all_warnings.clone(), stale_groups, false));
    let (view, status) = run_analysis(&index, &default_params(), 1);
    if generation != GENERATION.load(AtomicOrdering::SeqCst) { return; }
    store_state(Some(Arc::clone(&index)), Some(Arc::clone(&view)));
    publish_view(&weak, &view, status, true);
    if let Some(files) = input_for_cache {
        // Browsable snapshot only: always marked STALE on restart and NEVER a deletion authorization.
        persist_snapshot(files, hash_label, min_size, all_warnings, stale_groups, generation);
    }
}

/// Any manual file operation invalidates the relationship index. No stale green rows may remain.
pub(crate) fn invalidate_after_manual_change(weak: &slint::Weak<MainWindow>) {
    GENERATION.fetch_add(1, AtomicOrdering::SeqCst);
    INDEX_DIRTY.store(true, AtomicOrdering::SeqCst);
    // Keep the old index for navigating other pairs, instead of forcing a terabyte
    // re-scan after every copy. Drop the computed green view and mark it stale.
    let retained = INDEX.lock().ok().and_then(|guard| guard.clone()).is_some();
    if let Ok(mut guard) = VIEW.lock() { *guard = None; }
    let _ = weak.upgrade_in_event_loop(move |app| {
        app.set_folder_relations_available(retained);
        app.set_folder_relations_rows(to_model(Vec::new()));
        app.set_folder_relations_detail("".into());
        app.set_folder_relations_files(to_model(Vec::new()));
        app.set_folder_relations_status("Daten wurden verändert. Der alte Index bleibt als UNVERIFIZIERTE Orientierung erhalten. Über 'Alle' oder 'Ungeprüft' neu auswerten (ohne neuen Hash-Scan). Für belastbare Vollständigkeit neuen Scan ausführen.".into());
    });
}

pub(crate) fn connect_folder_relations(app: &MainWindow) {
    // Read persisted index outside UI thread. It is explicitly marked as an old snapshot.
    let weak = app.as_weak();
    thread::spawn(move || {
        let Ok(cached) = load_snapshot() else { return; };
        if GENERATION.load(AtomicOrdering::SeqCst) != 0 { return; }
        let index = Arc::new(cached);
        let (view, status) = run_analysis(&index, &default_params(), 1);
        if GENERATION.load(AtomicOrdering::SeqCst) != 0 { return; }
        store_state(Some(Arc::clone(&index)), Some(Arc::clone(&view)));
        publish_view(&weak, &view, status, true);
    });

    let weak = app.as_weak();
    app.on_folder_relations_analyze(move |threshold_percent, min_files, summarize, disk, sort, page, tab| {
        let Some(app) = weak.upgrade() else { return };
        if app.get_folder_relations_busy() { return; }
        let index = INDEX.lock().ok().and_then(|guard| guard.clone());
        let Some(index) = index else {
            app.set_folder_relations_status("Keine Scandaten: zuerst Hash-Duplikatscan durchführen.".into());
            return;
        };
        let generation = GENERATION.load(AtomicOrdering::SeqCst);
        app.set_folder_relations_busy(true);
        let disk_name = disk.to_string();
        let sort_name = sort.to_string();
        let weak = app.as_weak();
        thread::spawn(move || {
            let disk_filter = if disk_name == ALL_DISKS || disk_name.is_empty() { None }
                else { index.disks.iter().position(|d| d.name == disk_name).map(|position| position as u16) };
            let params = Params {
                min_files: u64::try_from(min_files.max(1)).unwrap_or(1),
                threshold_permille: u32::try_from(threshold_percent.clamp(50, 100)).unwrap_or(90) * 10,
                summarize,
                disk: disk_filter,
                sort: sort_name,
                page: usize::try_from(page.max(0)).unwrap_or(0),
            };
            let (view, status) = run_analysis(&index, &params, tab);
            if generation != GENERATION.load(AtomicOrdering::SeqCst) { return; }
            if let Ok(mut guard) = VIEW.lock() { *guard = Some(Arc::clone(&view)); }
            publish_view(&weak, &view, status, false);
        });
    });

    let weak = app.as_weak();
    app.on_folder_relations_select(move |position| {
        let view = VIEW.lock().ok().and_then(|guard| guard.clone());
        let Some(view) = view else { return; };
        let Ok(position) = usize::try_from(position) else { return; };
        let generation = GENERATION.load(AtomicOrdering::SeqCst);
        let weak = weak.clone();
        thread::spawn(move || {
            let Some(row) = view.rows.get(position) else { return };
            let text = detail_text(&view.index, row);
            let base = view.index.node_path(row.a);
            let listing = view.index.files_of(row.a);
            let shown: Vec<Vec<String>> = listing
                .iter()
                .take(FILE_LIST_LIMIT)
                .map(|(relative, size, covered)| {
                    vec![
                        relative.display().to_string(),
                        format_size(*size, BINARY),
                        if *covered { "Kopie anderswo".to_owned() } else { "nur hier".to_owned() },
                    ]
                })
                .collect();
            actions::set_files(listing.iter().take(FILE_LIST_LIMIT).map(|(relative, _, _)| base.join(relative)).collect(), base);
            if generation != GENERATION.load(AtomicOrdering::SeqCst) { return; }
            let _ = weak.upgrade_in_event_loop(move |app| {
                app.set_folder_relations_detail(text.into());
                app.set_folder_relations_files(to_model(shown));
            });
        });
    });

    actions::connect(app);
}

#[cfg(test)]
mod tests {
    use super::*;

    fn file(path: &str, size: u64, group: Option<u32>) -> InputFile {
        InputFile { path: PathBuf::from(path), size, modified: 1, group }
    }

    fn params(threshold_permille: u32) -> Params {
        Params { min_files: 1, threshold_permille, summarize: false, disk: None, sort: "Abdeckung".to_owned(), page: 0 }
    }

    fn find<'a>(index: &FolderIndex, rows: &'a [Row], suffix: &str) -> Option<&'a Row> {
        rows.iter().find(|r| index.node_path(r.a).ends_with(suffix))
    }

    /// 2025: 10 Dateien. 2026: dieselben 10 (andere Namen) plus 5 neue.
    fn scenario() -> Vec<InputFile> {
        let mut files = Vec::new();
        for i in 0..10u32 {
            files.push(file(&format!("/Volumes/P1/2025/allefotos/a{i}.jpg"), 100 + u64::from(i), Some(i)));
            files.push(file(&format!("/Volumes/P2/2026/neu/b{i}.jpg"), 100 + u64::from(i), Some(i)));
        }
        for i in 0..5u64 {
            files.push(file(&format!("/Volumes/P2/2026/neu/extra{i}.jpg"), 500 + i, None));
        }
        files
    }

    #[test]
    fn contained_folder_is_green_with_partner() {
        let index = build_index(scenario(), "Blake3".to_owned(), 0);
        let mut rows = analyze(&index, &params(900));
        fill_partners(&index, &mut rows, 3);
        let row = find(&index, &rows, "allefotos").expect("allefotos muss gemeldet werden");
        assert_eq!(row.class, 2);
        assert_eq!((row.covered_files, row.total_files), (10, 10));
        assert!(index.node_path(row.partners[0].node).ends_with("neu"));
        // Der größere Ordner ist NICHT grün: seine 5 neuen Dateien gibt es nur dort.
        assert!(find(&index, &rows, "neu").is_none() || find(&index, &rows, "neu").is_some_and(|r| r.class == 1));
    }

    #[test]
    fn symmetric_identical_folders_are_one_view_row_even_with_same_content_parents() {
        let mut files = Vec::new();
        for i in 0..4u32 {
            files.push(file(&format!("/Volumes/P1/a/f{i}"), 100, Some(i)));
            files.push(file(&format!("/Volumes/P2/b/g{i}"), 100, Some(i)));
        }
        let index = Arc::new(build_index(files, "Blake3".to_owned(), 0));
        let (view, _) = run_analysis(&index, &params(900), 0);
        assert_eq!(view.rows.iter().filter(|row| row.class == 2 && row.twins >= 2).count(), 1);
    }
    #[test]
    fn partial_is_yellow_and_lists_only_here() {
        let mut files = scenario();
        files.push(file("/Volumes/P1/2025/allefotos/nur_hier.jpg", 5, None));
        let index = build_index(files, "Blake3".to_owned(), 0);
        assert!(find(&index, &analyze(&index, &params(1000)), "allefotos").is_none());
        let rows = analyze(&index, &params(900));
        let row = find(&index, &rows, "allefotos").expect("90 % reichen für gelb");
        assert_eq!(row.class, 1);
            let only = index.only_here(row.a);
        assert_eq!(only.len(), 1);
        assert!(only[0].0.ends_with("nur_hier.jpg"));
    }

    #[test]
    fn coverage_split_over_two_folders() {
        let mut files = Vec::new();
        for i in 0..6u32 {
            files.push(file(&format!("/Volumes/P1/a/f{i}"), 50 + u64::from(i), Some(i)));
        }
        for i in 0..3u32 {
            files.push(file(&format!("/Volumes/P2/b/f{i}"), 50 + u64::from(i), Some(i)));
        }
        for i in 3..6u32 {
            files.push(file(&format!("/Volumes/P3/c/f{i}"), 50 + u64::from(i), Some(i)));
        }
        let index = build_index(files, "Blake3".to_owned(), 0);
        let mut rows = analyze(&index, &params(900));
        fill_partners(&index, &mut rows, 3);
        let row = find(&index, &rows, "a").expect("a ist über b und c komplett gedeckt");
        assert_eq!(row.class, 2);
        assert_eq!(row.partners.len(), 2);
    }

    #[test]
    fn twins_are_marked() {
        let mut files = Vec::new();
        for i in 0..4u32 {
            files.push(file(&format!("/Volumes/P1/one/f{i}"), 10 + u64::from(i), Some(i)));
            files.push(file(&format!("/Volumes/P2/two/g{i}"), 10 + u64::from(i), Some(i)));
        }
        let index = build_index(files, "Blake3".to_owned(), 0);
        let rows = analyze(&index, &params(900));
        assert_eq!(rows.iter().filter(|r| r.twins == 2).count(), 2);
    }

    #[test]
    fn junk_files_are_ignored() {
        let mut files = Vec::new();
        for i in 0..3u32 {
            files.push(file(&format!("/Volumes/P1/x/f{i}"), 10 + u64::from(i), Some(i)));
            files.push(file(&format!("/Volumes/P2/y/f{i}"), 10 + u64::from(i), Some(i)));
        }
        files.push(file("/Volumes/P1/x/.DS_Store", 6148, None));
        let index = build_index(files, "Blake3".to_owned(), 0);
        assert_eq!(index.junk_skipped, 1);
        assert!(find(&index, &analyze(&index, &params(900)), "x").is_some_and(|r| r.class == 2));
    }

    #[test]
    fn disks_are_recognized() {
        assert_eq!(disk_of(Path::new("/Volumes/Foto Platte/a/b")), "Foto Platte");
        assert_eq!(disk_of(Path::new("/Users/me/x")), "Startvolume");
        assert_eq!(disk_of(Path::new("/media/me/USB/x")), "USB");
        assert_eq!(disk_of(Path::new("/")), "Startvolume");
    }

    #[test]
    fn unrelated_folders_report_nothing() {
        let files = vec![file("/Volumes/P1/a/f1", 5, None), file("/Volumes/P1/a/f2", 6, None), file("/Volumes/P1/b/f3", 7, None)];
        let index = build_index(files, "Blake3".to_owned(), 0);
        assert!(analyze(&index, &params(500)).is_empty());
    }
    #[test]
    fn folder_pair_is_contained_and_not_identical() {
        let index = build_index(scenario(), "Blake3".to_owned(), 0);
        let rows = analyze(&index, &params(900));
        let a = find(&index, &rows, "allefotos").unwrap().a;
        let (partners, _) = index.partners(a, 3);
        assert!(!partners.is_empty());
        assert_eq!(partners[0].kind, 1); // fully contained in B with more files
        assert_eq!(partners[0].files, 10);
        assert!(index.node_path(partners[0].node).ends_with("neu"));
    }

    #[test]
    fn folder_pair_split_over_two_is_not_complete_in_one_folder() {
        let mut files = Vec::new();
        for i in 0..6u32 {
            files.push(file(&format!("/Volumes/D/a/old{i}"), 100, Some(i)));
            let other = if i < 3 { "b" } else { "c" };
            files.push(file(&format!("/Volumes/D/{other}/new{i}"), 100, Some(i)));
        }
        let index = build_index(files, "Blake3".to_owned(), 0);
        let row = find(&index, &analyze(&index, &params(900)), "a").unwrap().a;
        assert_eq!(index.coverage(row).0, 6); // global 100 %
        let (partners, _) = index.partners(row, 3);
        assert!(partners.iter().all(|p| p.kind == 0));
        assert!(partners.iter().all(|p| p.files < 6));
    }

    #[test]
    fn folder_pair_copy_counts_vs_content_coverage() {
        let files = vec![
            file("/Volumes/D/A/one", 10, Some(0)),
            file("/Volumes/D/A/two", 10, Some(0)),
            file("/Volumes/D/B/other", 10, Some(0)),
        ];
        let index = build_index(files, "Blake3".to_owned(), 0);
        let rows = analyze(&index, &params(900));
        let row = find(&index, &rows, "A").unwrap();
        assert_eq!((row.covered_files, row.copy_files, row.total_files), (2, 1, 2));
        let (partners, _) = index.partners(row.a, 3);
        assert!(partners.iter().all(|p| p.kind == 0));
    }

    #[test]
    fn folders_with_only_empty_files_are_not_listed() {
        let files = vec![
            file("/Volumes/D/A/empty", 0, None),
            file("/Volumes/D/B/empty2", 0, None),
            file("/Volumes/D/B/empty3", 0, None),
        ];
        let index = build_index(files, "Blake3".to_owned(), 0);
        assert!(analyze(&index, &params(900)).is_empty());
    }

    #[test]
    fn empty_files_next_to_real_files_still_count() {
        let files = vec![
            file("/Volumes/D/A/real", 10, Some(0)),
            file("/Volumes/D/A/empty", 0, None),
            file("/Volumes/D/B/real", 10, Some(0)),
            file("/Volumes/D/B/empty", 0, None),
        ];
        let index = build_index(files, "Blake3".to_owned(), 0);
        let rows = analyze(&index, &params(900));
        let a = find(&index, &rows, "A").unwrap();
        assert_eq!((a.class, a.covered_files, a.total_files), (2, 2, 2));
    }

    #[test]
    fn folder_pair_many_equal_content_files_still_discovered() {
        let mut files = Vec::new();
        for i in 0..220 {
            files.push(file(&format!("/Volumes/D/A/f{i}"), 10, Some(0)));
            files.push(file(&format!("/Volumes/D/B/g{i}"), 10, Some(0)));
        }
        let index = build_index(files, "Blake3".to_owned(), 0);
        let rows = analyze(&index, &params(900));
        let a = find(&index, &rows, "A").unwrap().a;
        let (partners, _) = index.partners(a, 3);
        assert!(partners.iter().any(|p| p.kind == 2));
    }

    #[test]
    fn cache_and_pathless_warning_make_everything_uncertain() {
        let files = scenario();
        let cached = build_index_checked(files.clone(), "Blake3".to_owned(), 0, Vec::new(), 0, true);
        let rows = analyze(&cached, &params(900));
        assert_eq!(find(&cached, &rows, "allefotos").unwrap().class, 0);
        let pathless = build_index_checked(files, "Blake3".to_owned(), 0, vec!["permission denied".to_owned()], 0, false);
        let rows = analyze(&pathless, &params(900));
        assert_eq!(find(&pathless, &rows, "allefotos").unwrap().class, 0);
    }

    #[test]
    fn warning_inside_a_makes_only_a_uncertain() {
        let mut files = scenario();
        for i in 0..4u32 {
            files.push(file(&format!("/Volumes/P3/other/o{i}.jpg"), 300 + u64::from(i), Some(100 + i)));
            files.push(file(&format!("/Volumes/P4/copy/o{i}.jpg"), 300 + u64::from(i), Some(100 + i)));
        }
        // nicht lesbarer Ordner unterhalb von allefotos und ein nicht lesbarer Ordner direkt unter der Platte P4
        let warnings = vec![
            "Cannot open dir /Volumes/P1/2025/allefotos/privat, reason Permission denied (os error 13)".to_owned(),
            "Cannot open dir /Volumes/P4/.Trashes/501, reason Permission denied (os error 13)".to_owned(),
        ];
        let index = build_index_checked(files, "Blake3".to_owned(), 0, warnings, 0, false);
        let rows = analyze(&index, &params(900));
        assert_eq!(find(&index, &rows, "allefotos").unwrap().class, 0, "unterhalb liegt ein nicht lesbarer Ordner");
        assert_eq!(find(&index, &rows, "other").unwrap().class, 2, "Warnung betrifft nur P4, nicht diesen Ordner");
        // Der unlesbare Ordner liegt neben "copy", nicht darin: "copy" bleibt gültig, die ganze Platte P4 nicht.
        assert_eq!(find(&index, &rows, "copy").unwrap().class, 2);
        assert_eq!(find(&index, &rows, "P4").unwrap().class, 0);
    }

    #[test]
    fn changed_hash_groups_only_shrink_coverage() {
        let mut files = scenario();
        // Eine Kopie hat sich seit dem Hashen geändert: ohne Gruppe, also einmalig.
        files[1].group = None;
        let index = build_index_checked(files, "Blake3".to_owned(), 0, Vec::new(), 1, false);
        let rows = analyze(&index, &params(900));
        let a = find(&index, &rows, "allefotos").unwrap();
        assert_eq!(a.class, 1, "9 von 10 gedeckt: gelb, nicht grün");
    }

    #[test]
    fn files_of_lists_uncovered_first() {
        let mut files = scenario();
        files.push(file("/Volumes/P1/2025/allefotos/nur_hier.jpg", 5, None));
        let index = build_index(files, "Blake3".to_owned(), 0);
        let rows = analyze(&index, &params(900));
        let row = find(&index, &rows, "allefotos").unwrap();
        let listing = index.files_of(row.a);
        assert_eq!(listing.len(), 11);
        assert!(listing[0].0.ends_with("nur_hier.jpg") && !listing[0].2, "Datei ohne Kopie steht zuerst");
        assert!(listing[1..].iter().all(|entry| entry.2));
    }
}
