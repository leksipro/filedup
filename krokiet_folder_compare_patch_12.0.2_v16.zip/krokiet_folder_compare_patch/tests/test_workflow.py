"""Static integration regressions. They do not replace Cargo/Slint compilation."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]

class WorkflowTests(unittest.TestCase):
    def test_pair_preview_reuses_existing_index(self):
        core = (ROOT / "krokiet/src/folder_relations.rs").read_text()
        audit = (ROOT / "krokiet/src/folder_compare.rs").read_text()
        installer = (ROOT / "apply_patch.py").read_text()
        self.assertIn("fn index_pair_preview(", core)
        self.assertIn("on_folder_compare_preview", audit)
        self.assertIn("root.folder_compare_preview(a, b)", installer)
        self.assertIn("prepare_index_preview", audit)

    def test_batch_unbounded_and_rechecks_files(self):
        actions = (ROOT / "krokiet/src/folder_audit_actions.rs").read_text()
        self.assertNotIn("MAX_BATCH_FILES", actions)
        self.assertIn('"merge_selected"', actions)
        self.assertIn('"trash_selected:"', actions)
        self.assertIn("copy_missing(&a, &b", actions)
        self.assertIn("preflight_trash_pair_with_mode(&a, &b", actions)
        self.assertIn("delete_all(&paths)", actions)
        self.assertIn("fn conflict_batch()", actions)
        self.assertIn('if action == "verify_conflicts"', actions)
        self.assertIn("BATCH_STOP.load", actions)
        self.assertNotIn("remove_single_folder", actions)

    def test_symmetric_pairs_and_bidirectional_coverage(self):
        core = (ROOT / "krokiet/src/folder_relations.rs").read_text()
        ui = (ROOT / "krokiet/ui/popups/popup_folder_workspace.slint").read_text()
        self.assertIn("let mut groups: HashMap<(Vec<(u32, u32)>, u64)", core)
        self.assertIn("A→B {a_part}", core)
        self.assertIn("B→A {b_part}", core)
        self.assertIn("root.open_compare(root.right_path, root.left_path)", ui)
        self.assertIn('"Konflikte prüfen " + root.audit_counts[4]', ui)

    def test_filter_selection_across_pages_and_separate_confirmations(self):
        ui = (ROOT / "krokiet/ui/popups/popup_folder_workspace.slint").read_text()
        actions = (ROOT / "krokiet/src/folder_audit_actions.rs").read_text()
        self.assertIn("root.audit_action(\"select_all\", 0)", ui)
        self.assertIn("root.audit_action(\"filter:different\", 0)", ui)
        self.assertIn("confirm_trash", ui)
        self.assertIn("confirm_merge", ui)
        self.assertIn("session.selected.extend(shown)", actions)
        self.assertIn("visible_indices(session)", actions)

    def test_v16_check_modes_and_hash_dependency(self):
        actions = (ROOT / "krokiet/src/folder_audit_actions.rs").read_text()
        ui = (ROOT / "krokiet/ui/popups/popup_folder_workspace.slint").read_text()
        installer = (ROOT / "apply_patch.py").read_text()
        index = (ROOT / "krokiet/src/folder_relations.rs").read_text()
        for token in ('TrashCheckMode::Fast', 'TrashCheckMode::FreshHash', 'TrashCheckMode::Bytes',
                      'fn matches_fast_evidence(', 'fn hash_file(', 'entry.fast_proof',
                      'trash_selected:', 'source_stamp(&checked_regular'):
            self.assertIn(token, actions)
        self.assertIn('private property <string> trash_check_mode: "Aktueller Hash"', ui)
        self.assertIn('model: ["Schnell (Index)", "Aktueller Hash", "Bytevergleich"]', ui)
        self.assertIn('add_locked_blake3_dependency(cargo_new, lock_new)', installer)
        self.assertIn('index.hash_label == "Blake3" && !index.from_cache', index)

    def test_folder_cards_present_a_and_b(self):
        ui = (ROOT / "krokiet/ui/popups/popup_folder_workspace.slint").read_text()
        self.assertIn('"A  " + row[3]', ui)
        self.assertIn('"B  " + row[7]', ui)
        self.assertIn('root.open_compare(row[3], row[7])', ui)

if __name__ == "__main__":
    unittest.main()
