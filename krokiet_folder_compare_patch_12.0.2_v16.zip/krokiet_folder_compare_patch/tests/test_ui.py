from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / "krokiet/ui/popups/popup_folder_workspace.slint"
class WorkspaceUI(unittest.TestCase):
    def test_unified_window_and_responsive_layout(self):
        t=UI.read_text()
        self.assertIn("export component PopupFolderWorkspace",t)
        self.assertIn("popup_min_height: 0px",t)
        self.assertIn("root.width < 1170px",t)
        self.assertIn('"Ordnerbeziehungen"',t)
        self.assertIn('text: "A/B-Dateien"',t)
        self.assertIn('root.open_compare(row[3], row[7])',t)
    def test_full_workflow_and_no_automatic_delete(self):
        t=UI.read_text()
        for s in ('"filter:only_a"','"filter:only_b"','"filter:conflict"','"filter:different"',
                  '"filter:same"', '"merge_selected"', '"trash_selected:"',
                  '"select_all"','"select_page"','"clear_selection"','"verify_selected"'):
            self.assertIn(s,t)
        self.assertNotIn('"remove_single_folder"',t)
        self.assertIn('"verify_conflicts"', t)
        self.assertIn('"A/B tauschen"', t)
    def test_refresh_counters_does_not_relock_session(self):
        actions=(ROOT/'krokiet/src/folder_audit_actions.rs').read_text()
        block=actions.split('fn refresh_selection(weak: &Weak<MainWindow>) {',1)[1].split('pub(super) fn connect',1)[0]
        self.assertNotIn('update_metrics(&app)',block)
        self.assertIn('let values = SESSION.lock()',block)
        self.assertIn('set_folder_audit_counts',block)
    def test_single_entry(self):
        installer=(ROOT/'apply_patch.py').read_text()
        self.assertIn('PopupFolderWorkspace',installer)
        self.assertNotIn('folder_compare_popup_window.show_popup()',installer)
        self.assertNotIn('folder_relations_popup_window.show_popup()',installer)
        self.assertIn('root.folder_compare_preview(a, b)',installer)
if __name__ == "__main__": unittest.main()
