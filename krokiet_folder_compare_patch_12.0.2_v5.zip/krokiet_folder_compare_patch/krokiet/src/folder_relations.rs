//! "Ordner-Übersicht": beantwortet pro Ordner die eine Frage "Wie viel davon liegt schon woanders?".
//!
//! Nur lesend. Nichts wird gelöscht, verschoben oder verändert. Die Ampel ist ein HINWEIS, das
//! Urteil liefert der strenge Vergleich "Compare folders".
//!
//! Prinzip
//! 1. Nach einem Duplikat-Scan (Methode Hash) wird jede Datei, die der Scan betrachtet, aufgelistet
//!    (ohne Mindestgröße). Dateien einer Duplikatgruppe haben dieselbe Inhalts-ID, alle anderen sind einmalig.
//! 2. Jeder Ordner bekommt rekursiv die Menge seiner Inhalts-IDs (mit Anzahl der Kopien).
//! 3. Eine Datei in Ordner A gilt als "gedeckt", wenn es von ihrem Inhalt mindestens eine Kopie
//!    AUSSERHALB von A gibt (egal auf welcher Platte). Das ist reine Zählerei, ohne Paarvergleiche.
//! 4. Grün: alles gedeckt. Gelb: Bytes gedeckt über der Schwelle. Unterordner werden zusammengefasst.
//! 5. Zusätzlich: wo liegen die Kopien (bis zu drei Fundstellen), was liegt nur hier, Zwillinge.

use std::cmp::Ordering;
use std::collections::{BTreeSet, HashMap};
use std::ffi::{OsStr, OsString};
use std::path::{Component, Path, PathBuf};
use std::sync::atomic::AtomicBool;
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::SystemTime;

use chrono::{Local, TimeZone, Utc};
use czkawka_core::common::model::{CheckingMethod, FileEntry};
use czkawka_core::common::tool_data::CommonData;
use czkawka_core::tools::duplicate::DuplicateFinder;
use humansize::{BINARY, format_size};
use slint::{ComponentHandle, ModelRc, SharedString, VecModel, Weak};

use crate::MainWindow;

/// Maximale Zeilenzahl in der Oberfläche.
const ROW_LIMIT: usize = 1500;
/// Fundstellen pro Ordner.
const PARTNER_COUNT: usize = 3;

/// Maximale Zeilen "nur hier" im Detail.
const ONLY_HERE_LIMIT: usize = 200;
const ALL_DISKS: &str = "Alle Platten";

// ---- PURE-BEGIN (kein Czkawka, kein Slint: wird separat extrahiert und getestet) ----

/// Inhalte mit mehr Kopien gelten für die Suche nach Fundstellen als zu häufig (Icons, Lizenztexte) und werden dort übergangen.
const COMMON_CONTENT_COPIES: u32 = 200;

pub(crate) struct InputFile {
    pub path: PathBuf,
    pub size: u64,
    pub modified: u64,
    /// Nummer der Duplikatgruppe (Dateien mit gleichem Inhalt), None für Dateien ohne Duplikat.
    pub group: Option<u32>,
}

/// Systemmüll, der nicht mitgezählt wird (wie beim strengen Vergleich).
pub(crate) fn is_junk(name: &OsStr) -> bool {
    let name = name.to_string_lossy().to_lowercase();
    name == ".ds_store" || name == "thumbs.db" || name == "desktop.ini" || name == ".localized" || name.starts_with("._")
}

/// Platte eines Pfades: /Volumes/NAME, /mnt/NAME, /media/BENUTZER/NAME, sonst "Startvolume".
pub(crate) fn disk_of(path: &Path) -> String {
    let parts: Vec<String> = path
        .components()
        .filter_map(|component| match component {
            Component::Normal(name) => Some(name.to_string_lossy().into_owned()),
            _ => None,
        })
        .collect();
    let found = match parts.first().map(String::as_str) {
        Some("Volumes" | "mnt") => parts.get(1).cloned(),
        Some("media") => parts.get(2).or_else(|| parts.get(1)).cloned(),
        _ => None,
    };
    found.unwrap_or_else(|| "Startvolume".to_owned())
}

struct FileRec {
    dir: u32,
    name: OsString,
    size: u64,
    /// Inhalts-ID, nur wenn es mindestens zwei Dateien mit diesem Inhalt gibt.
    id: Option<u32>,
}

struct Node {
    parent: Option<u32>,
    name: OsString,
    disk: u16,
    total_files: u64,
    total_bytes: u64,
    newest: u64,
    /// Rekursive Menge der geteilten Inhalts-IDs: (id, Anzahl Kopien in diesem Ordner), nach id sortiert.
    shared: Vec<(u32, u32)>,
}

pub(crate) struct DiskStat {
    pub name: String,
    pub files: u64,
    pub bytes: u64,
    /// Bytes von Dateien, deren Inhalt auch auf einer anderen Platte liegt.
    pub other_disk_bytes: u64,
    /// Bytes von Dateien mit Kopie, aber nur auf derselben Platte.
    pub same_disk_bytes: u64,
}

pub(crate) struct FolderIndex {
    nodes: Vec<Node>,
    recs: Vec<FileRec>,
    direct_files: Vec<Vec<u32>>,
    children: Vec<Vec<u32>>,
    occurrences: Vec<Vec<u32>>,
    id_size: Vec<u64>,
    id_count: Vec<u32>,
    tin: Vec<u32>,
    tout: Vec<u32>,
    pub(crate) disks: Vec<DiskStat>,
    pub(crate) hash_label: String,
    pub(crate) file_count: u64,
    pub(crate) junk_skipped: u64,
    pub(crate) skipped_small: u64,
    pub(crate) min_size: u64,
}

fn node_for(dir: &Path, nodes: &mut Vec<Node>, dirs: &mut HashMap<PathBuf, u32>) -> u32 {
    if let Some(&index) = dirs.get(dir) {
        return index;
    }
    let mut chain: Vec<&Path> = Vec::new();
    let mut current = dir;
    let mut parent_index: Option<u32> = None;
    loop {
        if let Some(&index) = dirs.get(current) {
            parent_index = Some(index);
            break;
        }
        chain.push(current);
        match current.parent() {
            Some(parent) if !parent.as_os_str().is_empty() => current = parent,
            _ => break,
        }
    }
    for directory in chain.into_iter().rev() {
        let index = nodes.len() as u32;
        let name = directory.file_name().map_or_else(|| directory.as_os_str().to_os_string(), OsStr::to_os_string);
        nodes.push(Node {
            parent: parent_index,
            name,
            disk: 0,
            total_files: 0,
            total_bytes: 0,
            newest: 0,
            shared: Vec::new(),
        });
        dirs.insert(directory.to_path_buf(), index);
        parent_index = Some(index);
    }
    parent_index.unwrap_or(0)
}

fn path_of(nodes: &[Node], n: u32) -> PathBuf {
    let mut names: Vec<&OsString> = Vec::new();
    let mut current = Some(n);
    while let Some(index) = current {
        let node = &nodes[index as usize];
        names.push(&node.name);
        current = node.parent;
    }
    let mut path = PathBuf::new();
    for name in names.into_iter().rev() {
        path.push(name);
    }
    path
}

pub(crate) fn build_index(files: Vec<InputFile>, hash_label: String, min_size: u64) -> FolderIndex {
    let before = files.len();
    let files: Vec<InputFile> = files.into_iter().filter(|f| !f.path.file_name().is_some_and(is_junk)).collect();
    let junk_skipped = (before - files.len()) as u64;
    let skipped_small = files.iter().filter(|f| f.group.is_none() && f.size > 0 && f.size < min_size).count() as u64;

    // Rohe Inhalts-IDs: Duplikatgruppe g -> g + 1, leere Dateien -> 0, alles andere hat keine ID.
    let max_group = files.iter().filter_map(|f| f.group).max().map_or(0, |g| g as usize + 1);
    let id_space = max_group + 1;
    let raw_id = |f: &InputFile| -> Option<u32> {
        match f.group {
            Some(g) => Some(g + 1),
            None if f.size == 0 => Some(0),
            None => None,
        }
    };
    let mut id_count = vec![0u32; id_space];
    let mut id_size = vec![0u64; id_space];
    for file in &files {
        if let Some(id) = raw_id(file) {
            id_count[id as usize] += 1;
            id_size[id as usize] = file.size;
        }
    }

    let mut nodes: Vec<Node> = Vec::new();
    let mut dirs: HashMap<PathBuf, u32> = HashMap::new();
    let mut direct_ids: Vec<Vec<u32>> = Vec::new();
    let mut direct_files: Vec<Vec<u32>> = Vec::new();
    let mut recs: Vec<FileRec> = Vec::with_capacity(files.len());
    let file_count = files.len() as u64;
    for file in &files {
        let dir = file.path.parent().unwrap_or_else(|| Path::new("/"));
        let index = node_for(dir, &mut nodes, &mut dirs) as usize;
        while direct_ids.len() < nodes.len() {
            direct_ids.push(Vec::new());
            direct_files.push(Vec::new());
        }
        let shared_id = raw_id(file).filter(|&id| id_count[id as usize] >= 2);
        let rec = recs.len() as u32;
        recs.push(FileRec {
            dir: index as u32,
            name: file.path.file_name().map(OsStr::to_os_string).unwrap_or_default(),
            size: file.size,
            id: shared_id,
        });
        direct_files[index].push(rec);
        if let Some(id) = shared_id {
            direct_ids[index].push(id);
        }
        let node = &mut nodes[index];
        node.total_files += 1;
        node.total_bytes += file.size;
        node.newest = node.newest.max(file.modified);
    }
    drop(dirs);
    drop(files);

    // Von unten nach oben aufsummieren. Kinder haben immer einen größeren Index als ihr Elternknoten.
    let count = nodes.len();
    let mut acc: Vec<Vec<(u32, u32)>> = vec![Vec::new(); count];
    for n in (0..count).rev() {
        let mut list = std::mem::take(&mut acc[n]);
        list.extend(direct_ids[n].iter().map(|&id| (id, 1)));
        list.sort_unstable_by_key(|entry| entry.0);
        let mut merged: Vec<(u32, u32)> = Vec::with_capacity(list.len());
        for (id, copies) in list {
            match merged.last_mut() {
                Some(last) if last.0 == id => last.1 += copies,
                _ => merged.push((id, copies)),
            }
        }
        merged.shrink_to_fit();
        if let Some(parent) = nodes[n].parent {
            let parent = parent as usize;
            acc[parent].extend(merged.iter().copied());
            let (files_n, bytes_n, newest_n) = (nodes[n].total_files, nodes[n].total_bytes, nodes[n].newest);
            nodes[parent].total_files += files_n;
            nodes[parent].total_bytes += bytes_n;
            nodes[parent].newest = nodes[parent].newest.max(newest_n);
        }
        nodes[n].shared = merged;
    }
    drop(direct_ids);

    // Euler-Tour für schnelle "liegt darin"-Tests.
    let mut children: Vec<Vec<u32>> = vec![Vec::new(); count];
    let mut roots: Vec<u32> = Vec::new();
    for (index, node) in nodes.iter().enumerate() {
        match node.parent {
            Some(parent) => children[parent as usize].push(index as u32),
            None => roots.push(index as u32),
        }
    }
    let mut tin = vec![0u32; count];
    let mut tout = vec![0u32; count];
    let mut clock = 0u32;
    let mut stack: Vec<(u32, usize)> = Vec::new();
    for root in roots {
        tin[root as usize] = clock;
        clock += 1;
        stack.push((root, 0));
        while let Some((node, position)) = stack.last().copied() {
            if let Some(&child) = children[node as usize].get(position) {
                if let Some(top) = stack.last_mut() {
                    top.1 += 1;
                }
                tin[child as usize] = clock;
                clock += 1;
                stack.push((child, 0));
            } else {
                tout[node as usize] = clock;
                stack.pop();
            }
        }
    }

    // Platten (höchstens 63, der Rest wird zusammengefasst).
    let node_disk_names: Vec<String> = (0..count).map(|n| disk_of(&path_of(&nodes, n as u32))).collect();
    let mut names: Vec<String> = node_disk_names.iter().cloned().collect::<BTreeSet<_>>().into_iter().collect();
    if names.len() > 63 {
        names.truncate(62);
        names.push("Weitere Platten".to_owned());
    }
    let last = names.len().saturating_sub(1) as u16;
    {
        let lookup: HashMap<&str, u16> = names.iter().enumerate().map(|(i, name)| (name.as_str(), i as u16)).collect();
        for (n, node) in nodes.iter_mut().enumerate() {
            node.disk = lookup.get(node_disk_names[n].as_str()).copied().unwrap_or(last);
        }
    }
    let mut id_disks = vec![0u64; id_space];
    for rec in &recs {
        if let Some(id) = rec.id {
            id_disks[id as usize] |= 1u64 << nodes[rec.dir as usize].disk;
        }
    }
    let mut disks: Vec<DiskStat> = names
        .iter()
        .map(|name| DiskStat {
            name: name.clone(),
            files: 0,
            bytes: 0,
            other_disk_bytes: 0,
            same_disk_bytes: 0,
        })
        .collect();
    for rec in &recs {
        let disk = nodes[rec.dir as usize].disk as usize;
        disks[disk].files += 1;
        disks[disk].bytes += rec.size;
        if let Some(id) = rec.id {
            if id_disks[id as usize] & !(1u64 << disk) != 0 {
                disks[disk].other_disk_bytes += rec.size;
            } else {
                disks[disk].same_disk_bytes += rec.size;
            }
        }
    }

    let mut occurrences: Vec<Vec<u32>> = vec![Vec::new(); id_space];
    for (n, node) in nodes.iter().enumerate() {
        for &(id, _) in &node.shared {
            occurrences[id as usize].push(n as u32);
        }
    }

    FolderIndex {
        nodes,
        recs,
        direct_files,
        children,
        occurrences,
        id_size,
        id_count,
        tin,
        tout,
        disks,
        hash_label,
        file_count,
        junk_skipped,
        skipped_small,
        min_size,
    }
}

#[derive(Debug, Clone)]
pub(crate) struct Partner {
    pub node: u32,
    /// Bytes von A, die (zusätzlich zu den vorherigen Fundstellen) in diesem Ordner nochmal vorliegen.
    pub bytes: u64,
    pub files: u64,
}

#[derive(Debug, Clone)]
pub(crate) struct Row {
    pub a: u32,
    /// 2 = grün (alles gedeckt), 1 = gelb (über der Schwelle).
    pub class: u8,
    pub covered_files: u64,
    pub total_files: u64,
    pub covered_bytes: u64,
    pub total_bytes: u64,
    /// Anzahl gleichartiger Zwillingsordner inklusive diesem (0 = kein Zwilling).
    pub twins: u32,
    pub partners: Vec<Partner>,
    /// Bytes, deren Kopien in keiner der genannten Fundstellen liegen (weitere oder übergeordnete Ordner).
    pub rest_bytes: u64,
}

pub(crate) struct Params {
    pub min_files: u64,
    pub threshold_permille: u32,
    pub summarize: bool,
    pub disk: Option<u16>,
}

impl FolderIndex {
    pub(crate) fn node_path(&self, n: u32) -> PathBuf {
        path_of(&self.nodes, n)
    }

    pub(crate) fn node_disk_name(&self, n: u32) -> &str {
        &self.disks[self.nodes[n as usize].disk as usize].name
    }

    pub(crate) fn node_newest(&self, n: u32) -> u64 {
        self.nodes[n as usize].newest
    }

    /// Ist `b` ein echter Unterordner von `a`?
    fn inside(&self, b: u32, a: u32) -> bool {
        let (a, b) = (a as usize, b as usize);
        self.tin[a] < self.tin[b] && self.tin[b] < self.tout[a]
    }

    fn depth(&self, n: u32) -> usize {
        let mut depth = 0;
        let mut current = self.nodes[n as usize].parent;
        while let Some(index) = current {
            depth += 1;
            current = self.nodes[index as usize].parent;
        }
        depth
    }

    fn copies_in(&self, n: u32, id: u32) -> u32 {
        let shared = &self.nodes[n as usize].shared;
        shared.binary_search_by_key(&id, |entry| entry.0).map_or(0, |position| shared[position].1)
    }

    /// (gedeckte Dateien, gedeckte Bytes) von Ordner a: Inhalt hat mindestens eine Kopie außerhalb von a.
    fn coverage(&self, a: u32) -> (u64, u64) {
        let (mut files, mut bytes) = (0u64, 0u64);
        for &(id, copies) in &self.nodes[a as usize].shared {
            if self.id_count[id as usize] > copies {
                files += u64::from(copies);
                bytes += u64::from(copies) * self.id_size[id as usize];
            }
        }
        (files, bytes)
    }

    /// Liegt von Inhalt `id` eine Kopie in Ordner b? Ordner, die a enthalten oder in a liegen, zählen nicht
    /// (ein Oberordner enthält ja a selbst und wäre als Fundstelle nutzlos).
    fn outside_copy_in(&self, b: u32, a: u32, id: u32) -> bool {
        b != a && !self.inside(b, a) && !self.inside(a, b) && self.copies_in(b, id) > 0
    }

    fn cmp_partner(&self, x: (u32, (u64, u64)), y: (u32, (u64, u64))) -> Ordering {
        x.1.0
            .cmp(&y.1.0)
            .then(x.1.1.cmp(&y.1.1))
            .then(self.nodes[y.0 as usize].total_files.cmp(&self.nodes[x.0 as usize].total_files))
            .then_with(|| self.depth(x.0).cmp(&self.depth(y.0)))
            .then_with(|| self.node_path(y.0).cmp(&self.node_path(x.0)))
    }

    /// Fundstellen der Kopien von a: gierig, bis zu `max` Ordner. Große Ordner (mehr als das 20fache der
    /// erklärten Bytes) werden zuerst übergangen, damit nicht die ganze Platte als "Fundstelle" erscheint.
    pub(crate) fn partners(&self, a: u32, max: usize) -> (Vec<Partner>, u64) {
        let mut remaining: Vec<(u32, u32)> = self.nodes[a as usize]
            .shared
            .iter()
            .copied()
            .filter(|&(id, copies)| self.id_count[id as usize] > copies && self.id_size[id as usize] > 0 && self.id_count[id as usize] <= COMMON_CONTENT_COPIES)
            .collect();
        let mut result: Vec<Partner> = Vec::new();
        while result.len() < max && !remaining.is_empty() {
            let mut score: HashMap<u32, (u64, u64)> = HashMap::new();
            for &(id, copies) in &remaining {
                let size = self.id_size[id as usize];
                for &b in &self.occurrences[id as usize] {
                    if self.outside_copy_in(b, a, id) {
                        let entry = score.entry(b).or_insert((0, 0));
                        entry.0 += u64::from(copies) * size;
                        entry.1 += u64::from(copies);
                    }
                }
            }
            let pick = |constrained: bool| {
                score
                    .iter()
                    .filter(|&(&b, &(bytes, _))| !constrained || self.nodes[b as usize].total_bytes <= bytes.saturating_mul(20))
                    .map(|(&b, &value)| (b, value))
                    .max_by(|x, y| self.cmp_partner(*x, *y))
            };
            let Some((b, (bytes, files))) = pick(true).or_else(|| pick(false)) else { break };
            result.push(Partner { node: b, bytes, files });
            remaining.retain(|&(id, _)| !self.outside_copy_in(b, a, id));
        }
        let rest = remaining.iter().map(|&(id, copies)| u64::from(copies) * self.id_size[id as usize]).sum();
        (result, rest)
    }

    /// Dateien in a, deren Inhalt nirgends außerhalb von a vorkommt: (Pfad relativ zu a, Größe), größte zuerst.
    pub(crate) fn only_here(&self, a: u32) -> Vec<(PathBuf, u64)> {
        let mut result: Vec<(PathBuf, u64)> = Vec::new();
        let mut stack: Vec<(u32, PathBuf)> = vec![(a, PathBuf::new())];
        while let Some((n, relative)) = stack.pop() {
            for &rec_index in &self.direct_files[n as usize] {
                let rec = &self.recs[rec_index as usize];
                let covered = rec.id.is_some_and(|id| self.id_count[id as usize] > self.copies_in(a, id));
                if !covered {
                    result.push((relative.join(&rec.name), rec.size));
                }
            }
            for &child in &self.children[n as usize] {
                stack.push((child, relative.join(&self.nodes[child as usize].name)));
            }
        }
        result.sort_by(|x, y| y.1.cmp(&x.1).then_with(|| x.0.cmp(&y.0)));
        result
    }
}

pub(crate) fn analyze(index: &FolderIndex, params: &Params) -> Vec<Row> {
    let mut all: Vec<Row> = Vec::new();
    for a in 0..index.nodes.len() as u32 {
        let node = &index.nodes[a as usize];
        if node.total_files < params.min_files || node.total_bytes == 0 {
            continue;
        }
        let (covered_files, covered_bytes) = index.coverage(a);
        let class = if covered_files == node.total_files {
            2
        } else if covered_bytes > 0 && u128::from(covered_bytes) * 1000 >= u128::from(params.threshold_permille) * u128::from(node.total_bytes) {
            1
        } else {
            continue;
        };
        all.push(Row {
            a,
            class,
            covered_files,
            total_files: node.total_files,
            covered_bytes,
            total_bytes: node.total_bytes,
            twins: 0,
            partners: Vec::new(),
            rest_bytes: 0,
        });
    }

    let class_of: HashMap<u32, u8> = all.iter().map(|row| (row.a, row.class)).collect();
    let mut rows: Vec<Row> = if params.summarize {
        all.into_iter()
            .filter(|row| {
                // Ausblenden, wenn ein übergeordneter Ordner schon mindestens genauso stark gemeldet ist.
                let mut parent = index.nodes[row.a as usize].parent;
                while let Some(p) = parent {
                    if class_of.get(&p).is_some_and(|class| *class >= row.class) {
                        return false;
                    }
                    parent = index.nodes[p as usize].parent;
                }
                true
            })
            .collect()
    } else {
        all
    };

    // Zwillinge: grüne Ordner mit exakt gleicher Inhaltsmenge. Ineinander verschachtelte zählen nicht doppelt.
    let mut groups: HashMap<(&[(u32, u32)], u64), Vec<usize>> = HashMap::new();
    for (position, row) in rows.iter().enumerate() {
        if row.class == 2 {
            groups.entry((index.nodes[row.a as usize].shared.as_slice(), row.total_files)).or_default().push(position);
        }
    }
    let mut twin_updates: Vec<(usize, u32)> = Vec::new();
    for members in groups.values() {
        let tops: Vec<usize> = members
            .iter()
            .copied()
            .filter(|&m| !members.iter().any(|&other| other != m && index.inside(rows[m].a, rows[other].a)))
            .collect();
        if tops.len() >= 2 {
            for &position in &tops {
                twin_updates.push((position, tops.len() as u32));
            }
        }
    }
    for (position, size) in twin_updates {
        rows[position].twins = size;
    }

    if let Some(disk) = params.disk {
        rows.retain(|row| index.nodes[row.a as usize].disk == disk);
    }
    rows.sort_by(|x, y| {
        y.class
            .cmp(&x.class)
            .then(y.total_bytes.cmp(&x.total_bytes))
            .then_with(|| index.node_path(x.a).cmp(&index.node_path(y.a)))
    });
    rows
}

pub(crate) fn fill_partners(index: &FolderIndex, rows: &mut [Row], max: usize) {
    for row in rows {
        let (partners, rest) = index.partners(row.a, max);
        row.partners = partners;
        row.rest_bytes = rest;
    }
}

// ---- PURE-END ----

fn permille(part: u64, total: u64) -> String {
    if total == 0 {
        return "-".to_owned();
    }
    // Abgerundet, damit 99,96 % nie als 100,0 % erscheint.
    let value = (u128::from(part) * 1000 / u128::from(total)) as f64 / 10.0;
    format!("{value:.1} %")
}

fn day(seconds: u64) -> String {
    if seconds == 0 {
        return "?".to_owned();
    }
    Utc.timestamp_opt(seconds as i64, 0).single().unwrap_or_default().with_timezone(&Local).format("%Y-%m-%d").to_string()
}

fn short_path(path: &Path) -> String {
    let names: Vec<String> = path
        .components()
        .filter_map(|c| match c {
            Component::Normal(name) => Some(name.to_string_lossy().into_owned()),
            _ => None,
        })
        .collect();
    let start = names.len().saturating_sub(2);
    names[start..].join("/")
}

fn size_text(files: u64, bytes: u64) -> String {
    format!("{} ({files} Dateien)", format_size(bytes, BINARY))
}

fn to_rows(index: &FolderIndex, rows: &[Row]) -> Vec<Vec<String>> {
    rows.iter()
        .take(ROW_LIMIT)
        .map(|row| {
            let first_partner = row.partners.first();
            let partner_text = if row.partners.is_empty() {
                "Fundstelle nicht bestimmbar".to_owned()
            } else {
                let parts: Vec<String> = row.partners.iter().map(|p| format!("{} {}", short_path(&index.node_path(p.node)), permille(p.bytes, row.total_bytes))).collect();
                let more = if row.rest_bytes > 0 { format!(", weitere {}", permille(row.rest_bytes, row.total_bytes)) } else { String::new() };
                format!("auch in: {}{more}", parts.join(", "))
            };
            let a_newest = index.node_newest(row.a);
            let dates = match first_partner {
                Some(p) => {
                    let b_newest = index.node_newest(p.node);
                    let hint = match a_newest.cmp(&b_newest) {
                        Ordering::Less => "  (Fundstelle ist neuer)",
                        Ordering::Greater => "  (dieser Ordner ist neuer)",
                        Ordering::Equal => "",
                    };
                    format!("neueste Datei: hier {}, Fundstelle {}{hint}", day(a_newest), day(b_newest))
                }
                None => format!("neueste Datei: hier {}", day(a_newest)),
            };
            let twin = if row.twins >= 2 { format!("ZWILLING: {} Ordner mit gleichem Inhalt, einer muss bleiben", row.twins) } else { String::new() };
            vec![
                row.class.to_string(),
                row.a.to_string(),
                index.node_disk_name(row.a).to_owned(),
                index.node_path(row.a).display().to_string(),
                size_text(row.total_files, row.total_bytes),
                format!("{} der Bytes, {} von {} Dateien", permille(row.covered_bytes, row.total_bytes), row.covered_files, row.total_files),
                partner_text,
                first_partner.map(|p| index.node_path(p.node).display().to_string()).unwrap_or_default(),
                dates,
                twin,
            ]
        })
        .collect()
}

fn to_model(rows: Vec<Vec<String>>) -> ModelRc<ModelRc<SharedString>> {
    let rows: Vec<ModelRc<SharedString>> = rows.into_iter().map(|row| ModelRc::new(VecModel::from(row.into_iter().map(SharedString::from).collect::<Vec<_>>()))).collect();
    ModelRc::new(VecModel::from(rows))
}

fn disk_summary(index: &FolderIndex) -> String {
    let mut lines: Vec<String> = index
        .disks
        .iter()
        .filter(|d| d.files > 0)
        .map(|d| {
            format!(
                "{}: {} in {} Dateien. Inhalt auch auf anderer Platte: {} ({}). Kopie nur auf derselben Platte: {}.",
                d.name,
                format_size(d.bytes, BINARY),
                d.files,
                format_size(d.other_disk_bytes, BINARY),
                permille(d.other_disk_bytes, d.bytes),
                format_size(d.same_disk_bytes, BINARY)
            )
        })
        .collect();
    if lines.is_empty() {
        lines.push("Keine Dateien im Scan.".to_owned());
    }
    lines.join("\n")
}

fn warnings(index: &FolderIndex) -> String {
    let mut text = String::new();
    if index.hash_label != "Blake3" {
        text.push_str(&format!(" ACHTUNG: Hash {} ist nicht Blake3. Für Löschentscheidungen Blake3 verwenden.", index.hash_label));
    }
    if index.skipped_small > 0 {
        text.push_str(&format!(
            " ACHTUNG: {} Dateien unter {} Bytes hat der Scan nicht verglichen. Sie zählen als \"nur hier\". Für genaue Werte im Scan die Mindestgröße auf 0 setzen.",
            index.skipped_small, index.min_size
        ));
    }
    if index.junk_skipped > 0 {
        text.push_str(&format!(" Systemdateien (.DS_Store, ._*, Thumbs.db, desktop.ini, .localized) ignoriert: {}.", index.junk_skipped));
    }
    text
}

fn summary(index: &FolderIndex, rows: &[Row], seconds: f32) -> String {
    let green = rows.iter().filter(|r| r.class == 2).count();
    let yellow = rows.len() - green;
    format!(
        "{} Ordner in der Liste (grün {green}, gelb {yellow}), {} Dateien ausgewertet, Hash {}, {seconds:.1} s.{} Nur Hinweise: Löschen erst nach dem strengen Vergleich.",
        rows.len(),
        index.file_count,
        index.hash_label,
        warnings(index)
    )
}

fn detail_text(index: &FolderIndex, row: &Row) -> String {
    let path = index.node_path(row.a);
    let mut text = format!(
        "{}\nPlatte: {}\nGröße: {}, neueste Datei {}\nAnderswo vorhanden: {} der Bytes, {} von {} Dateien\n",
        path.display(),
        index.node_disk_name(row.a),
        size_text(row.total_files, row.total_bytes),
        day(index.node_newest(row.a)),
        permille(row.covered_bytes, row.total_bytes),
        row.covered_files,
        row.total_files
    );
    if row.twins >= 2 {
        text.push_str(&format!("ZWILLING: {} Ordner haben genau denselben Inhalt. Löschst du alle, ist der Inhalt weg.\n", row.twins));
    }
    text.push_str("\nWo die Kopien liegen (Anteil der Bytes dieses Ordners):\n");
    if row.partners.is_empty() {
        text.push_str("  keine Fundstelle bestimmbar\n");
    }
    for p in &row.partners {
        text.push_str(&format!(
            "  {}  {}  ({} Dateien, Platte {}, neueste Datei {})\n",
            permille(p.bytes, row.total_bytes),
            index.node_path(p.node).display(),
            p.files,
            index.node_disk_name(p.node),
            day(index.node_newest(p.node))
        ));
    }
    if row.rest_bytes > 0 {
        text.push_str(&format!("  {}  weitere Fundstellen (übergeordnete oder zusätzliche Ordner)\n", permille(row.rest_bytes, row.total_bytes)));
    }
    let only = index.only_here(row.a);
    let only_bytes: u64 = only.iter().map(|(_, size)| *size).sum();
    if only.is_empty() {
        text.push_str("\nNur hier: nichts. Jede Datei hat außerhalb dieses Ordners eine Kopie.\n");
    } else {
        text.push_str(&format!("\nNur hier ({} Dateien, {}), diese Dateien gäbe es nach dem Löschen nirgends mehr:\n", only.len(), format_size(only_bytes, BINARY)));
        for (relative, size) in only.iter().take(ONLY_HERE_LIMIT) {
            text.push_str(&format!("  {}  {}\n", format_size(*size, BINARY), relative.display()));
        }
        if only.len() > ONLY_HERE_LIMIT {
            text.push_str(&format!("  ... und {} weitere\n", only.len() - ONLY_HERE_LIMIT));
        }
    }
    text
}

struct View {
    index: Arc<FolderIndex>,
    rows: Vec<Row>,
}

static INDEX: Mutex<Option<Arc<FolderIndex>>> = Mutex::new(None);
static VIEW: Mutex<Option<Arc<View>>> = Mutex::new(None);

fn store_state(index: Option<Arc<FolderIndex>>, view: Option<Arc<View>>) {
    if let Ok(mut guard) = INDEX.lock() {
        *guard = index;
    }
    if let Ok(mut guard) = VIEW.lock() {
        *guard = view;
    }
}

fn default_params() -> Params {
    Params {
        min_files: 1,
        threshold_permille: 900,
        summarize: true,
        disk: None,
    }
}

fn run_analysis(index: &Arc<FolderIndex>, params: &Params) -> (Arc<View>, String) {
    let started = SystemTime::now();
    let mut rows = analyze(index, params);
    rows.truncate(ROW_LIMIT);
    fill_partners(index, &mut rows, PARTNER_COUNT);
    let seconds = started.elapsed().map_or(0.0, |d| d.as_secs_f32());
    let text = summary(index, &rows, seconds);
    (Arc::new(View { index: Arc::clone(index), rows }), text)
}

fn publish_view(weak: &Weak<MainWindow>, view: &Arc<View>, status: String, reset_disks: bool) {
    let rows = to_rows(&view.index, &view.rows);
    let summary_text = disk_summary(&view.index);
    let mut disk_names: Vec<String> = vec![ALL_DISKS.to_owned()];
    disk_names.extend(view.index.disks.iter().filter(|d| d.files > 0).map(|d| d.name.clone()));
    let _ = weak.upgrade_in_event_loop(move |app| {
        app.set_folder_relations_rows(to_model(rows));
        app.set_folder_relations_status(status.into());
        app.set_folder_relations_disk_summary(summary_text.into());
        app.set_folder_relations_detail("Wähle eine Zeile, um Details zu sehen.".into());
        if reset_disks {
            app.set_folder_relations_disks(ModelRc::new(VecModel::from(disk_names.into_iter().map(SharedString::from).collect::<Vec<_>>())));
        }
        app.set_folder_relations_available(true);
        app.set_folder_relations_busy(false);
    });
}

fn publish_message(weak: &Weak<MainWindow>, available: bool, status: String) {
    let _ = weak.upgrade_in_event_loop(move |app| {
        app.set_folder_relations_available(available);
        app.set_folder_relations_status(status.into());
        app.set_folder_relations_busy(false);
        if !available {
            app.set_folder_relations_rows(to_model(Vec::new()));
            app.set_folder_relations_disk_summary(SharedString::new());
            app.set_folder_relations_detail(SharedString::new());
        }
    });
}

/// Alles aus einem fertigen Duplikat-Scan. Wird erstellt, BEVOR der Finder in Krokiets gemeinsamen Zustand wandert.
pub(crate) struct ScanSnapshot {
    group_of: HashMap<PathBuf, u32>,
    hash_label: String,
    min_size: u64,
    inventory_job: Box<dyn FnOnce() -> Option<Vec<FileEntry>>>,
}

pub(crate) fn prepare(tool: &DuplicateFinder, stop_flag: &Arc<AtomicBool>) -> Result<ScanSnapshot, String> {
    if tool.get_stopped_search() {
        return Err("Der Scan wurde abgebrochen: keine Ordner-Übersicht.".to_owned());
    }
    let params = tool.get_params();
    if !matches!(params.check_method, CheckingMethod::Hash) {
        return Err("Die Ordner-Übersicht braucht im Duplikat-Scan die Prüfmethode \"Hash\".".to_owned());
    }
    if tool.get_use_reference() {
        return Err("Die Ordner-Übersicht unterstützt keine Referenzordner.".to_owned());
    }
    let mut group_of: HashMap<PathBuf, u32> = HashMap::new();
    for (group_number, group) in tool.get_files_sorted_by_hash().values().flatten().enumerate() {
        for entry in group {
            group_of.insert(entry.path.clone(), group_number as u32);
        }
    }
    Ok(ScanSnapshot {
        group_of,
        hash_label: format!("{:?}", params.hash_type),
        min_size: tool.get_minimal_file_size_for_addon(),
        inventory_job: tool.prepare_full_inventory(stop_flag),
    })
}

/// Läuft im Scan-Thread, nachdem die normalen Ergebnisse an die Oberfläche übergeben wurden.
pub(crate) fn publish(weak: Weak<MainWindow>, snapshot: Result<ScanSnapshot, String>) {
    let snapshot = match snapshot {
        Ok(snapshot) => snapshot,
        Err(reason) => {
            store_state(None, None);
            publish_message(&weak, false, reason);
            return;
        }
    };
    let ScanSnapshot { group_of, hash_label, min_size, inventory_job } = snapshot;
    let _ = weak.upgrade_in_event_loop(|app| {
        app.set_folder_relations_available(false);
        app.set_folder_relations_status("Ordner-Übersicht: Ordnerstruktur wird gelesen ...".into());
    });
    let Some(files) = inventory_job() else {
        store_state(None, None);
        publish_message(&weak, false, "Ordner-Übersicht: beim Lesen der Ordnerstruktur abgebrochen.".to_owned());
        return;
    };
    let input: Vec<InputFile> = files
        .into_iter()
        .map(|file| {
            let group = group_of.get(&file.path).copied();
            InputFile {
                path: file.path,
                size: file.size,
                modified: file.modified_date,
                group,
            }
        })
        .collect();
    drop(group_of);
    let index = Arc::new(build_index(input, hash_label, min_size));
    let (view, status) = run_analysis(&index, &default_params());
    store_state(Some(Arc::clone(&index)), Some(Arc::clone(&view)));
    publish_view(&weak, &view, status, true);
}

pub(crate) fn connect_folder_relations(app: &MainWindow) {
    let weak = app.as_weak();
    app.on_folder_relations_analyze(move |threshold_percent, min_files, summarize, disk| {
        let Some(app) = weak.upgrade() else { return };
        if app.get_folder_relations_busy() {
            return;
        }
        let index = INDEX.lock().ok().and_then(|guard| guard.clone());
        let Some(index) = index else {
            app.set_folder_relations_status("Noch keine Scandaten: zuerst einen Duplikat-Scan mit Prüfmethode \"Hash\" ausführen.".into());
            return;
        };
        app.set_folder_relations_busy(true);
        let disk_name = disk.to_string();
        let weak = app.as_weak();
        thread::spawn(move || {
            let disk_filter = if disk_name == ALL_DISKS || disk_name.is_empty() {
                None
            } else {
                index.disks.iter().position(|d| d.name == disk_name).map(|position| position as u16)
            };
            let params = Params {
                min_files: u64::try_from(min_files.max(1)).unwrap_or(1),
                threshold_permille: u32::try_from(threshold_percent.clamp(50, 100)).unwrap_or(90) * 10,
                summarize,
                disk: disk_filter,
            };
            let (view, status) = run_analysis(&index, &params);
            if let Ok(mut guard) = VIEW.lock() {
                *guard = Some(Arc::clone(&view));
            }
            publish_view(&weak, &view, status, false);
        });
    });

    let weak = app.as_weak();
    app.on_folder_relations_select(move |position| {
        let view = VIEW.lock().ok().and_then(|guard| guard.clone());
        let Some(view) = view else { return };
        let Ok(position) = usize::try_from(position) else { return };
        let weak = weak.clone();
        thread::spawn(move || {
            let text = view.rows.get(position).map_or_else(String::new, |row| detail_text(&view.index, row));
            let _ = weak.upgrade_in_event_loop(move |app| app.set_folder_relations_detail(text.into()));
        });
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    fn file(path: &str, size: u64, group: Option<u32>) -> InputFile {
        InputFile { path: PathBuf::from(path), size, modified: 1, group }
    }

    fn params(threshold_permille: u32) -> Params {
        Params { min_files: 1, threshold_permille, summarize: false, disk: None }
    }

    fn find<'a>(index: &FolderIndex, rows: &'a [Row], suffix: &str) -> Option<&'a Row> {
        rows.iter().find(|r| index.node_path(r.a).ends_with(suffix))
    }

    /// 2025: 10 Dateien. 2026: dieselben 10 (andere Namen) plus 5 neue.
    fn scenario() -> Vec<InputFile> {
        let mut files = Vec::new();
        for i in 0..10u32 {
            files.push(file(&format!("/Volumes/P1/2025/allefotos/a{i}.jpg"), 100 + u64::from(i), Some(i)));
            files.push(file(&format!("/Volumes/P2/2026/neu/b{i}.jpg"), 100 + u64::from(i), Some(i)));
        }
        for i in 0..5u64 {
            files.push(file(&format!("/Volumes/P2/2026/neu/extra{i}.jpg"), 500 + i, None));
        }
        files
    }

    #[test]
    fn contained_folder_is_green_with_partner() {
        let index = build_index(scenario(), "Blake3".to_owned(), 0);
        let mut rows = analyze(&index, &params(900));
        fill_partners(&index, &mut rows, 3);
        let row = find(&index, &rows, "allefotos").expect("allefotos muss gemeldet werden");
        assert_eq!(row.class, 2);
        assert_eq!((row.covered_files, row.total_files), (10, 10));
        assert!(index.node_path(row.partners[0].node).ends_with("neu"));
        // Der größere Ordner ist NICHT grün: seine 5 neuen Dateien gibt es nur dort.
        assert!(find(&index, &rows, "neu").is_none() || find(&index, &rows, "neu").is_some_and(|r| r.class == 1));
    }

    #[test]
    fn partial_is_yellow_and_lists_only_here() {
        let mut files = scenario();
        files.push(file("/Volumes/P1/2025/allefotos/nur_hier.jpg", 5, None));
        let index = build_index(files, "Blake3".to_owned(), 0);
        assert!(find(&index, &analyze(&index, &params(1000)), "allefotos").is_none());
        let rows = analyze(&index, &params(900));
        let row = find(&index, &rows, "allefotos").expect("90 % reichen für gelb");
        assert_eq!(row.class, 1);
            let only = index.only_here(row.a);
        assert_eq!(only.len(), 1);
        assert!(only[0].0.ends_with("nur_hier.jpg"));
    }

    #[test]
    fn coverage_split_over_two_folders() {
        let mut files = Vec::new();
        for i in 0..6u32 {
            files.push(file(&format!("/Volumes/P1/a/f{i}"), 50 + u64::from(i), Some(i)));
        }
        for i in 0..3u32 {
            files.push(file(&format!("/Volumes/P2/b/f{i}"), 50 + u64::from(i), Some(i)));
        }
        for i in 3..6u32 {
            files.push(file(&format!("/Volumes/P3/c/f{i}"), 50 + u64::from(i), Some(i)));
        }
        let index = build_index(files, "Blake3".to_owned(), 0);
        let mut rows = analyze(&index, &params(900));
        fill_partners(&index, &mut rows, 3);
        let row = find(&index, &rows, "a").expect("a ist über b und c komplett gedeckt");
        assert_eq!(row.class, 2);
        assert_eq!(row.partners.len(), 2);
    }

    #[test]
    fn twins_are_marked() {
        let mut files = Vec::new();
        for i in 0..4u32 {
            files.push(file(&format!("/Volumes/P1/one/f{i}"), 10 + u64::from(i), Some(i)));
            files.push(file(&format!("/Volumes/P2/two/g{i}"), 10 + u64::from(i), Some(i)));
        }
        let index = build_index(files, "Blake3".to_owned(), 0);
        let rows = analyze(&index, &params(900));
        assert_eq!(rows.iter().filter(|r| r.twins == 2).count(), 2);
    }

    #[test]
    fn junk_files_are_ignored() {
        let mut files = Vec::new();
        for i in 0..3u32 {
            files.push(file(&format!("/Volumes/P1/x/f{i}"), 10 + u64::from(i), Some(i)));
            files.push(file(&format!("/Volumes/P2/y/f{i}"), 10 + u64::from(i), Some(i)));
        }
        files.push(file("/Volumes/P1/x/.DS_Store", 6148, None));
        let index = build_index(files, "Blake3".to_owned(), 0);
        assert_eq!(index.junk_skipped, 1);
        assert!(find(&index, &analyze(&index, &params(900)), "x").is_some_and(|r| r.class == 2));
    }

    #[test]
    fn disks_are_recognized() {
        assert_eq!(disk_of(Path::new("/Volumes/Foto Platte/a/b")), "Foto Platte");
        assert_eq!(disk_of(Path::new("/Users/me/x")), "Startvolume");
        assert_eq!(disk_of(Path::new("/media/me/USB/x")), "USB");
        assert_eq!(disk_of(Path::new("/")), "Startvolume");
    }

    #[test]
    fn unrelated_folders_report_nothing() {
        let files = vec![file("/Volumes/P1/a/f1", 5, None), file("/Volumes/P1/a/f2", 6, None), file("/Volumes/P1/b/f3", 7, None)];
        let index = build_index(files, "Blake3".to_owned(), 0);
        assert!(analyze(&index, &params(500)).is_empty());
    }
}
