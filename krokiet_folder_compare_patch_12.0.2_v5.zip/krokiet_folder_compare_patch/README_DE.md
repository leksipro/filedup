# Krokiet 12.0.2: Folder Compare und Folder Relationships (Quellcode-Erweiterung), Version 5

**Status: Quellcode, nicht auf macOS kompiliert.** Die Vergleichslogik ist in einem zweiten, unabhängigen Verfahren nachgebaut und gegeneinander getestet (siehe „Validierung“). Die Einbindung in Krokiet (Rust-Typen, Slint-Oberfläche, echter Czkawka-Scanner) konnte nur durch Lesen des Originalquellcodes 12.0.2 geprüft werden. **Der erste Schritt bei dir ist `cargo test`.**

Die Erweiterung fügt Krokiet eine Schaltfläche „Compare folders“ hinzu. Der Vergleich ist **nur lesend**. Er löscht, verschiebt und verändert keine Nutzerdateien. Einzige Schreibaktion: der Bericht, wenn du ihn selbst über „Save report“ speicherst.

## Ziel

**Ist jede Datei aus Ordner A (kleiner, Kandidat zum Löschen) inhaltlich auch in Ordner B (größer, wird behalten) vorhanden, und geht beim Löschen von A nichts kaputt, was in B liegt?**

## Was verglichen wird und was nicht (bewusste Abgrenzung)

Verglichen wird der **Dateiinhalt** (BLAKE3 über die ganze Datei, ohne Hash-Cache) und die **Symlinks** (nie verfolgt).

**Nicht geprüft werden, und das ist so gewollt:**

- **Metadaten:** Datum/Zeit, Finder-Tags, ACLs, Extended Attributes, Ressourcen-Forks
- **Hardlinks:** Eine A-Datei, die ein Hardlink auf eine B-Datei ist, zählt als identischer Inhalt. Zwei A-Dateien mit gleichem Inhalt brauchen zwei B-Exemplare (strenge 1:1-Zuordnung).
- **Projektverweise:** Pfade innerhalb von Projektdateien (Ableton, Final Cut, Logic, Blender usw.) und Finder-Aliase
- **Verweise von außerhalb:** Symlinks oder Aliase irgendwo sonst auf der Platte, die in A hineinzeigen. Nur Symlinks **in B** werden geprüft.

Der Bericht nennt diese Grenzen jedes Mal.

## Die fünf Urteile

| Urteil | Bedeutung | Löschen von A? |
|---|---|---|
| **CONTENT CONTAINMENT CONFIRMED** | Jede reguläre Datei von A hat eine eigene inhaltsgleiche Kopie in B, jeder Symlink von A hat ein Gegenstück in B, nichts wurde übersprungen außer bekanntem Systemmüll. | im geprüften Umfang unbedenklich |
| **CONFIRMED EXCEPT IGNORED FILES** | Wie oben, aber Dateien von A wurden wegen **selbst hinzugefügter** Ignorier-Muster nicht verglichen. | erst die Liste „IGNORED IN A“ prüfen |
| **INCONCLUSIVE** | Reguläre Dateien sind in B, aber etwas in A war nicht vergleichbar (Symlink ohne Gegenstück, Socket/Gerät/FIFO), oder der Scan war unvollständig (Fehler, Warnung, Abbruch, Änderung während des Scans, fehlende Rechte). | nein |
| **DO NOT DELETE A** | Symlinks in B zeigen nach A und würden brechen. | nein |
| **NOT COMPLETE** | Mindestens eine Datei existiert nur in A. Die Liste zeigt sie. | nein |

Fehler führen immer zu „mehr fehlt“, nie zu weniger. Ein falsches „CONFIRMED“ ist nur bei einem BLAKE3-Treffer ohne gleichen Inhalt oder bei unbemerkt geänderten Dateien denkbar. Das Urteil gilt nur für den Zustand zum Scan-Zeitpunkt.

## Änderungen gegenüber Version 2 (Antwort auf das Review)

1. **Symlinks:**
   - Symlinks in B, die nach A zeigen, blockieren jetzt („DO NOT DELETE A“). Geprüft wird der gespeicherte Zielpfad (lexikalisch aufgelöst, `..` eingerechnet) **und** der tatsächlich aufgelöste Ort (zusätzlich ohne Beachtung der Groß-/Kleinschreibung).
   - Symlinks in A zählen nur dann als vertreten, wenn ein Link in B **dasselbe auflöst**: innerhalb des eigenen Baums an derselben relativen Position (und diese Position existiert in B), oder auf denselben Ort außerhalb. Gleicher Linktext mit anderer Verzeichnistiefe (`../x`) gilt nicht mehr als gleich.
2. **Ignorierregeln:**
   - Es werden nur **Dateien** ignoriert, **nie Ordner**. Ein Ordner, der wie ein Muster heißt, wird normal verglichen.
   - Standardliste = bekannter Systemmüll (`.DS_Store, ._*, Thumbs.db, desktop.ini, .localized`). Jede zusätzliche Regel, die in A Dateien erfasst, senkt das Urteil auf „CONFIRMED EXCEPT IGNORED FILES“.
   - Ignorierte Dateien stehen mit Größe im Bericht und werden nie als Treffer benutzt.
3. **Validierung** (siehe unten): unabhängiges Prüfskript, Zufallstests, Rechte- und Abbruchfälle, Headless-Test auf echten Ordnern.

Aus Version 2 weiterhin enthalten: Dateidialog im eigenen Thread, Fortschritt (3 Schritte, Hashing mit Prozent), „Save report“, keine Änderung des OK-Texts anderer Popups.

## Installation auf einem Mac mit Apple Silicon

```bash
git clone --branch 12.0.2 https://github.com/qarmin/czkawka.git
python3 /PFAD/ZU/krokiet_folder_compare_patch/apply_patch.py "$PWD/czkawka"
cd czkawka
cargo test -p krokiet folder_ --locked
cargo build -p krokiet --release --locked
./target/release/krokiet
```

Rust mindestens 1.94.1 (rustup). Das Skript prüft die Version und bricht ab, wenn die erwarteten Textstellen nicht genau einmal vorkommen. **Nicht auf `master` patchen.** Falls `cargo test` oder der Build Fehler meldet, schick mir die Ausgabe, dann korrigiere ich gezielt.

## So gehst du sicher vor (empfohlene Reihenfolge)

1. **`cargo test -p krokiet folder_ --locked`** muss grün sein. Die Tests laufen mit dem echten Czkawka-Scanner und decken u. a. Mehrfachkopien, leere Dateien, Umbenennungen, Symlinks (inkl. Verweise von B nach A), Ignorierregeln, fehlende Leserechte und Abbruch ab.
2. **Probelauf an zwei kleinen Testordnern** (Kopien, nicht deine Originale): Datei in A ändern, eine Datei nur in A anlegen, einen Symlink in B auf A legen. Das Tool muss jeweils NOT COMPLETE / DO NOT DELETE A melden.
3. **Zweite Meinung mit dem unabhängigen Skript** für jedes Ordnerpaar, das du löschen willst:

   ```bash
   python3 verify_folders.py "/Volumes/Platte/A" "/Volumes/Platte/B"
   ```

   Gleiche Regeln, eigener Code, SHA-256, nur Standardbibliothek, nur lesend. Zwei verschiedene Programme müssen zum selben Urteil kommen (Exit-Code 0 nur bei CONFIRMED). Etwas langsamer, weil ein Thread.
4. **Ohne Oberfläche auf echten Ordnern** (z. B. für Skripte):

   ```bash
   FC_A="/Volumes/Platte/A" FC_B="/Volumes/Platte/B" \
   cargo test -p krokiet folder_compare::tests::real_folders --release -- --ignored --nocapture
   ```

   Optional `FC_IGNORE=".DS_Store, ._*"`.
5. **Beim Löschen:** erst in den Papierkorb bzw. in einen Ordner `_zu_loeschen` verschieben, einige Tage warten, dann endgültig löschen. Das Tool prüft nicht, was außerhalb von A und B auf A verweist (Aliase, Projektdateien).

## Neu in Version 5: Ordner-Übersicht (Ampel pro Ordner)

Nach einem Duplikat-Scan mit der Methode **Hash** (empfohlen: Blake3) öffnet die Schaltfläche „Ordner-Übersicht“ ein Fenster. Es beantwortet pro Ordner eine einzige Frage: **Wie viel davon liegt schon woanders?** Die Ergebnisse des normalen Scans werden wiederverwendet, es wird nichts neu gehasht.

**Logik:** Eine Datei in Ordner A gilt als gedeckt, wenn es von ihrem Inhalt mindestens eine Kopie außerhalb von A gibt, egal auf welcher Platte und in welchem Ordner.

- **Grün:** jede Datei des Ordners ist gedeckt.
- **Gelb:** mindestens die eingestellte Schwelle der Bytes ist gedeckt (Standard 90 %, einstellbar 50 bis 100 %).
- Sonst erscheint der Ordner nicht.

**Anzeige:**

- Oben pro Platte: Größe, Dateizahl, wie viel davon auch auf einer anderen Platte liegt, wie viel nur eine Kopie auf derselben Platte hat. Die Platte wird aus dem Pfad erkannt (`/Volumes/NAME`, sonst „Startvolume“). Ein Auswahlfeld filtert die Liste auf eine Platte.
- Pro Ordner: Ampel, Abdeckung in Bytes und Dateien, Größe, „auch in:“ mit bis zu drei Fundstellen und deren Anteil (so siehst du „teils B, teils C“), neueste Datei hier und in der ersten Fundstelle (so siehst du 2025 gegen 2026), Hinweis auf Zwillinge.
- Klick auf eine Zeile zeigt unten die Details: alle Fundstellen mit Platte und Datum, und die Liste **„Nur hier“**, also genau die Dateien, die nach dem Löschen nirgends mehr existierten.
- Der Knopf „Streng prüfen“ öffnet den bekannten Vergleich mit dem Ordner und der ersten Fundstelle. Nur dieser liefert ein Urteil.
- Unterordner werden zusammengefasst: Ein Ordner erscheint nicht, wenn ein übergeordneter schon mindestens genauso stark gemeldet ist.
- **Zwillinge:** Haben mehrere grüne Ordner genau denselben Inhalt, steht „ZWILLING“ dabei. Löschst du alle, ist der Inhalt weg. Allgemein gilt: Löschst du mehrere grüne Ordner, können sie sich gegenseitig als Kopie dienen. Eine Schutzlogik dafür folgt mit dem Vormerken in einer späteren Version.

**Genauigkeit und Grenzen:**

- Die Liste betrachtet alle Dateien, die der Scan nach Ordnern, Ausschlüssen und Filtern betrachtet, **aber ohne Mindestgröße**. Dateien unterhalb der Mindestgröße des Scans werden nicht verglichen und zählen als „nur hier“. Die Statuszeile warnt dann. Für genaue Werte die Mindestgröße im Scan auf 0 setzen.
- Dateien in ausgeschlossenen Ordnern oder mit ausgeschlossener Endung fehlen in der Auswertung. Ein Ordner kann deshalb grün sein, obwohl seine Kopie in einem ausgeschlossenen Bereich liegt (dann sieht man sie nicht) oder umgekehrt. Für Löschentscheidungen keine Ausschlüsse verwenden.
- Systemdateien (.DS_Store, ._*, Thumbs.db, desktop.ini, .localized) werden nicht mitgezählt.
- Hardlinks, die der Scan ausblendet, gelten als „ohne Kopie“ und senken die Abdeckung. Das macht die Liste vorsichtiger.
- „Auch in:“ ist eine Hilfe: Ordner, die den Ordner selbst enthalten, zählen nicht als Fundstelle, sehr häufige Inhalte (über 200 Kopien) werden dort übergangen, es werden höchstens drei Fundstellen gezeigt. Der Rest steht als „weitere“.
- Funktioniert nicht mit Referenzordnern und nicht bei abgebrochenem Scan. Bei anderem Hash als Blake3 warnt die Statuszeile.
- Die Liste zeigt höchstens 1500 Zeilen (größte zuerst). Sie erscheint kurz nach dem Scan-Ende, starte währenddessen keinen neuen Scan.
- Nichts wird gelöscht oder verändert.

Technische Änderungen an Czkawka: zwei neue, nur lesende Methoden in `czkawka_core/src/tools/duplicate/core.rs` (`prepare_full_inventory`, `get_minimal_file_size_for_addon`) und ein kleiner Haken am Ende von `krokiet/src/connect_scan/duplicate.rs`.

**Validierung der Engine (Linux-Sandbox):** 1500 zufällige Ordnerbäume mit mehreren Platten, Systemmüll, leeren Dateien, Zwillingen und Plattenfilter gegen eine unabhängige Python-Referenz (Ampel, Zusammenfassung, Zwillinge, Plattenstatistik, Fundstellen), 0 Abweichungen. Leistungstest mit 530.000 Dateien und 15.000 Ordnern: Auswertung unter 0,3 Sekunden, Fundstellen für 9000 Zeilen unter 0,1 Sekunden. Sieben Unit-Tests im Modul. **Nicht geprüft:** Kompilierung, Oberfläche, echter Scan auf macOS. Die Folder-Compare-Validierung unten gilt unverändert.

## Validierung (was geprüft ist und was nicht)

**Hier ausgeführt (Linux-Sandbox):**

- Patch lässt sich auf frisches Original 12.0.2 anwenden, zweiter Lauf wird abgelehnt.
- Reine Vergleichslogik (Inventar, Zuordnung, Symlink-Regeln, Ignorierregeln, Urteil) gegen das unabhängige Python-Skript: 4500 zufällige Ordnerbäume mit Symlinks (relativ, absolut, in A, in B, außerhalb, verschiedene Tiefen), leeren Dateien, Mehrfachkopien, Systemmüll, `.mov`-Sonderregel und FIFOs. **0 Abweichungen**, alle fünf Urteile kamen vor.
- Unlesbares Verzeichnis und unlesbare Datei als normaler Benutzer: kein Urteil (INCONCLUSIVE). Abbruch: kein Urteil.

**Nicht geprüft, bitte bei dir testen:**

- Kompilierung der Rust- und Slint-Teile und der echte Czkawka-Scanner (Schritt 1 oben).
- Echte macOS-Dateisysteme (APFS, exFAT, HFS+), Netzlaufwerke, TCC-Rechtedialoge auf externen Volumes. Die Logik verwendet nur Dateiinhalt, Pfade und Symlinks, keine Inodes. Bei exFAT/APFS-Unterschieden (Unicode-Normalisierung, Groß-/Kleinschreibung, 2-Sekunden-Zeitstempel) fällt das Ergebnis im Zweifel auf „INCONCLUSIVE“ oder „fehlt“, nicht auf „bestätigt“. Das wurde aber nicht auf echten Laufwerken verifiziert.
- Beide Prüfverfahren stammen aus derselben Spezifikation. Der Test findet Implementierungsfehler, aber keine Denkfehler in den Regeln selbst.

## Quellcode, auf den sich die Erweiterung bezieht

- `krokiet/src/main.rs`, `krokiet/ui/main_window.slint`, `krokiet/src/connect_rfd.rs`
- `czkawka_core/src/tools/duplicate/{mod.rs,core.rs,traits.rs}`
- `czkawka_core/src/common/{tool_data.rs,progress_data.rs}`

Die GPL-3.0-Pflichten für eine Weitergabe eines gesamten Krokiet-Builds sind zu beachten. Original: https://github.com/qarmin/czkawka
