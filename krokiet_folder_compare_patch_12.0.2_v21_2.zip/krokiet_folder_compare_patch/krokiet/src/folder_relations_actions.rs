//! Read-only Finder and Quick Look operations for the global folder relationship list.
//! No deletion queue or batch trash action exists in v10.
use std::ffi::OsStr;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::sync::Mutex;
use std::thread;
use super::*;

static FILES: Mutex<(Vec<PathBuf>, PathBuf)> = Mutex::new((Vec::new(), PathBuf::new()));

pub(crate) fn set_files(files: Vec<PathBuf>, base: PathBuf) {
    if let Ok(mut guard) = FILES.lock() { *guard = (files, base); }
}

fn spawn_detached(program: &str, args: &[&OsStr]) -> Result<(), String> {
    let mut child = Command::new(program)
        .args(args).stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null())
        .spawn().map_err(|e| format!("{program}: {e}"))?;
    thread::spawn(move || { let _ = child.wait(); });
    Ok(())
}

#[cfg(target_os = "macos")]
fn quick_look(path: &Path) -> Result<(), String> { spawn_detached("qlmanage", &[OsStr::new("-p"), path.as_os_str()]) }
#[cfg(not(target_os = "macos"))]
fn quick_look(_path: &Path) -> Result<(), String> { Err("Quick Look wird nur auf macOS unterstützt".into()) }
#[cfg(target_os = "macos")]
fn reveal(path: &Path) -> Result<(), String> { spawn_detached("open", &[OsStr::new("-R"), path.as_os_str()]) }
#[cfg(not(target_os = "macos"))]
fn reveal(_path: &Path) -> Result<(), String> { Err("Finder wird nur auf macOS unterstützt".into()) }

pub(crate) fn connect(app: &MainWindow) {
    let weak = app.as_weak();
    app.on_folder_relations_action(move |action, index| {
        let result = match action.as_str() {
            "reveal_folder" => selected_row_path(index).and_then(|p| reveal(&p)),
            "preview_file" | "reveal_file" => file_at(index).and_then(|(file, base)| {
                if !file.starts_with(&base) { return Err("Datei außerhalb des Ordners".into()); }
                let meta = std::fs::symlink_metadata(&file).map_err(|e| e.to_string())?;
                if !meta.file_type().is_file() { return Err("Nur reguläre Dateien".into()); }
                if action == "preview_file" { quick_look(&file) } else { reveal(&file) }
            }),
            _ => Err("Unbekannte Aktion".into()),
        };
        if let Err(err) = result {
            let _ = weak.upgrade_in_event_loop(move |app| app.set_folder_relations_action_status(err.into()));
        }
    });
}

fn selected_row_path(index: i32) -> Result<PathBuf, String> {
    let view = VIEW.lock().ok().and_then(|guard| guard.clone()).ok_or("Keine Ansicht")?;
    let row = usize::try_from(index).ok().and_then(|i| view.rows.get(i)).ok_or("Keine Zeile gewählt")?;
    Ok(view.index.node_path(row.a))
}
fn file_at(index: i32) -> Result<(PathBuf, PathBuf), String> {
    let guard = FILES.lock().map_err(|_| "Interner Fehler")?;
    let path = usize::try_from(index).ok().and_then(|i| guard.0.get(i)).ok_or("Keine Datei gewählt")?;
    Ok((path.clone(), guard.1.clone()))
}
