# Krokiet Folder Compare v21.2 – macOS ARM64 (Test-Build)

Basis: Krokiet/Czkawka 12.0.2, Weiterentwicklung von v19.1. **Dies ist Quellcode, keine kompilierte App.**


## v21.2 – Slint-Tooltip-Kompilierungsfix

- Alle 16 Tooltips in `popup_folder_workspace.slint` geben nun `styled-text` mittels `@markdown(...)` aus.
- Dynamische Pfade und Statusmeldungen bleiben als dynamische Werte eingebunden; Inhalte werden bei der Markdown-Interpolation escaped.
- Keine Änderungen an der v21-Performance-Engine, am Datei-Scan oder an der v21.1-Papierkorb-Paketierung.
- Dieser Fix wurde statisch und mit Python-Regressionstests geprüft. Ein nativer macOS-Rust/Slint-Build bleibt erforderlich.

## v21.1 – Begrenzte Papierkorb-Systemaufrufe ohne Verlust der v21-Performance

- Der Fehler **„Argument list too long (os error 7)“** bei großen Papierkorb-Auswahlen wird adressiert: `trash::delete_all()` erhält nicht mehr die gesamte Auswahl auf einmal, sondern Pakete von höchstens **48 Pfaden**, zusätzlich begrenzt auf **32 KiB geschätzte Argumentkosten pro Aufruf** (mit Sicherheitszuschlag für Escaping). Das sind interne Paketgrenzen, **keine** Begrenzung der Dateiauswahl. Ein einzelner ungewöhnlich langer Pfad kann weiterhin einen macOS-Fehler auslösen.
- **Beide** zuvor unbeschränkten Aufrufstellen wurden angepasst: reguläre Papierkorb-Bereinigung und der datenträgerübergreifende Verschiebe-Fallback (historische, nicht prominent angebotene Move-Engine).
- Zwischen den Paketen kann abgebrochen werden. Jede Datei wird nach einem Paketergebnis separat auf den verbleibenden Quellpfad geprüft. Es werden ausschließlich eindeutig entfernte Dateien aus dem Index genommen; bereits kopierte Dateien mit verbliebener Quelle werden als Teilresultat behandelt.
- Ein weiterer macOS-Freigabedialog pro Paket ist möglich. Die Änderung behebt die überschrittene Argumentgröße, **nicht** Dateiberechtigungen, TCC-Abfragen oder sämtliche AppleScript-Probleme.
- Die v21-Dateizuordnung, Hintergrundvorschau, Ordner-Analyse-Caches und **Slint-UI sind unverändert geblieben**. Kein vollständiger Rust-/Slint- oder macOS-Laufzeittest in dieser Umgebung.

## v21 – Performance beim Laden eines Ordnerpaars und beim Seitenwechsel

Nur Geschwindigkeit, kein neuer Funktionsumfang. Gemessen wurde die Vorschau-Logik mit synthetischen Daten (190.000 Dateien in A, 3,4 Mio in B, Release-Build). Rust-Build von Krokiet und Slint sind weiterhin **nicht** geprüft.

- **Ordnerpaar wählen und „A/B tauschen“ liefen im UI-Thread.** Das Fenster fror ein, bis alle Zeilen gebaut waren. Jetzt läuft das im Hintergrund, die Oberfläche zeigt „Ordnerpaar wird aus dem Index geladen …“.
- **Quadratische Suche beseitigt.** Für jede identische Datei wurde die komplette B-Liste linear durchsucht (bei 115.000 identischen Dateien gegen 3,4 Mio B-Dateien). Das ist jetzt ein direkter Zugriff. Hochgerechnet etwa 17 Minuten, jetzt etwa 2 Sekunden. Die neue Funktion liefert Eintrag für Eintrag dasselbe wie die alte (Differenztest mit 3000 Zufallsfällen).
- **B wird nicht mehr komplett sortiert.** Bei Millionen Pfaden kostete das mehrere Sekunden. Nur A und die kleinen Kandidatenlisten werden sortiert. „Nur in B“ erscheint dafür in Baumreihenfolge.
- **Knotensuche im Index** baut Pfade nur noch für Ordner mit passendem Namen.
- **Paarliste (links): Seitenwechsel und Reiterwechsel rechnen nicht mehr alles neu.** Bisher wurden bei jedem Seitenwechsel alle Kandidaten neu berechnet, sortiert und auf Zwillinge geprüft; nur die Partnerdetails entstanden bereits für die sichtbare Seite. Jetzt liegt das Ergebnis zwischengespeichert vor und eine Seite ist nur ein Ausschnitt.
- Zwei neue Rust-Tests sichern die Zuordnung: Es wird immer eins zu eins gepaart (zwei identische Dateien in A, eine Kopie in B: nur eine gilt als identisch), und bei Duplikaten wird der gleiche relative Pfad bevorzugt.

**Noch nicht gelöst (Plan für v22):** Die Tabelle enthält weiterhin einen Eintrag je B-Datei (3,3 Mio „Nur in B“), das kostet Speicher und jede Filter- oder Auswahländerung durchläuft die Liste. „Nur in B“ sollte erst auf Wunsch aufgebaut und die Zähler sollten mitgeführt werden.

## v20 – Kompakter Arbeitsbereich zum Konsolidieren von Ordnern

**Wichtig:** Dieser Patch ist für einen GitHub-Build vorgesehen. Hier wurden kein Rust-/Slint-Build und keine realen Papierkorbaktionen durchgeführt. Nutze zunächst ausschließlich Testdaten.

- Ein Fenster mit drei gleichzeitig sichtbaren, scrollbareren Bereichen: **Ordnerpaare**, **Unterordner in A**, **Dateien in A/B**. Bei schmalen Fenstern können die Seitenbereiche einzeln ausgeblendet werden. Dateiaktionen sind unten fest angeordnet.
- A ist standardmäßig der **Arbeitsordner**. Die Hauptfilter lauten Alle A, Identisch in B, Fehlt in B und Abweichend. Nur-B-Dateien und alle A+B-Dateien sind weiter über **Mehr** sichtbar; ein A/B-Tausch bleibt möglich.
- Klick auf Unterordnernamen **filtert** die Dateiliste; das Kästchen **wählt alle für Aktionen geeigneten Dateien** dieses Unterordners. Konflikte werden dabei nicht mitselektiert. Die Auswahl bleibt über Filter und nachladbare Dateizeilen erhalten.
- Slint `ListView` virtualisiert die aktuell bereitgestellten Zeilen. Der Rust-Adapter lädt zunächst 240 Zeilen und auf Klick weitere 240. Es werden deshalb keine Millionen Zeilen gleichzeitig in das Slint-Modell kopiert; **v20 hat noch keinen automatischen Infinite-Scroll-Auslöser**.
- Der volle Dateipfad und Prüfnachweis ist nach Hover in einem Slint-Tooltip zugänglich (Slint 1.17). Finder und Quick Look bleiben für selektierte Zeilen vorhanden.
- **Kopieren** und **Papierkorb** sind getrennte, bestätigungspflichtige Aktionen. Die v19-Move-Engine bleibt im Quellcode, ist aber im normalen v20-Workflow **nicht über einen Button erreichbar**. Es werden keine Links automatisch umgeschrieben und keine Ordner automatisch gelöscht.
- Die **Zusatz-Byteprüfung** ist weiterhin freiwillig. Vor Papierkorb kann Schnell (Index), aktueller Hash (Standard) oder Bytevergleich gewählt werden. Für jede betroffene Datei wird die gewählte Prüfung separat ausgeführt.
- `link_preflight` inventarisiert nur noch Symlinks statt jedes regulären Dateieintrags. Die Verzeichnisse `.TemporaryItems` und `.Trashes` werden **ausschließlich unmittelbar im Stamm von `/Volumes/<Volume>/`** für diese Linkprüfung ausgelassen und bleiben unverändert. Andere nicht lesbare Verzeichnisse bleiben eine Sperre; deren mögliche Abhängigkeiten können wir nicht ausschließen. Das ist keine allgemeine Deaktivierung der macOS-Berechtigungen.
- Nach erfolgreichen Krokiet-Aktionen werden die bekannten Änderungen wie in v17 lokal im Index nachgeführt, ohne zwangsläufig den gesamten Datenträger neu zu scannen.

### Persistent gespeicherter Index – derzeitige Grenze

Der bestehende Code speichert seit v17 bereits einen **Cache-Snapshot** für Inventare bis zu **250.000 Dateien** (`MAX_PERSIST_FILES`). Dieser wird beim erneuten Laden stets als **veraltet/unverifiziert** behandelt. Für Archive mit Millionen Dateien – wie auf deinem Screenshot – gibt es **noch keinen vollständigen, pro Volume persistenten und inkrementell revalidierbaren Hash-Index**. Das ist eine separate, größere Datenbank-Änderung und **nicht Bestandteil von v20**. Es wäre falsch, die Snapshot-Funktion als vollwertige Lösung dafür zu bezeichnen.

### Geänderter Bedienablauf

1. Krokiet-Duplikatscan mit Hashes ausführen und **Ordner vergleichen** öffnen.
2. Links ein Paar wählen, in der mittleren Spalte einen Unterordner selektieren oder öffnen.
3. Rechts anhand der Statusfilter die A-Dateien prüfen; optional Konflikte nachprüfen (unter **Mehr**).
4. Dateien oder Unterordner auswählen. **Kopieren** ergänzt B ohne Überschreiben und lässt A bestehen. **Papierkorb** betrifft nur nach gewähltem Modus überprüfte identische Kopien aus A.
5. Das Ergebnis kontrollieren. Unlesbare Archivordner und externe Projekt-Pfadreferenzen sind weiterhin besondere Risiken.

---

## v19.1 – Korrektur des macOS-Kopiervorgangs

- In v19 verursachte `/bin/cp -pE` auf macOS einen **Aufruffehler (Exit-Code 64)**. Das war die Ursache für den fehlgeschlagenen Rust-Test `v19_copy_fallback_keeps_source_until_trash`.
- Der Verschiebe-Fallback verwendet jetzt `/bin/cp -p`. Die Option `-p` berücksichtigt auf macOS bereits Zeitstempel, Berechtigungen, ACLs, erweiterte Attribute und Resource Forks, soweit das Zieldateisystem sie unterstützt.
- Bei erneutem `cp`-Fehler erscheint nun zusätzlich die Ausgabe von `stderr` im Fehlerbericht. Das Original bleibt bei fehlgeschlagenem Kopiervorgang bestehen.

## Historie v19 – Verschieben und Kopieren getrennt (in v20 nicht in der Haupt-UI angeboten)

- Nach Wahl der Übertragungsrichtung stehen **Verschieben bestätigen** und **Nur kopieren** nebeneinander.
- **Verschieben** auf unterstützten Dateisystemen: mit `std::fs::hard_link` zuerst ein ausschließlich neu angelegtes Ziel erzeugen, anschließend Quellpfad entfernen. Bewahrt Inhalt und Dateimetadaten ohne erneutes Kopieren. Quelle liegt anschließend nicht im Papierkorb.
- **Verschieben über Dateisystemgrenzen oder auf Dateisystemen ohne Hardlinks:** Quelle metadatenschonend kopieren (`/bin/cp -p` auf macOS), Inhalt byteweise vergleichen und dann die Quellen in begrenzten `trash::delete_all`-Paketen in den Papierkorb verschieben. Bei Fehlern bleiben Quelldateien erhalten; die Anwendung meldet diesen Fall als **nur kopiert**.
- Bestehende Zieldateien werden niemals überschrieben. Bei Problemen ist ein Teilergebnis möglich, das einzeln im Finder kontrolliert werden sollte.
- Der Inhaltsindex aktualisiert nach erfolgreichen Verschiebungen den Dateipfad, statt ein zusätzliches Duplikat einzutragen. Kein vollständiger Neu-Scan nur wegen der eigenen Aktionen.
- Externe Projektverknüpfungen und jede Art von Metadaten auf inkompatiblen Ziel-Dateisystemen können nicht vollständig abgesichert werden. Für echte Archive zuerst mit Testdateien prüfen. Leere Quellverzeichnisse werden nicht automatisch entfernt.

## Wesentliche Änderungen

### Neu in v18: Merge in beiden Richtungen direkt sichtbar

- Im A/B-Vergleich stehen oberhalb der Dateiliste **A → B** und **B → A** mit der Anzahl der jeweils fehlenden Dateien. Eine Richtung wählen markiert automatisch nur die entsprechenden fehlenden Dateien; das Kopieren erfordert eine zweite ausdrückliche Bestätigung.
- Auch eine manuell zusammengestellte Auswahl kann über beide Richtungen kopiert werden. Die Auswahl kann über mehrere Seiten bestehen bleiben.
- V18 kann die fehlenden Dateien **direkt aus B nach A** kopieren; ein vorheriges A/B-Tauschen ist nicht mehr nötig.
- Es werden weder vorhandene Zieldateien überschrieben noch Dateien aus der Quelle entfernt. Nach dem Kopieren wird byteweise verifiziert und der bekannte Ordnerindex aktualisiert, ohne einen vollständigen Festplattenscan zu erzwingen.
- Bei vollständig gleichen Dateiinhalten ist ein Merge nicht erforderlich. Bestehen nur ungeklärte Pfadkonflikte, müssen diese separat untersucht werden; ein automatisches Überschreiben findet nicht statt.
- Hinweis: Die Anzeige beruht anfänglich auf dem **älteren Scan-Index**. Vor dem Kopieren kontrolliert `copy_missing` die Quelle und den Zielpfad; eine erfolgreiche Kopie wird direkt byteweise verifiziert. Metadaten wie Finder-Tags oder Resource Forks werden nicht vollständig übernommen.


### Neu in v17: Nach Lösch- und Kopieraktionen ohne vollständigen Neu-Scan weiterarbeiten

- Das bisherige globale `INDEX_DIRTY` nach **jeder** Dateiaktion war unnötig: Es blendete alle Ordnerbeziehungen aus. Jetzt wird nach nachweislich erfolgreichen Änderungen nur das **im Speicher vorhandene Inventar** korrigiert.
- In den Papierkorb verschobene Dateien werden aus dem Index entfernt. Erfolgreich und byteweise überprüfte Kopien werden ergänzt. Die Gruppenzähler und Ordnerbeziehungen werden aus diesen **gespeicherten Dateieinträgen** neu berechnet – ohne den Datenträger erneut zu durchsuchen oder unberührte Dateien zu hashen.
- Der aktuelle Ordnerfilter, die Sortierung und Seite werden nach Möglichkeit erhalten. Weil sich Zeilenpositionen ändern können, wird die alte Zeilenauswahl zurückgesetzt; die aktualisierte Trefferliste bleibt sichtbar.
- Für ältere unveränderte Dateien ist dies weiterhin der **Stand des letzten Scans**, keine Echtzeitüberwachung der Festplatte. Der Schnellmodus beim Papierkorb bleibt eine bewusste Vertrauensentscheidung.
- Kann eine Kopie nicht mit dem Inventar abgeglichen werden (beispielsweise Quelle außerhalb des ursprünglich gescannten Bereichs), wird der alte Index **ausdrücklich als unverifiziert** angezeigt statt fälschlich sichere Treffer zu melden.
- Der neue Index wird für den nächsten Start als **Cache-Snapshot** gespeichert, der nach Neustart weiterhin als unverifiziert gekennzeichnet wird. Bei sehr großen Inventaren entfällt das Caching, nicht die Aktualisierung im Arbeitsspeicher.


- Symmetrisch identische Zwillingsordner werden in der Trefferliste zu einem repräsentativen Treffer zusammengefasst. Bei mehr als zwei identischen Ordnern wird weiterhin die Gruppengröße angezeigt.
- Bei einem konkreten A/B-Paar steht die **Dateiabdeckung in beide Richtungen**: „A in B“ und „B in A“ mit Dateizahlen. Diese Zahl ist nicht die globale Abdeckung über verstreute Archive.
- In der Vergleichstabelle gibt es eine zusätzliche Aktion **Konflikte prüfen**. Sie vergleicht alle bislang unklaren Pfadpaare A/B frisch byteweise. Danach steht „Identisch“ oder „Verschieden“; „Ungeprüft“ ist bewusst keine Behauptung unterschiedlicher Inhalte.
- „A/B tauschen“ wechselt über die vorhandenen Indexdaten die Richtung des Paares. Die Aktion „Kopieren nach B“ kann so für beide Richtungen verwendet werden. Sind eigene, nicht indexierte Pfade ausgewählt, ist gegebenenfalls „Neu prüfen“ nötig.
- **Keine starre Grenze von 200 Dateien** bei ausdrücklichen Mehrfachaktionen. Dateien werden vor dem Papierkorb einzeln geprüft, danach mit **begrenzten `trash::delete_all`-Paketen** an das Betriebssystem übergeben. Zwischen Paketen ist ein Abbruch möglich; ein Fehler kann eine teilweise Ausführung bedeuten. Die Ergebnisse werden anhand der verbleibenden Originalpfade abgeglichen.
- Das Kopieren verwendet weiterhin `create_new(true)` und überschreibt keine Dateien. Kopien werden byteweise überprüft.
- Der beim Papierkorb verwendete Prüfmodus wird ausdrücklich in der Bestätigung gewählt. Kein neuer Vollscan der Platte; der aktuelle Hashmodus liest nur die ausgewählten A/B-Dateien.
- **Schnell kann Datenverlust ermöglichen:** Größe und Änderungszeit sind kein Beweis für unveränderte Inhalte, auch nicht bei gleichzeitiger Aktualisierung der Uhrzeiten. Wähle bei wichtigen Daten „Aktueller Hash“ oder „Bytevergleich“.

## Bedienung der Versionen v17–v19 (historisch; v20 siehe oben)

1. **Einmal** den regulären Duplikatscan mit Hash-Prüfung starten und **Ordner vergleichen** öffnen.
2. Links ein Ordnerpaar auswählen. Rechts erscheint die **unverifizierte Index-Vorschau**, ohne erneuten gesamten Datenträger-Scan.
3. Für problematische Fälle **Konflikte prüfen** wählen, um gleichnamige Dateien aktuell byteweise nachzuprüfen. Über **Neu prüfen** ist weiterhin ein vollständiger Audit möglich.
4. Oberhalb der Dateiliste steht **Merge A → B / B → A** mit der Zahl fehlender Dateien. Richtung wählen, Auswahl in der Vorschau kontrollieren und Kopieren ausdrücklich bestätigen. Die manuelle Auswahl unter „Nur A“ oder „Nur B“ bleibt möglich.
5. Für identische Dateipaare ist „Optional: Byteprüfung“ weiterhin eine zusätzliche Vorabprüfung. Vor der Papierkorb-Bestätigung einen von drei Modi wählen: **Schnell (Index)** prüft nur Scan-Nachweis, Größe und Änderungszeit (kein neues Lesen der Inhalte, höheres Risiko); **Aktueller Hash** berechnet BLAKE3 für A und B neu (**Voreinstellung**); **Bytevergleich** vergleicht alle Bytes direkt. Ohne qualifizierten Scan-Nachweis wird Schnell für betroffene Dateien gesperrt, nicht still auf einen anderen Modus gewechselt.
6. Nach Merge/Papierkorb wird die Ordnerliste ohne erneuten Scan aktualisiert. Die A/B-Tabelle wird zeilenweise fortgeschrieben; bei externen Änderungen oder unklaren Scan-Daten kann ein erneuter Scan nötig sein.
7. Bei Dateien in externen Projekten, Ressourcen-Forks und Dateien mit AppleDouble-`._`-Metadaten manuell kontrollieren. Die Anwendung kennt keine externen Projektverweise.

## Datenschutz und Sicherheitsgrenzen

- Kein automatisches Entfernen ganzer Ordner, keine permanente Löschung.
- Dateifilter können Inhalte verdecken. Für Archiventscheidungen Filter deaktivieren und den gesamten A/B-Bestand ansehen.
- Die Papierkorb-API verwendet auf macOS bei großen Mengen mehrere begrenzte Systemaufrufe. **Ob macOS tatsächlich nur eine Freigabe abfragt, kann nicht garantiert werden**: Zugriffsrechte, TCC und externe Volumes können weitere Dialoge auslösen. Niemals Rechte pauschal auf allen Dateien ändern, um Dialoge zu umgehen.
- Auch ein erfolgreiches `cargo test` ist keine Zertifizierung gegen alle Datenverlustfälle. Erst auf Testordnern und mit wiederherstellbaren Kopien prüfen.

## GitHub-Build

ZIP ins Repo-Hauptverzeichnis hochladen: `krokiet_folder_compare_patch_12.0.2_v21_2.zip`.
Workflow: `.github/workflows/build-krokiet-v21-2.yml` mit der beigefügten YAML erstellen.

Der Workflow klont Krokiet 12.0.2, wendet `apply_patch.py` an (einschließlich einer **direkten, auf die vorhandene Cargo.lock-Version festgelegten `trash`- und `blake3`-Abhängigkeiten**), führt die Tests mit `--locked` aus und erstellt das ad-hoc signierte ARM64-App-Bundle.

**Vor dem Build:** Der Patch wurde hier statisch geprüft und mit Python-Tests getestet. Rust-/Slint- und macOS-Dateisystem-Tests müssen in GitHub Actions bzw. auf dem Mac erfolgen.
