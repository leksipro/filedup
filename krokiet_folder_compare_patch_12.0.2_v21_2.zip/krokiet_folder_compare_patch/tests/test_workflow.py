"""Static integration regressions. They do not replace Cargo/Slint compilation."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]

class WorkflowTests(unittest.TestCase):
    def test_pair_preview_reuses_existing_index(self):
        core = (ROOT / "krokiet/src/folder_relations.rs").read_text()
        audit = (ROOT / "krokiet/src/folder_compare.rs").read_text()
        installer = (ROOT / "apply_patch.py").read_text()
        self.assertIn("fn index_pair_preview(", core)
        self.assertIn("on_folder_compare_preview", audit)
        self.assertIn("root.folder_compare_preview(a, b)", installer)
        self.assertIn("prepare_index_preview", audit)

    def test_batch_unbounded_and_rechecks_files(self):
        actions = (ROOT / "krokiet/src/folder_audit_actions.rs").read_text()
        self.assertNotIn("MAX_BATCH_FILES", actions)
        self.assertIn('"merge_selected"', actions)
        self.assertIn('"trash_selected:"', actions)
        self.assertIn("copy_missing(from,to,src)", actions)
        self.assertIn("preflight_trash_pair_with_mode(&a, &b", actions)
        self.assertIn("delete_all(&paths)", actions)
        self.assertIn("fn conflict_batch()", actions)
        self.assertIn('if action == "verify_conflicts"', actions)
        self.assertIn("BATCH_STOP.load", actions)
        self.assertNotIn("remove_single_folder", actions)

    def test_v18_direct_bidirectional_merge(self):
        actions = (ROOT / "krokiet/src/folder_audit_actions.rs").read_text()
        ui = (ROOT / "krokiet/ui/popups/popup_folder_workspace.slint").read_text()
        installer = (ROOT / "apply_patch.py").read_text()
        self.assertIn('"select_merge_to_b"', actions)
        self.assertIn('"select_merge_to_a"', actions)
        self.assertIn('"merge_selected_a_to_b"', actions)
        self.assertIn('"merge_selected_b_to_a"', actions)
        self.assertIn('entry.kind == Kind::OnlyB', actions)
        self.assertIn('if merge_to_a { (&b,&a) } else { (&a,&b) }', actions)
        self.assertIn('update_session_copied(index,dest,merge_to_a)', actions)
        self.assertIn('Nach B kopieren', ui)
        self.assertIn('root.open_compare(root.right_path, root.left_path)', ui)
        self.assertIn('selected_merge_back_count: root.folder_audit_selected_merge_back_count', installer)
        self.assertIn('folder_audit_selected_merge_back_count: 0', installer)
        # Never turn a content conflict into an implicit overwrite.
        self.assertIn('.create_new(true)', actions)
        self.assertIn('target_kind = if merge_to_a { Kind::OnlyB }', actions)

    def test_v19_1_macos_copy_uses_supported_flags(self):
        actions=(ROOT/"krokiet/src/folder_audit_actions.rs").read_text()
        self.assertIn('Command::new("/bin/cp").arg("-p")', actions)
        self.assertNotIn('.arg("-pE")', actions)
        self.assertIn('String::from_utf8_lossy(&result.stderr)', actions)
        self.assertIn('fn v19_copy_fallback_keeps_source_until_trash()', actions)

    def test_v19_copy_move_are_distinct(self):
        actions=(ROOT/"krokiet/src/folder_audit_actions.rs").read_text()
        ui=(ROOT/"krokiet/ui/popups/popup_folder_workspace.slint").read_text()
        core=(ROOT/"krokiet/src/folder_relations.rs").read_text()
        for t in ('move_selected_a_to_b','move_selected_b_to_a','stage_move(', 'MoveStage::PendingTrash','update_session_moved','delete_all(&paths)'):
            self.assertIn(t,actions)
        self.assertIn('ManualChange::Moved',core)
        self.assertNotIn('Verschieben bestätigen',ui)
        self.assertIn('Kopieren bestätigen',ui)
        self.assertNotIn('move_selected_a_to_b',ui)
    def test_symmetric_pairs_and_bidirectional_coverage(self):
        core = (ROOT / "krokiet/src/folder_relations.rs").read_text()
        ui = (ROOT / "krokiet/ui/popups/popup_folder_workspace.slint").read_text()
        self.assertIn("let mut groups: HashMap<(Vec<(u32, u32)>, u64)", core)
        self.assertIn("A→B {a_part}", core)
        self.assertIn("B→A {b_part}", core)
        self.assertIn("root.open_compare(root.right_path, root.left_path)", ui)
        self.assertIn('root.audit_action("verify_conflicts", 0)', ui)

    def test_filter_selection_across_pages_and_separate_confirmations(self):
        ui = (ROOT / "krokiet/ui/popups/popup_folder_workspace.slint").read_text()
        actions = (ROOT / "krokiet/src/folder_audit_actions.rs").read_text()
        self.assertIn("root.audit_action(\"select_all\", 0)", ui)
        self.assertIn("root.audit_action(\"filter:all_pairs\", 0)", ui)
        self.assertIn("confirm_trash", ui)
        self.assertIn("confirm_merge", ui)
        self.assertIn("session.selected.extend(shown)", actions)
        self.assertIn("visible_indices(session)", actions)

    def test_v20_scope_and_incremental_display(self):
        actions=(ROOT/'krokiet/src/folder_audit_actions.rs').read_text()
        ui=(ROOT/'krokiet/ui/popups/popup_folder_workspace.slint').read_text()
        for token in ('fn subfolder_rows(', 'fn scope_contains(', 'fn folder_group(',
                      '"select_scope:"', '"load_more"', 'session.display_limit',
                      'e.kind != Kind::OnlyB', 'session.selected.extend(shown)'):
            self.assertIn(token, actions)
        self.assertIn('audit_subfolders', ui)
        self.assertIn('Weitere 240 laden', ui)

    def test_v20_system_directory_exception_is_narrow(self):
        actions=(ROOT/'krokiet/src/folder_audit_actions.rs').read_text()
        self.assertIn('is_known_volume_temp(', actions)
        self.assertIn('Some(".TemporaryItems" | ".Trashes")', actions)
        self.assertIn('Some(Path::new("/Volumes"))', actions)
        self.assertIn('inventory_links_for_preflight', actions)
        self.assertIn('links_into_a(a, &ib)', actions)
        self.assertIn('v20_symlink_only_preflight_still_detects_references', actions)

    def test_v16_check_modes_and_hash_dependency(self):
        actions = (ROOT / "krokiet/src/folder_audit_actions.rs").read_text()
        ui = (ROOT / "krokiet/ui/popups/popup_folder_workspace.slint").read_text()
        installer = (ROOT / "apply_patch.py").read_text()
        index = (ROOT / "krokiet/src/folder_relations.rs").read_text()
        for token in ('TrashCheckMode::Fast', 'TrashCheckMode::FreshHash', 'TrashCheckMode::Bytes',
                      'fn matches_fast_evidence(', 'fn hash_file(', 'entry.fast_proof',
                      'trash_selected:', 'source_stamp(&checked_regular'):
            self.assertIn(token, actions)
        self.assertIn('private property <string> trash_check_mode: "Aktueller Hash"', ui)
        self.assertIn('model: ["Schnell (Index)", "Aktueller Hash", "Bytevergleich"]', ui)
        self.assertIn('add_locked_blake3_dependency(cargo_new, lock_new)', installer)
        self.assertIn('index.hash_label == "Blake3" && !index.from_cache', index)

    def test_v17_index_reconciled_after_successful_actions(self):
        core = (ROOT / "krokiet/src/folder_relations.rs").read_text()
        actions = (ROOT / "krokiet/src/folder_audit_actions.rs").read_text()
        installer = (ROOT / "apply_patch.py").read_text()
        for token in ('enum ManualChange', 'fn reconcile_inventory(', 'fn apply_manual_changes(',
                      'inventory_for_reconciliation', 'run_analysis(&updated, &params, tab)',
                      'persist_snapshot(files', 'v17_remove_one_of_two_copies_drops_duplicate_coverage_without_scan',
                      'v17_reconciled_copy_of_unique_source_joins_new_content_group'):
            self.assertIn(token, core)
        self.assertNotIn('invalidate_after_manual_change(&weak)', actions)
        self.assertIn('apply_manual_changes(&weak, changes)', actions)
        self.assertIn('apply_manual_changes(&weak, vec![change])', actions)
        self.assertIn('selected <=> root.folder_relations_selected', installer)
        self.assertIn('app.set_folder_relations_selected(-1)', core)

    def test_folder_cards_present_a_and_b(self):
        ui = (ROOT / "krokiet/ui/popups/popup_folder_workspace.slint").read_text()
        self.assertIn('A: \\{row[3]}', ui)
        self.assertIn('B: \\{row[7]}', ui)
        self.assertIn('root.open_compare(row[3], row[7])', ui)

if __name__ == "__main__":
    unittest.main()
