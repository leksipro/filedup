"""Smoke test: v16 patch injection against minimal original source anchors.
This is NOT a substitute for applying the patch to the real Krokiet 12.0.2 checkout.
"""
import pathlib
import subprocess
import sys
import tempfile
import unittest

BUNDLE = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BUNDLE))
import apply_patch  # noqa: E402


class InstallerV16Tests(unittest.TestCase):
    def test_patch_creates_audit_callbacks_and_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)

            def put(name, contents):
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(contents, encoding="utf-8")

            put("krokiet/Cargo.toml", '[package]\nversion = "12.0.2"\n[dependencies]\nczkawka_core = "12.0.2"\n')
            put("Cargo.lock", 'version = 4\n\n[[package]]\nname = "krokiet"\nversion = "12.0.2"\ndependencies = [\n "czkawka_core",\n]\n\n[[package]]\nname = "trash"\nversion = "5.2.9"\n\n[[package]]\nname = "blake3"\nversion = "1.8.2"\n')
            put("krokiet/src/main.rs", "mod file_actions;\n" +
                "    connect_scan_button(&app, progress_sender.clone(), stop_flag.clone(), Arc::clone(&shared_models), Arc::clone(&audio_player));")
            put("krokiet/ui/main_window.slint", "\n".join([
                'import { HorizontalBox, LineEdit, Palette, VerticalBox } from "std-widgets.slint";',
                'import { PopupNewDirectories } from "popups/popup_new_directories.slint";',
                "    callback scan_ended(string);",
                '    in-out property <string> text_summary_text: "";',
                "            text_summary := LineEdit {",
                "    new_directory_popup_window := PopupNewDirectories {",
            ]))
            put("czkawka_core/src/tools/duplicate/core.rs", '    #[fun_time(message = "check_files_size", level = "debug")]\n')
            put("krokiet/src/connect_scan/duplicate.rs", apply_patch.HOOK_OLD)
            process = subprocess.run([sys.executable, str(BUNDLE / "apply_patch.py"), str(root)],
                                     capture_output=True, text=True)
            self.assertEqual(process.returncode, 0, process.stderr)
            slint = (root / "krokiet/ui/main_window.slint").read_text(encoding="utf-8")
            for label in ("folder_audit_action", "folder_audit_rows", "folder_audit_page_info",
                          "selected <=> root.folder_audit_selected", "audit_action(name, position)"):
                self.assertIn(label, slint)
            self.assertTrue((root / "krokiet/src/folder_audit_actions.rs").is_file())
            self.assertIn('trash = "=5.2.9"', (root / "krokiet/Cargo.toml").read_text())
            self.assertIn(' "trash",', (root / "Cargo.lock").read_text())
            self.assertIn('blake3 = "=1.8.2"', (root / "krokiet/Cargo.toml").read_text())
            self.assertIn(' "blake3",', (root / "Cargo.lock").read_text())

    def test_no_global_batch_trash_api_in_v10_actions(self):
        source = (BUNDLE / "krokiet/src/folder_relations_actions.rs").read_text(encoding="utf-8")
        self.assertNotIn("start_trash(", source)
        self.assertNotIn("remove_single_folder(", source)
        slint = (BUNDLE / "krokiet/ui/popups/popup_folder_relations.slint").read_text(encoding="utf-8")
        self.assertNotIn('root.action("trash"', slint)
        self.assertNotIn('Auf Löschliste setzen', slint)


if __name__ == "__main__":
    unittest.main()
