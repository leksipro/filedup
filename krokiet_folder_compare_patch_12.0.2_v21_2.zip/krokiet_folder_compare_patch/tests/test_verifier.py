"""Offline regression tests for the read-only Python second-opinion verifier."""
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import verify_folders as verifier


class VerifierV6Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name)
        self.a, self.b = root / 'A', root / 'B'
        self.a.mkdir()
        self.b.mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def put(self, folder, name, content):
        dst = folder / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(content)
        return dst

    def verdict(self):
        return verifier.audit(str(self.a), str(self.b), [])['verdict']

    def test_identical_renamed_nested(self):
        self.put(self.a, 'old/picture.jpg', b'content')
        self.put(self.b, 'new/name.jpg', b'content')
        self.assertEqual(self.verdict(), 'CONFIRMED')

    def test_contained_more_files(self):
        self.put(self.a, 'original', b'1')
        self.put(self.b, 'renamed', b'1')
        self.put(self.b, 'extra', b'2')
        self.assertEqual(self.verdict(), 'CONFIRMED')

    def test_unmatched_different_contents(self):
        self.put(self.a, 'original', b'1')
        self.put(self.b, 'original', b'2')
        self.assertEqual(self.verdict(), 'NOT COMPLETE')

    def test_copy_multiplicity(self):
        self.put(self.a, 'one', b'1')
        self.put(self.a, 'two', b'1')
        self.put(self.b, 'one', b'1')
        self.assertEqual(self.verdict(), 'NOT COMPLETE')

    def test_empty_files(self):
        self.put(self.a, 'one', b'')
        self.put(self.b, 'two', b'')
        self.assertEqual(self.verdict(), 'CONFIRMED')

    @unittest.skipUnless(hasattr(os, 'symlink'), 'Requires symlinks')
    def test_symlink_target_mismatch_must_not_confirm(self):
        self.put(self.a, 'old', b'A')
        self.put(self.b, 'renamed', b'A')
        self.put(self.b, 'old', b'B')
        (self.a / 'link').symlink_to('old')
        (self.b / 'link').symlink_to('old')
        self.assertEqual(self.verdict(), 'INCONCLUSIVE')

    @unittest.skipUnless(hasattr(os, 'symlink'), 'Requires symlinks')
    def test_symlink_from_b_into_a_blocks(self):
        self.put(self.a, 'old', b'A')
        self.put(self.b, 'new', b'A')
        (self.b / 'link').symlink_to(self.a / 'old')
        self.assertEqual(self.verdict(), 'DEPENDENCY ON A')

    @unittest.skipUnless(hasattr(os, 'symlink'), 'Requires symlinks')
    def test_symlink_in_a_without_external_dependency_in_b(self):
        self.put(self.a, 'old', b'A')
        self.put(self.b, 'new', b'A')
        (self.a / 'link').symlink_to('old')
        self.assertEqual(self.verdict(), 'INCONCLUSIVE')

    def test_extra_in_a(self):
        self.put(self.a, 'one', b'A')
        self.put(self.a, 'two', b'B')
        self.put(self.b, 'one', b'A')
        self.assertEqual(self.verdict(), 'NOT COMPLETE')

    def test_default_strict_no_junk_ignored(self):
        self.put(self.a, 'photo', b'A')
        self.put(self.a, '.DS_Store', b'one')
        self.put(self.b, 'photo', b'A')
        self.assertEqual(self.verdict(), 'NOT COMPLETE')
        self.assertEqual(verifier.audit(str(self.a), str(self.b), verifier.parse_patterns(verifier.DEFAULT_IGNORE))['verdict'], 'CONFIRMED EXCEPT IGNORED FILES')


if __name__ == '__main__':
    unittest.main()
