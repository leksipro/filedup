"""Static guards for the v21 performance changes; not a compiler substitute."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "krokiet/src"

class V21Performance(unittest.TestCase):
    def test_preview_runs_off_the_ui_thread(self):
        text = (SRC / "folder_compare.rs").read_text()
        i = text.index("on_folder_compare_preview")
        block = text[i:i + 3500]
        self.assertIn("thread::spawn", block)
        self.assertIn("upgrade_in_event_loop", block)

    def test_no_linear_scan_of_b_per_identical_file(self):
        text = (SRC / "folder_audit_actions.rs").read_text()
        self.assertNotIn("right.iter().find(|f| f.path == *right_path", text)
        self.assertIn("fn index_preview_session(", text)

    def test_analysis_is_cached_between_page_changes(self):
        text = (SRC / "folder_relations.rs").read_text()
        self.assertIn("static ANALYSIS_CACHE", text)
        self.assertIn("fn analyzed_rows(", text)
        self.assertIn("INDEX_DIRTY.load", text[text.index("fn analysis_key"):text.index("fn analyzed_rows")])

if __name__ == "__main__":
    unittest.main()
