from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class TestTrashChunks(unittest.TestCase):
    def test_both_delete_all_sites_are_bounded(self):
        source = (ROOT / "krokiet/src/folder_audit_actions.rs").read_text()
        self.assertEqual(source.count("delete_all(&paths)"), 2)
        self.assertIn("let chunks = trash_chunk_ranges(ready.iter()", source)
        self.assertIn("let chunks = trash_chunk_ranges(verified.iter()", source)
        self.assertIn("if BATCH_STOP.load(Ordering::Relaxed) { break; }", source)
        self.assertIn("TRASH_CHUNK_MAX_ESTIMATED_BYTES", source)
        self.assertIn("v21_1_trash_chunks_are_bounded", source)

    def test_workflow_points_to_correct_package(self):
        text=(ROOT/".github/workflows/build-krokiet.yml").read_text()
        self.assertIn("krokiet_folder_compare_patch_12.0.2_v21_3.zip", text)
        self.assertIn("krokiet-v21-3-macos-arm64-app", text)

if __name__ == "__main__":
    unittest.main()
