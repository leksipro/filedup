"""Consistency checks for patch release packaging, not Rust compilation."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]

class V20Release(unittest.TestCase):
    def test_installer_slint_property_bridge(self):
        installer=(ROOT/'apply_patch.py').read_text()
        ui=(ROOT/'krokiet/ui/popups/popup_folder_workspace.slint').read_text()
        rust=(ROOT/'krokiet/src/folder_audit_actions.rs').read_text()
        for name in ('folder_audit_subfolders','folder_audit_from_index'):
            self.assertIn(name,installer)
            self.assertIn(name,rust)
        for name in ('audit_subfolders','audit_from_index'):
            self.assertIn(name,ui)
        self.assertIn('fn refresh_cached_groups(',rust)
    def test_archive_source_workflow_version(self):
        y=(ROOT/'.github/workflows/build-krokiet.yml').read_text()
        self.assertIn('krokiet_folder_compare_patch_12.0.2_v21_3.zip',y)
        self.assertIn('krokiet-v21-3-macos-arm64-app',y)
        self.assertIn('cargo test -p krokiet --locked',y)
        self.assertIn('cargo build -p krokiet --release --locked',y)

if __name__ == '__main__': unittest.main()
