//! Interactive, manually operated side-by-side audit table.
//! Global folder relationships only suggest pairs; a separate fresh audit builds this table.
//! Filesystem mutations require explicit confirmation; copies never overwrite.
//! Batch trash is one system operation after user-selected checking; no folder deletion.
use super::*;
use std::fs::{File, OpenOptions};
use std::io::{self, Read, Write};
#[cfg(unix)] use std::os::unix::fs::MetadataExt;
use std::process::{Command, Stdio};
use slint::{ModelRc, SharedString, VecModel, Weak};
use czkawka_core::common::remove_single_file;
use trash::delete_all;

const PAGE: usize = 120;
// No arbitrary selection cap: all selected entries are processed with progress and cancellation.
// A batch operation requires an explicit confirmation showing the selected count.
static BATCH_STOP: AtomicBool = AtomicBool::new(false);

pub(super) fn cancel_batch() { BATCH_STOP.store(true, Ordering::Relaxed); }
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Kind { Same, OnlyA, OnlyB, Conflict }
#[derive(Clone, Debug)]
struct Entry { a: Option<PathBuf>, b: Option<PathBuf>, kind: Kind, checked_conflict: bool, fast_proof: Option<FastProof> }

/// A fast check is knowingly weaker: it trusts a prior successful content match
/// only while size and modification time still match the saved scan evidence.
#[derive(Clone, Copy, Debug)]
struct FastProof { size_a: u64, size_b: u64, modified_a: u64, modified_b: u64 }

impl FastProof {
    fn from_audit(a: &Stamp, b: &Stamp) -> Option<Self> {
        Some(Self { size_a: a.bytes, size_b: b.bytes,
            modified_a: unix_seconds(a.modified?)?, modified_b: unix_seconds(b.modified?)? })
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum TrashCheckMode { Fast, FreshHash, Bytes }
impl TrashCheckMode {
    fn parse(s: &str) -> Option<Self> {
        match s { "fast" => Some(Self::Fast), "hash" => Some(Self::FreshHash), "bytes" => Some(Self::Bytes), _ => None }
    }
    fn label(self) -> &'static str { match self { Self::Fast => "Schnell (Index)", Self::FreshHash => "Aktueller BLAKE3", Self::Bytes => "Bytevergleich" } }
}

fn unix_seconds(date: SystemTime) -> Option<u64> { date.duration_since(std::time::UNIX_EPOCH).ok().map(|d| d.as_secs()) }

struct Session {
    a: PathBuf, b: PathBuf, patterns: Vec<String>, entries: Vec<Entry>,
    page: usize, filter: String, selected: BTreeSet<usize>, from_index: bool,
}
static SESSION: Mutex<Option<Session>> = Mutex::new(None);

fn model(rows: Vec<Vec<String>>) -> ModelRc<ModelRc<SharedString>> {
    ModelRc::new(VecModel::from(rows.into_iter().map(|row| {
        ModelRc::new(VecModel::from(row.into_iter().map(SharedString::from).collect::<Vec<_>>()))
    }).collect::<Vec<_>>()))
}

fn row_text(entry: &Entry, a: &Path, b: &Path) -> Vec<String> {
    let left = entry.a.as_deref().map(|p| rel(p, a)).unwrap_or_else(|| "—".into());
    let right = entry.b.as_deref().map(|p| rel(p, b)).unwrap_or_else(|| "—".into());
    let (label, code) = match entry.kind {
        Kind::Same => ("Identisch", "same"),
        Kind::OnlyA => ("Nur in A", "only_a"),
        Kind::OnlyB => ("Nur in B", "only_b"),
        Kind::Conflict => (if entry.checked_conflict { "Verschieden" } else { "Ungeprüft" }, "conflict"),
    };
    let evidence = match entry.kind {
        Kind::Conflict if entry.checked_conflict => "Byteweise geprüft: Datei-Inhalte unterscheiden sich.",
        Kind::Conflict => "Gleicher relativer Pfad; Inhalt noch nicht aktuell byteweise geprüft.",
        Kind::Same => "Identisch laut Vergleich/Index. Vor Papierkorb: Prüfmodus wählen (Schnell / Aktueller Hash / Bytevergleich).",
        Kind::OnlyA => "In B wurde keine identische Dateikopie zugeordnet.",
        Kind::OnlyB => "In A wurde keine identische Dateikopie zugeordnet.",
    };
    vec![left, right, code.into(), label.into(), "0".into(), evidence.into()]
}

/// Seitenzeilen als reine Strings: darf in Hintergrundthreads gebaut werden (ModelRc ist nicht Send).
fn visible_indices(session: &Session) -> Vec<usize> {
    session.entries.iter().enumerate().filter(|(_, e)| match session.filter.as_str() {
        "same" => e.kind == Kind::Same,
        "only_a" => e.kind == Kind::OnlyA,
        "only_b" => e.kind == Kind::OnlyB,
        "conflict" => e.kind == Kind::Conflict,
        "different" => e.kind != Kind::Same,
        _ => true,
    }).map(|(i, _)| i).collect()
}

fn page_rows(session: &Session) -> (Vec<Vec<String>>, String) {
    let displayed = visible_indices(session);
    let pages = displayed.len().max(1).div_ceil(PAGE);
    let page = session.page.min(pages.saturating_sub(1));
    let start = page * PAGE;
    let end = (start + PAGE).min(displayed.len());
    let rows = displayed[start..end].iter().map(|&i| {
        let mut row = row_text(&session.entries[i], &session.a, &session.b);
        row[4] = if session.selected.contains(&i) { "1".into() } else { "0".into() };
        row
    }).collect();
    let merges = session.selected.iter().filter(|&&i| session.entries[i].kind == Kind::OnlyA).count();
    let deletes = session.selected.iter().filter(|&&i| session.entries[i].kind == Kind::Same).count();
    let label = if session.from_index { "INDEX-VORSCHAU (nicht vollständig geprüft)" } else { "Frischer Audit" };
    (rows, format!("{label} · Seite {} / {} · {} von {} Zeilen · {} ausgewählt ({} kopierbar, {} manuell löschbar)",
        page + 1, pages, displayed.len(), session.entries.len(), session.selected.len(), merges, deletes))
}

/// Nur im UI-Thread aufrufen.
pub(super) fn to_model(rows: Vec<Vec<String>>) -> ModelRc<ModelRc<SharedString>> { model(rows) }

/// Called from the background scan thread, before the UI result is published.
pub(super) fn prepare(audit: &Audit, a: &Path, b: &Path) -> (Vec<Vec<String>>, String) {
    let mut entries = Vec::with_capacity(audit.files_a + audit.extra_b.len());
    // Pair same relative path but DIFFERENT content explicitly as a conflict.
    // These paths are NOT in audit.pairs (which contain verified same-content pairs).
    let extra_by_relative: BTreeMap<PathBuf, PathBuf> = audit.extra_b.iter()
        .filter_map(|p| p.strip_prefix(b).ok().map(|relative| (relative.to_path_buf(), p.clone())))
        .collect();
    let mut conflicts_b = BTreeSet::new();
    for path in &audit.missing_a {
        let counterpart = path.strip_prefix(a).ok().and_then(|r| extra_by_relative.get(r));
        if let Some(right) = counterpart {
            conflicts_b.insert(right.clone());
            entries.push(Entry { a: Some(path.clone()), b: Some(right.clone()), kind: Kind::Conflict, checked_conflict: false, fast_proof: None });
        } else {
            entries.push(Entry { a: Some(path.clone()), b: None, kind: Kind::OnlyA, checked_conflict: false, fast_proof: None });
        }
    }
    for (left, right) in &audit.pairs {
        let proof = audit.pair_stamps.get(left).and_then(|(a, b)| FastProof::from_audit(a, b));
        entries.push(Entry { a: Some(left.clone()), b: Some(right.clone()), kind: Kind::Same,
            checked_conflict: false, fast_proof: proof });
    }
    for path in &audit.extra_b {
        if !conflicts_b.contains(path) { entries.push(Entry { a: None, b: Some(path.clone()), kind: Kind::OnlyB, checked_conflict: false, fast_proof: None }); }
    }
    let session = Session { a: a.to_owned(), b: b.to_owned(), patterns: audit.patterns.clone(), entries, page: 0, filter: "all".into(), selected: BTreeSet::new(), from_index: false };
    let result = page_rows(&session);
    if let Ok(mut guard) = SESSION.lock() { *guard = Some(session); }
    result
}

/// Construct a side-by-side table from the existing content index without
/// rehashing files. All conclusions remain explicitly provisional.
pub(super) fn prepare_index_preview(
    a: &Path, b: &Path,
    indexed_a: Vec<crate::folder_relations::IndexedFile>,
    indexed_b: Vec<crate::folder_relations::IndexedFile>,
    patterns: Vec<String>,
) -> (Vec<Vec<String>>, String) {
    let mut by_content_b: BTreeMap<u32, Vec<PathBuf>> = BTreeMap::new();
    let mut left = indexed_a;
    let mut right = indexed_b;
    left.sort_by(|x, y| x.path.cmp(&y.path));
    right.sort_by(|x, y| x.path.cmp(&y.path));
    for f in &right {
        if let Some(id) = f.content_id { by_content_b.entry(id).or_default().push(f.path.clone()); }
    }
    // Prefer the original relative path if there is a choice within one content group.
    let mut used_b = BTreeSet::new();
    let mut entries = Vec::new();
    for file in &left {
        let counterpart = file.content_id.and_then(|id| by_content_b.get(&id)).and_then(|candidates| {
            let same_rel = file.path.strip_prefix(a).ok();
            candidates.iter().find(|p| !used_b.contains(*p) && p.strip_prefix(b).ok() == same_rel)
                .or_else(|| candidates.iter().find(|p| !used_b.contains(*p))).cloned()
        });
        if let Some(ref p) = counterpart { used_b.insert(p.clone()); }
        let fast_proof = counterpart.as_ref().and_then(|right_path| {
            if !file.fast_eligible { return None; }
            let other = right.iter().find(|f| f.path == *right_path && f.fast_eligible)?;
            Some(FastProof { size_a: file.size, size_b: other.size,
                modified_a: file.modified, modified_b: other.modified })
        });
        let kind = if counterpart.is_some() { Kind::Same } else { Kind::OnlyA };
        entries.push(Entry { a: Some(file.path.clone()), b: counterpart,
            kind, checked_conflict: false, fast_proof });
    }
    // A and B entries with matching relative paths but different/unknown hashes are conflicts.
    let extras: BTreeMap<PathBuf, PathBuf> = right.iter().filter(|f| !used_b.contains(&f.path))
        .filter_map(|f| f.path.strip_prefix(b).ok().map(|r| (r.to_owned(), f.path.clone()))).collect();
    let mut consumed = BTreeSet::new();
    for item in &mut entries {
        if item.kind != Kind::OnlyA { continue; }
        if let Some(path) = &item.a {
            if let Ok(rel) = path.strip_prefix(a) {
                if let Some(dest) = extras.get(rel) {
                    item.b = Some(dest.clone()); item.kind = Kind::Conflict; consumed.insert(dest.clone());
                }
            }
        }
    }
    for file in right {
        if !used_b.contains(&file.path) && !consumed.contains(&file.path) {
            entries.push(Entry { a: None, b: Some(file.path), kind: Kind::OnlyB, checked_conflict: false, fast_proof: None });
        }
    }
    let session = Session { a: a.into(), b: b.into(), patterns,
        entries, page: 0, filter: "all".into(), selected: BTreeSet::new(), from_index: true };
    let result = page_rows(&session);
    if let Ok(mut guard) = SESSION.lock() { *guard = Some(session); }
    result
}

/// Produce a truthful report from the indexed preview instead of accidentally
/// exporting a previously completed, unrelated fresh audit.
pub(super) fn index_preview_report() -> Option<String> {
    let guard = SESSION.lock().ok()?;
    let session = guard.as_ref()?;
    if !session.from_index { return None; }
    let mut lines = vec![
        "UNVERIFIZIERTE INDEX-VORSCHAU – KEINE LÖSCHFREIGABE".to_owned(),
        format!("A: {}", session.a.display()),
        format!("B: {}", session.b.display()),
        format!("{} Einträge aus früherem Scan; Filter für Systemdateien können den Index einschränken", session.entries.len()),
    ];
    for entry in &session.entries {
        let row = row_text(entry, &session.a, &session.b);
        lines.push(format!("{} | {} | {}", row[3], row[0], row[1]));
    }
    Some(lines.join("\n"))
}

pub(super) fn reset() {
    if let Ok(mut guard) = SESSION.lock() { *guard = None; }
}

fn ui_message(weak: &Weak<MainWindow>, message: String) {
    let _ = weak.upgrade_in_event_loop(move |app| app.set_folder_compare_status(message.into()));
}

/// A completed audit belongs to one exact pair of roots and one set of filters.
/// The user can edit the path fields or choose a different pair from Folder Relationships
/// without starting a new scan. Never apply a manual file action to that old session.
fn current_inputs_match_session(app: &MainWindow) -> bool {
    let Ok(guard) = SESSION.lock() else { return false; };
    let Some(session) = guard.as_ref() else { return false; };
    let left = fs::canonicalize(Path::new(app.get_folder_compare_left_path().as_str())).ok();
    let right = fs::canonicalize(Path::new(app.get_folder_compare_right_path().as_str())).ok();
    let patterns = parse_patterns(app.get_folder_compare_ignore_patterns().as_str()).ok();
    // Auch der Pfad der Sitzung wird kanonisiert: Die Index-Vorschau speichert den Pfad aus dem Scan, der Audit den kanonischen.
    let session_a = fs::canonicalize(&session.a).ok();
    let session_b = fs::canonicalize(&session.b).ok();
    left.is_some() && right.is_some()
        && left == session_a
        && right == session_b
        && patterns.as_deref() == Some(session.patterns.as_slice())
}

fn checked_roots(a: &Path, b: &Path) -> Result<(), String> {
    let ma = fs::symlink_metadata(a).map_err(|e| format!("A: {e}"))?;
    let mb = fs::symlink_metadata(b).map_err(|e| format!("B: {e}"))?;
    if !ma.file_type().is_dir() || !mb.file_type().is_dir() {
        return Err("A und B müssen echte Verzeichnisse sein (keine symbolischen Links).".into());
    }
    let ca = a.canonicalize().map_err(|e| e.to_string())?;
    let cb = b.canonicalize().map_err(|e| e.to_string())?;
    if ca.starts_with(&cb) || cb.starts_with(&ca) { return Err("A und B dürfen nicht ineinander liegen.".into()); }
    Ok(())
}

fn checked_regular(path: &Path, root: &Path) -> Result<fs::Metadata, String> {
    if !path.starts_with(root) || path == root { return Err("Datei liegt außerhalb des gewählten Ordners.".into()); }
    let meta = fs::symlink_metadata(path).map_err(|e| e.to_string())?;
    if !meta.file_type().is_file() { return Err("Nur echte reguläre Dateien sind erlaubt, keine Symlinks.".into()); }
    let canon = path.canonicalize().map_err(|e| e.to_string())?;
    if !canon.starts_with(root.canonicalize().map_err(|e| e.to_string())?) {
        return Err("Dateipfad verlässt den ausgewählten Ordner.".into());
    }
    Ok(meta)
}

/// Liest, bis der Puffer voll oder das Ende erreicht ist. Einzelne `read`-Aufrufe dürfen kürzer ausfallen
/// (Netzlaufwerke, externe Platten); ohne diese Schleife würden gleiche Dateien als verschieden gemeldet.
fn fill<R: Read>(reader: &mut R, buffer: &mut [u8]) -> io::Result<usize> {
    let mut total = 0;
    while total < buffer.len() {
        match reader.read(&mut buffer[total..]) {
            Ok(0) => break,
            Ok(n) => total += n,
            Err(e) if e.kind() == io::ErrorKind::Interrupted => continue,
            Err(e) => return Err(e),
        }
    }
    Ok(total)
}

fn equal_streams<R: Read, S: Read>(left: &mut R, right: &mut S) -> io::Result<bool> {
    let mut left_buffer = vec![0u8; 128 * 1024];
    let mut right_buffer = vec![0u8; 128 * 1024];
    loop {
        let n = fill(left, &mut left_buffer)?;
        let m = fill(right, &mut right_buffer)?;
        if n != m || left_buffer[..n] != right_buffer[..m] { return Ok(false); }
        if n == 0 { return Ok(true); }
    }
}

fn equal_bytes(a: &Path, b: &Path) -> io::Result<bool> {
    equal_streams(&mut File::open(a)?, &mut File::open(b)?)
}

fn source_stamp(meta: &fs::Metadata) -> (u64, Option<SystemTime>) {
    (meta.len(), meta.modified().ok())
}

/// Streaming BLAKE3: bounded memory independent of file size.
fn hash_file(path: &Path) -> io::Result<blake3::Hash> {
    let mut file = File::open(path)?;
    let mut hasher = blake3::Hasher::new();
    let mut buf = [0_u8; 128 * 1024];
    loop {
        let n = file.read(&mut buf)?;
        if n == 0 { break; }
        hasher.update(&buf[..n]);
    }
    Ok(hasher.finalize())
}

/// Fast mode does not read content. Only valid for a qualifying, formerly
/// content-verified pair with metadata from that completed scan.
fn matches_fast_evidence(left: &fs::Metadata, right: &fs::Metadata, proof: FastProof) -> bool {
    left.len() == proof.size_a && right.len() == proof.size_b &&
        proof.size_a == proof.size_b &&
        left.modified().ok().and_then(unix_seconds) == Some(proof.modified_a) &&
        right.modified().ok().and_then(unix_seconds) == Some(proof.modified_b)
}

/// Create missing parent directories, refusing all existing symlinks.
/// Does not allow a symlink in any component of the target within B.
fn checked_destination(b: &Path, relative: &Path) -> Result<PathBuf, String> {
    if relative.is_absolute() || relative.components().any(|c| !matches!(c, Component::Normal(_))) {
        return Err("Ungültiger relativer Dateipfad.".into());
    }
    let mut current = b.to_path_buf();
    let parent = relative.parent().ok_or("Ungültiger Zielpfad")?;
    for component in parent.components() {
        current.push(component.as_os_str());
        if current.exists() {
            let meta = fs::symlink_metadata(&current).map_err(|e| e.to_string())?;
            if !meta.file_type().is_dir() { return Err(format!("Ziel enthält Link oder Datei statt Verzeichnis: {}", current.display())); }
        } else {
            fs::create_dir(&current).map_err(|e| format!("Ordner konnte nicht erstellt werden: {e}"))?;
        }
    }
    Ok(b.join(relative))
}

/// Merge ONE file (only in A) into B at the same relative path.
/// Existing destination ALWAYS causes failure; no replacement, no move, no source deletion.
fn copy_missing(a: &Path, b: &Path, source: &Path) -> Result<(PathBuf, bool), String> {
    checked_roots(a, b)?;
    let before = checked_regular(source, a)?;
    let relative = source.strip_prefix(a).map_err(|e| e.to_string())?;
    let target = checked_destination(b, relative)?;
    let mut input = File::open(source).map_err(|e| e.to_string())?;
    let mut output = OpenOptions::new().write(true).create_new(true).open(&target)
        .map_err(|e| format!("Zieldatei existiert bereits oder kann nicht erstellt werden: {} ({e})", target.display()))?;
    let copied = (|| -> Result<(), String> {
        io::copy(&mut input, &mut output).map_err(|e| format!("Kopieren fehlgeschlagen: {e}"))?;
        output.flush().map_err(|e| e.to_string())?;
        output.sync_all().map_err(|e| e.to_string())?;
        drop(output);
        let after = checked_regular(source, a)?;
        if source_stamp(&before) != source_stamp(&after) {
            return Err("Quelle wurde während des Kopierens verändert.".into());
        }
        if !equal_bytes(source, &target).map_err(|e| e.to_string())? {
            return Err("Kopierte Datei ist nicht byte-identisch.".into());
        }
        Ok(())
    })();
    if let Err(err) = copied {
        // Only a file that we successfully created with create_new can be cleaned up.
        let _ = fs::remove_file(&target);
        return Err(err);
    }
    // Der Inhalt ist verifiziert. Zeitstempel und Zugriffsrechte werden danach bestmöglich übernommen.
    // Finder-Tags, erweiterte Attribute und Resource Forks werden NICHT kopiert.
    let mut metadata_ok = true;
    if let Ok(modified) = before.modified() {
        metadata_ok &= OpenOptions::new().write(true).open(&target).and_then(|file| file.set_modified(modified)).is_ok();
    }
    metadata_ok &= fs::set_permissions(&target, before.permissions()).is_ok();
    Ok((target, metadata_ok))
}

/// MOVE uses a no-overwrite hard link and removes the old link when supported.
/// Otherwise we make a verified destination copy first, and trash the source in
/// one shared system operation. Never call a partial copy a completed move.
#[derive(Debug)]
enum MoveStage { Moved(PathBuf), PendingTrash(PathBuf) }

#[cfg(unix)]
fn same_inode(a: &fs::Metadata, b: &fs::Metadata) -> bool { a.dev() == b.dev() && a.ino() == b.ino() }

#[cfg(target_os = "macos")]
fn copy_for_move(from: &Path, to: &Path, source: &Path) -> Result<PathBuf, String> {
    checked_roots(from, to)?;
    let before = checked_regular(source, from)?;
    let rel = source.strip_prefix(from).map_err(|e| e.to_string())?;
    let dest = checked_destination(to, rel)?;
    // Reserve destination EXCLUSIVELY. /bin/cp may only overwrite our own placeholder.
    let placeholder = OpenOptions::new().write(true).create_new(true).open(&dest)
        .map_err(|e| format!("Ziel existiert oder ist gesperrt: {} ({e})", dest.display()))?;
    drop(placeholder);
    let outcome = (|| -> Result<(), String> {
        // macOS cp -p already preserves timestamps, permissions, ACLs, xattrs and resource forks.
        // -E is NOT a supported macOS cp flag (exit status 64 / usage error).
        let result = Command::new("/bin/cp").arg("-p").arg(source).arg(&dest).output()
            .map_err(|e| format!("macOS-Metadatenkopie konnte nicht gestartet werden: {e}"))?;
        if !result.status.success() {
            return Err(format!("macOS-Metadatenkopie fehlgeschlagen ({}): {}",
                result.status, String::from_utf8_lossy(&result.stderr).trim()));
        }
        if !equal_bytes(source, &dest).map_err(|e| e.to_string())? {
            return Err("Zielinhalt stimmt nicht byteweise mit Quelle überein".into());
        }
        if source_stamp(&checked_regular(source, from)?) != source_stamp(&before) {
            return Err("Quelle wurde beim Kopieren verändert".into());
        }
        checked_regular(&dest, to)?;
        Ok(())
    })();
    if let Err(e) = outcome {
        let _ = fs::remove_file(&dest);
        return Err(format!("{e}; Quelle bleibt bestehen"));
    }
    Ok(dest)
}
#[cfg(not(target_os = "macos"))]
fn copy_for_move(from: &Path, to: &Path, source: &Path) -> Result<PathBuf, String> {
    copy_missing(from, to, source).map(|(p, _)| p)
}

fn stage_move(from: &Path, to: &Path, source: &Path) -> Result<MoveStage, String> {
    stage_move_impl(from, to, source, false)
}
fn stage_move_impl(from: &Path, to: &Path, source: &Path, force_copy: bool) -> Result<MoveStage, String> {
    checked_roots(from, to)?;
    let before = checked_regular(source, from)?;
    let rel = source.strip_prefix(from).map_err(|e| e.to_string())?;
    let dest = checked_destination(to, rel)?;
    if !force_copy && fs::hard_link(source, &dest).is_ok() {
        let src_after = checked_regular(source, from)?;
        let dst_after = checked_regular(&dest, to)?;
        #[cfg(unix)] let unchanged = same_inode(&before, &src_after) && same_inode(&before, &dst_after);
        #[cfg(not(unix))] let unchanged = source_stamp(&before) == source_stamp(&src_after);
        if !unchanged || source_stamp(&before) != source_stamp(&src_after) {
            let _ = fs::remove_file(&dest);
            return Err("Quelldatei hat sich verändert; nichts gelöscht".into());
        }
        return match fs::remove_file(source) {
            Ok(()) => Ok(MoveStage::Moved(dest)),
            Err(_) => Ok(MoveStage::PendingTrash(dest)),
        };
    }
    copy_for_move(from, to, source).map(MoveStage::PendingTrash)
}

fn move_link_preflight(a: &Path, b: &Path, source_root: &Path) -> Result<(), String> {
    checked_roots(a, b)?;
    let stop = AtomicBool::new(false);
    let left = inventory(a, &[], &stop)?;
    let right = inventory(b, &[], &stop)?;
    if !links_into_a(source_root, &left).is_empty() || !links_into_a(source_root, &right).is_empty() {
        return Err("Symlink-Abhängigkeiten zum Quellordner gefunden; Verschieben gesperrt".into());
    }
    Ok(())
}

/// Bytevergleich zweier gepaarter Dateien ohne jede Änderung. Ok(true) = byteweise identisch.
fn verify_pair(a: &Path, b: &Path, left: &Path, right: &Path) -> Result<bool, String> {
    let la = checked_regular(left, a)?;
    let rb = checked_regular(right, b)?;
    if la.len() != rb.len() { return Ok(false); }
    equal_bytes(left, right).map_err(|e| e.to_string())
}

/// Einmal pro Sammelaktion: Ordnergrenzen und Symlink-Abhängigkeiten in beiden Bäumen.
/// Liest beide Bäume ein (bei großen Ordnern dauert das), deshalb nicht pro Datei.
fn link_preflight(a: &Path, b: &Path) -> Result<(), String> {
    checked_roots(a, b)?;
    let stop = AtomicBool::new(false);
    let ia = inventory(a, &[], &stop)?;
    let ib = inventory(b, &[], &stop)?;
    if !links_into_a(a, &ia).is_empty() || !links_into_a(a, &ib).is_empty() {
        return Err("Symlinks in A oder B verweisen auf A. Bitte Links und Abhängigkeiten zuerst im Finder prüfen.".into());
    }
    Ok(())
}

/// Verify selected files according to the explicitly chosen mode. Never mutates data.
/// Fast is a metadata-guarded TRUST decision; it is NOT a fresh content check.
fn preflight_trash_pair_with_mode(
    a: &Path, b: &Path, left: &Path, right: &Path,
    mode: TrashCheckMode, proof: Option<FastProof>,
) -> Result<(), String> {
    let la = checked_regular(left, a)?;
    let rb = checked_regular(right, b)?;
    if la.len() != rb.len() { return Err("Dateigrößen unterscheiden sich; keine Papierkorbaktion.".into()); }
    let before_a = source_stamp(&la);
    let before_b = source_stamp(&rb);
    let matches = match mode {
        TrashCheckMode::Fast => {
            let Some(p) = proof else {
                return Err("Kein geeigneter, aktueller BLAKE3-Scan-Nachweis vorhanden. 'Aktueller Hash' oder 'Bytevergleich' wählen.".into());
            };
            matches_fast_evidence(&la, &rb, p)
        }
        TrashCheckMode::FreshHash => hash_file(left).map_err(|e| e.to_string())?
            == hash_file(right).map_err(|e| e.to_string())?,
        TrashCheckMode::Bytes => equal_bytes(left, right).map_err(|e| e.to_string())?,
    };
    if !matches { return Err("Inhalt bzw. Scan-Metadaten stimmen nicht überein. Keine Papierkorbaktion.".into()); }
    // TOCTOU mitigation (not atomic). Root/link checks are still separately mandatory.
    if before_a != source_stamp(&checked_regular(left, a)?) ||
       before_b != source_stamp(&checked_regular(right, b)?) {
        return Err("Dateien wurden während der Prüfung verändert.".into());
    }
    Ok(())
}

/// Legacy safety helper for tests/individual audit code: full byte comparison.
fn preflight_trash_pair(a: &Path, b: &Path, left: &Path, right: &Path) -> Result<(), String> {
    preflight_trash_pair_with_mode(a, b, left, right, TrashCheckMode::Bytes, None)
}

/// One-file manual trash remains a distinct, user-confirmed operation.
fn trash_pair(a: &Path, b: &Path, left: &Path, right: &Path) -> Result<(), String> {
    preflight_trash_pair(a, b, left, right)?;
    remove_single_file(left, true)
}

/// Einzelaktion: Preflight und Papierkorb für eine Datei.
fn trash_identical_a(a: &Path, b: &Path, left: &Path, right: &Path) -> Result<(), String> {
    link_preflight(a, b)?;
    trash_pair(a, b, left, right)
}

#[cfg(target_os="macos")]
fn show_file(path: &Path, preview: bool) -> Result<(), String> {
    let mut command = if preview { Command::new("qlmanage") } else { Command::new("open") };
    command.arg(if preview { "-p" } else { "-R" }).arg(path)
        .stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null());
    let mut child = command.spawn().map_err(|e| e.to_string())?;
    thread::spawn(move || { let _ = child.wait(); });
    Ok(())
}
#[cfg(not(target_os="macos"))]
fn show_file(_path: &Path, _preview: bool) -> Result<(), String> { Err("Nur auf macOS verfügbar".into()) }

fn selected(index: i32) -> Result<(Entry, PathBuf, PathBuf, usize), String> {
    let guard = SESSION.lock().map_err(|_| "Interner Zustandsfehler")?;
    let session = guard.as_ref().ok_or("Bitte zuerst vergleichen.")?;
    let idx = usize::try_from(index).map_err(|_| "Keine Datei ausgewählt")?;
    let visible = visible_indices(session);
    let global = *visible.get(session.page * PAGE + idx).ok_or("Keine Datei ausgewählt")?;
    let entry = session.entries.get(global).ok_or("Keine Datei ausgewählt")?.clone();
    Ok((entry, session.a.clone(), session.b.clone(), global))
}

fn selected_batch(kind: Kind) -> Result<(Vec<(usize, Entry)>, PathBuf, PathBuf), String> {
    let guard = SESSION.lock().map_err(|_| "Interner Zustandsfehler")?;
    let session = guard.as_ref().ok_or("Bitte zuerst vergleichen.")?;
    let entries = session.selected.iter().filter_map(|&i| session.entries.get(i)
        .filter(|entry| entry.kind == kind).map(|entry| (i, entry.clone())))
        .collect();
    Ok((entries, session.a.clone(), session.b.clone()))
}

fn conflict_batch() -> Result<(Vec<(usize, Entry)>, PathBuf, PathBuf), String> {
    let guard = SESSION.lock().map_err(|_| "Interner Zustandsfehler")?;
    let session = guard.as_ref().ok_or("Bitte zuerst vergleichen.")?;
    let entries = session.entries.iter().enumerate()
        .filter(|(_, entry)| entry.kind == Kind::Conflict)
        .map(|(i, entry)| (i, entry.clone())).collect();
    Ok((entries, session.a.clone(), session.b.clone()))
}

fn session_counts(session: &Session) -> [i32; 6] {
    let mut counts = [0i32; 6];
    for item in &session.entries {
        counts[0] += 1;
        match item.kind {
            Kind::Same => counts[5] += 1,
            Kind::OnlyA => { counts[1] += 1; counts[2] += 1; },
            Kind::OnlyB => { counts[1] += 1; counts[3] += 1; },
            Kind::Conflict => { counts[1] += 1; counts[4] += 1; },
        }
    }
    counts
}

/// Called only from the UI thread. Counters describe the full audit, not just the visible page.
pub(super) fn update_metrics(app: &MainWindow) {
    let counts_and_selection = SESSION.lock().ok().and_then(|guard| guard.as_ref().map(|session| {
        let merge = session.selected.iter().filter(|&&i| session.entries.get(i).is_some_and(|e| e.kind == Kind::OnlyA)).count();
        let merge_back = session.selected.iter().filter(|&&i| session.entries.get(i).is_some_and(|e| e.kind == Kind::OnlyB)).count();
        let same = session.selected.iter().filter(|&&i| session.entries.get(i).is_some_and(|e| e.kind == Kind::Same)).count();
        (session_counts(session), merge, merge_back, same)
    }));
    let (counts, merge, merge_back, same) = counts_and_selection.unwrap_or(([0; 6], 0, 0, 0));
    app.set_folder_audit_counts(ModelRc::new(VecModel::from(counts.to_vec())));
    app.set_folder_audit_selected_merge_count(i32::try_from(merge).unwrap_or(i32::MAX));
    app.set_folder_audit_selected_merge_back_count(i32::try_from(merge_back).unwrap_or(i32::MAX));
    app.set_folder_audit_selected_same_count(i32::try_from(same).unwrap_or(i32::MAX));
}

fn refresh_selection(weak: &Weak<MainWindow>) {
    // Collect everything under one lock, then release it BEFORE calling any UI setters.
    // update_metrics() must never lock SESSION recursively (std::sync::Mutex is not re-entrant).
    let values = SESSION.lock().ok().and_then(|guard| guard.as_ref().map(|session| {
        let (rows, info) = page_rows(session);
        let counts = session_counts(session);
        let merge = session.selected.iter().filter(|&&i| session.entries.get(i).is_some_and(|e| e.kind == Kind::OnlyA)).count();
        let merge_back = session.selected.iter().filter(|&&i| session.entries.get(i).is_some_and(|e| e.kind == Kind::OnlyB)).count();
        let same = session.selected.iter().filter(|&&i| session.entries.get(i).is_some_and(|e| e.kind == Kind::Same)).count();
        (rows, info, counts, merge, merge_back, same)
    }));
    let Some((rows, info, counts, merge, merge_back, same)) = values else { return };
    if let Some(app) = weak.upgrade() {
        app.set_folder_audit_rows(model(rows));
        app.set_folder_audit_page_info(info.into());
        app.set_folder_audit_selected(-1);
        app.set_folder_audit_counts(ModelRc::new(VecModel::from(counts.to_vec())));
        app.set_folder_audit_selected_merge_count(i32::try_from(merge).unwrap_or(i32::MAX));
        app.set_folder_audit_selected_merge_back_count(i32::try_from(merge_back).unwrap_or(i32::MAX));
        app.set_folder_audit_selected_same_count(i32::try_from(same).unwrap_or(i32::MAX));
    }
}

pub(super) fn connect(app: &MainWindow) {
    let weak = app.as_weak();
    app.on_folder_audit_action(move |action, index| {
        // Audit actions must never act on a previous A/B pair after the visible
        // path or ignore-filter fields have changed.
        let Some(app) = weak.upgrade() else { return; };
        if !current_inputs_match_session(&app) {
            reset();
            app.set_folder_compare_has_report(false);
            app.set_folder_audit_rows(to_model(Vec::new()));
            app.set_folder_audit_selected(-1);
            app.set_folder_audit_page_info("Auswahl geändert – erneute Prüfung erforderlich".into());
            update_metrics(&app);
            app.set_folder_compare_status("A, B oder Filter wurden seit dem letzten Audit geändert. Vor einer Dateiaktion bitte 'Inhalte prüfen' erneut ausführen.".into());
            return;
        }
        // Selection is stored by global entry index, not by current page row.
        if action.starts_with("filter:") || matches!(action.as_str(),
            "toggle" | "select_page" | "select_all" | "clear_selection" | "select_merge_to_b" | "select_merge_to_a") {
            if let Ok(mut guard) = SESSION.lock() {
                if let Some(session) = guard.as_mut() {
                    if let Some(filter) = action.strip_prefix("filter:") {
                        session.filter = filter.to_owned(); session.page = 0;
                    } else if action == "clear_selection" {
                        session.selected.clear();
                    } else if action == "select_merge_to_b" || action == "select_merge_to_a" {
                        let target_kind = if action == "select_merge_to_b" { Kind::OnlyA } else { Kind::OnlyB };
                        session.filter = if target_kind == Kind::OnlyA { "only_a".into() } else { "only_b".into() };
                        session.page = 0;
                        session.selected = session.entries.iter().enumerate()
                            .filter(|(_, entry)| entry.kind == target_kind).map(|(i, _)| i).collect();
                    } else {
                        let shown = visible_indices(session);
                        let page_items = shown.iter().skip(session.page * PAGE).take(PAGE).copied().collect::<Vec<_>>();
                        match action.as_str() {
                            "toggle" => {
                                if let Ok(row) = usize::try_from(index) {
                                    if let Some(&i) = page_items.get(row) {
                                        if !session.selected.insert(i) { session.selected.remove(&i); }
                                    }
                                }
                            }
                            "select_page" => { session.selected.extend(page_items); }
                            "select_all" => { session.selected.extend(shown); }
                            _ => {}
                        }
                    }
                }
            }
            refresh_selection(&weak);
            return;
        }
        if action == "verify_conflicts" {
            if app.get_folder_compare_busy() { return; }
            let (batch, a, b) = match conflict_batch() {
                Ok(value) => value, Err(e) => { app.set_folder_compare_status(e.into()); return; }
            };
            if batch.is_empty() { app.set_folder_compare_status("Keine Konflikte vorhanden.".into()); return; }
            BATCH_STOP.store(false, Ordering::Relaxed);
            app.set_folder_compare_busy(true);
            let weak = app.as_weak();
            thread::spawn(move || {
                let total = batch.len();
                let mut identical = Vec::new();
                let mut different = Vec::new();
                let mut errors = Vec::new();
                for (number, (index, entry)) in batch.into_iter().enumerate() {
                    if BATCH_STOP.load(Ordering::Relaxed) { break; }
                    if number % 10 == 0 { ui_message(&weak, format!("Prüfe Konflikte {} / {total} ...", number + 1)); }
                    let (Some(left), Some(right)) = (entry.a.as_deref(), entry.b.as_deref()) else { continue };
                    match verify_pair(&a, &b, left, right) {
                        Ok(true) => identical.push(index),
                        Ok(false) => different.push(index),
                        Err(e) => { if errors.len() < 16 { errors.push(format!("{}: {e}", left.display())); } },
                    }
                }
                let n_equal = identical.len();
                let n_different = different.len();
                if let Ok(mut guard) = SESSION.lock() {
                    if let Some(session) = guard.as_mut() {
                        for index in identical {
                            if let Some(entry) = session.entries.get_mut(index) {
                                if entry.kind == Kind::Conflict { entry.kind = Kind::Same; entry.checked_conflict = false; entry.fast_proof = None; }
                            }
                            session.selected.remove(&index);
                        }
                        for index in different {
                            if let Some(entry) = session.entries.get_mut(index) {
                                if entry.kind == Kind::Conflict { entry.checked_conflict = true; }
                            }
                            session.selected.remove(&index);
                        }
                    }
                }
                let stopped = BATCH_STOP.load(Ordering::Relaxed);
                let _ = weak.upgrade_in_event_loop(move |app| {
                    refresh_selection(&app.as_weak());
                    app.set_folder_compare_busy(false);
                    app.set_folder_compare_status(format!(
                        "Konflikte geprüft: {n_equal} byte-identisch, {n_different} tatsächlich verschieden, {} Fehler. {}{}",
                        errors.len(), if stopped { "Abgebrochen. " } else { "" }, errors.join(" | ")).into());
                });
            });
            return;
        }
        if action == "verify_selected" {
            if app.get_folder_compare_busy() { return; }
            let (batch, a, b) = match selected_batch(Kind::Same) {
                Ok(out) => out, Err(e) => { app.set_folder_compare_status(e.into()); return; }
            };
            if batch.is_empty() { app.set_folder_compare_status("Keine ausgewählten Zeilen mit Status 'Identisch'.".into()); return; }
            BATCH_STOP.store(false, Ordering::Relaxed);
            app.set_folder_compare_busy(true);
            let weak = app.as_weak();
            thread::spawn(move || {
                let total = batch.len();
                let (mut confirmed, mut differing, mut errors) = (0usize, Vec::new(), Vec::new());
                for (number, (index, entry)) in batch.into_iter().enumerate() {
                    if BATCH_STOP.load(Ordering::Relaxed) { break; }
                    if number % 20 == 0 { ui_message(&weak, format!("Byteweise Prüfung {} / {total} ...", number + 1)); }
                    match verify_pair(&a, &b, entry.a.as_deref().expect("same a"), entry.b.as_deref().expect("same b")) {
                        Ok(true) => confirmed += 1,
                        Ok(false) => differing.push(index),
                        Err(e) => if errors.len() < 8 { errors.push(e); },
                    }
                }
                let differing_count = differing.len();
                if let Ok(mut guard) = SESSION.lock() {
                    if let Some(session) = guard.as_mut() {
                        // Gleicher Hash im Index, aber andere Bytes jetzt: als Konflikt anzeigen und aus der Auswahl nehmen.
                        for index in differing { if let Some(entry) = session.entries.get_mut(index) { entry.kind = Kind::Conflict; entry.checked_conflict = true; entry.fast_proof = None; } session.selected.remove(&index); }
                    }
                }
                let stopped = BATCH_STOP.load(Ordering::Relaxed);
                let _ = weak.upgrade_in_event_loop(move |app| {
                    refresh_selection(&app.as_weak());
                    app.set_folder_compare_busy(false);
                    app.set_folder_compare_status(format!("Byteweise geprüft, nichts verändert: {confirmed} identisch, {differing_count} abweichend (jetzt Konflikt), {} nicht lesbar. {}{}",
                        errors.len(), if stopped { "Vorgang abgebrochen. " } else { "" }, errors.join(" | ")).into());
                });
            });
            return;
        }
        if matches!(action.as_str(), "merge_selected" | "merge_selected_a_to_b" | "merge_selected_b_to_a" | "move_selected_a_to_b" | "move_selected_b_to_a") || action.starts_with("trash_selected:") {
            if app.get_folder_compare_busy() { return; }
            let merge_to_a = matches!(action.as_str(), "merge_selected_b_to_a" | "move_selected_b_to_a");
            let is_move = matches!(action.as_str(), "move_selected_a_to_b" | "move_selected_b_to_a");
            let is_merge = is_move || matches!(action.as_str(), "merge_selected" | "merge_selected_a_to_b" | "merge_selected_b_to_a");
            let mode = if is_merge { TrashCheckMode::FreshHash } else {
                let suffix = action.strip_prefix("trash_selected:").unwrap_or("");
                let Some(mode) = TrashCheckMode::parse(suffix) else {
                    app.set_folder_compare_status("Ungültiger Prüfmodus. Keine Papierkorbaktion.".into()); return;
                };
                mode
            };
            let target_kind = if merge_to_a { Kind::OnlyB } else if is_merge { Kind::OnlyA } else { Kind::Same };
            let (batch, a, b) = match selected_batch(target_kind) {
                Ok(out) => out, Err(e) => { app.set_folder_compare_status(e.into()); return; }
            };
            if batch.is_empty() { app.set_folder_compare_status("Keine geeigneten ausgewählten Dateien vorhanden.".into()); return; }
            BATCH_STOP.store(false, Ordering::Relaxed);
            app.set_folder_compare_busy(true);
            let weak = app.as_weak();
            thread::spawn(move || {
                let total = batch.len();
                let mut ok = 0usize;
                let mut changes = Vec::<crate::folder_relations::ManualChange>::new();
                let mut failed = Vec::new();
                let mut failed_count = 0usize;
                let preflight = if is_move { move_link_preflight(&a, &b, if merge_to_a { &b } else { &a }) }
                else if is_merge { checked_roots(&a, &b) } else {
                    ui_message(&weak, "Prüfe Ordnergrenzen und Symlinks in A und B ...".to_owned());
                    link_preflight(&a, &b)
                };
                if let Err(reason) = preflight {
                    let _ = weak.upgrade_in_event_loop(move |app| {
                        app.set_folder_compare_busy(false);
                        app.set_folder_compare_status(format!("Nichts ausgeführt: {reason}").into());
                    });
                    return;
                }
                let mut only_copied = 0usize;
                if is_merge {
                    let mut pending = Vec::<(usize, PathBuf, PathBuf, (u64, Option<SystemTime>))>::new();
                    for (number, (index, entry)) in batch.into_iter().enumerate() {
                        if BATCH_STOP.load(Ordering::Relaxed) { break; }
                        if number % 10 == 0 { ui_message(&weak, format!("{} {} / {total} ...", if is_move { "Verschiebe" } else { "Kopiere" }, number+1)); }
                        let src = if merge_to_a { entry.b.as_deref().expect("only-b") } else { entry.a.as_deref().expect("only-a") };
                        let (from,to) = if merge_to_a { (&b,&a) } else { (&a,&b) };
                        if is_move {
                            let stamp = match checked_regular(src,from) { Ok(meta) => source_stamp(&meta), Err(e) => {
                                failed_count+=1; if failed.len()<12 { failed.push(e); } continue;
                            }};
                            match stage_move(from,to,src) {
                                Ok(MoveStage::Moved(dest)) => {
                                    changes.push(crate::folder_relations::ManualChange::Moved { source:src.to_owned(), destination:dest.clone() });
                                    update_session_moved(index,dest,merge_to_a); ok+=1;
                                }
                                Ok(MoveStage::PendingTrash(dest)) => pending.push((index,src.to_owned(),dest,stamp)),
                                Err(e) => { failed_count+=1; if failed.len()<12 { failed.push(e); } }
                            }
                        } else {
                            match copy_missing(from,to,src) {
                                Ok((dest,_)) => {
                                    changes.push(crate::folder_relations::ManualChange::Copied { source:src.to_owned(), destination:dest.clone() });
                                    update_session_copied(index,dest,merge_to_a); ok+=1;
                                }
                                Err(e) => { failed_count+=1; if failed.len()<12 { failed.push(e); } }
                            }
                        }
                    }
                    if is_move && !pending.is_empty() {
                        let mut ready = Vec::new();
                        let (from,to) = if merge_to_a { (&b,&a) } else { (&a,&b) };
                        for (index,src,dest,prior) in pending {
                            let verified = if BATCH_STOP.load(Ordering::Relaxed) { false } else {
                                (|| -> Result<bool,String> {
                                    let sm = checked_regular(&src,from)?;
                                    let dm = checked_regular(&dest,to)?;
                                    if source_stamp(&sm)!=prior || sm.len()!=dm.len() { return Ok(false); }
                                    #[cfg(unix)] let linked = same_inode(&sm,&dm);
                                    #[cfg(not(unix))] let linked = false;
                                    let same = linked || equal_bytes(&src,&dest).map_err(|e| e.to_string())?;
                                    Ok(same && source_stamp(&checked_regular(&src,from)?)==prior)
                                })().unwrap_or(false)
                            };
                            if verified { ready.push((index,src,dest)); }
                            else {
                                changes.push(crate::folder_relations::ManualChange::Copied { source:src.clone(), destination:dest.clone() });
                                update_session_copied(index,dest,merge_to_a);
                                only_copied+=1;
                                if !BATCH_STOP.load(Ordering::Relaxed) { failed_count+=1; if failed.len()<12 { failed.push(format!("{}: nicht mehr verifiziert, Quelle bleibt",src.display())); } }
                            }
                        }
                        if BATCH_STOP.load(Ordering::Relaxed) {
                            // User cancelled before the common trash operation. Nothing removed.
                            for (index,src,dest) in ready {
                                changes.push(crate::folder_relations::ManualChange::Copied { source:src, destination:dest.clone() });
                                update_session_copied(index,dest,merge_to_a); only_copied+=1;
                            }
                        } else if !ready.is_empty() {
                            ui_message(&weak, format!("{} verifizierte Quellen gemeinsam in Papierkorb ...",ready.len()));
                            let paths:Vec<&Path> = ready.iter().map(|(_,p,_)|p.as_path()).collect();
                            let result = checked_roots(&a,&b).and_then(|()|delete_all(&paths).map_err(|e|e.to_string()));
                            for (index,src,dest) in ready {
                                if checked_regular(&dest,to).is_ok() &&
                                    matches!(fs::symlink_metadata(&src),Err(ref e) if e.kind()==io::ErrorKind::NotFound) {
                                    changes.push(crate::folder_relations::ManualChange::Moved { source:src, destination:dest.clone() });
                                    update_session_moved(index,dest,merge_to_a); ok+=1;
                                } else if checked_regular(&src,from).is_ok() && checked_regular(&dest,to).is_ok() {
                                    changes.push(crate::folder_relations::ManualChange::Copied { source:src.clone(), destination:dest.clone() });
                                    update_session_copied(index,dest,merge_to_a); only_copied+=1; failed_count+=1;
                                    if failed.len()<12 { failed.push(format!("{}: nur kopiert (Quelle nicht entfernt)",src.display())); }
                                } else { failed_count+=1; if failed.len()<12 { failed.push(format!("{}: Status unklar, im Finder prüfen",src.display())); } }
                            }
                            if let Err(e)=result { if failed.len()<12 { failed.push(format!("Papierkorb: {e}")); } }
                        }
                    }
                } else {
                    // First verify ALL selected candidates. Nothing is trashed during preflight;
                    // users can cancel even large selections before the system trash operation.
                    let mut verified = Vec::<(usize, PathBuf)>::new();
                    for (number, (index, entry)) in batch.into_iter().enumerate() {
                        if BATCH_STOP.load(Ordering::Relaxed) { break; }
                        if number % 10 == 0 { ui_message(&weak, format!("{}: {} / {total} ...", mode.label(), number + 1)); }
                        let left = entry.a.as_deref().expect("same a");
                        let right = entry.b.as_deref().expect("same b");
                        match preflight_trash_pair_with_mode(&a, &b, left, right, mode, entry.fast_proof) {
                            Ok(()) => verified.push((index, left.to_owned())),
                            Err(e) => { failed_count += 1; if failed.len() < 12 { failed.push(format!("{}: {e}", left.display())); } }
                        }
                    }
                    if !BATCH_STOP.load(Ordering::Relaxed) && !verified.is_empty() {
                        ui_message(&weak, format!("{} Dateien mit {} freigegeben. Gemeinsamer macOS-Papierkorbvorgang startet ...", verified.len(), mode.label()));
                        // One trash-rs call instead of one Finder/AppleScript authorization per file.
                        // On macOS, OS-level ownership prompts may nevertheless occur.
                        let paths: Vec<&Path> = verified.iter().map(|(_, path)| path.as_path()).collect();
                        let result = checked_roots(&a, &b).and_then(|()| delete_all(&paths).map_err(|e| e.to_string()));
                        // delete_all is not guaranteed atomic; reconcile each affected path
                        // rather than assuming success or silently retrying a partial failure.
                        for (index, path) in verified {
                            match fs::symlink_metadata(&path) {
                                Err(e) if e.kind() == io::ErrorKind::NotFound => {
                                    changes.push(crate::folder_relations::ManualChange::Trashed(path));
                                    update_session(index, None); ok += 1;
                                }
                                _ => { failed_count += 1; }
                            }
                        }
                        if let Err(e) = result {
                            failed.push(format!("Papierkorb meldete einen Fehler: {e}. Einzelstatus durch Prüfung der Originalpfade ermittelt."));
                        }
                    }
                }
                if !changes.is_empty() {
                    ui_message(&weak, format!("Aktualisiere Ordnerindex lokal ({} Änderungen, kein neuer Scan) ...", changes.len()));
                    crate::folder_relations::apply_manual_changes(&weak, changes);
                }
                let stopped = BATCH_STOP.load(Ordering::Relaxed);
                let _ = weak.upgrade_in_event_loop(move |app| {
                    refresh_selection(&app.as_weak());
                    app.set_folder_compare_busy(false);
                    app.set_folder_compare_status(format!("{} {ok} Dateien erfolgreich; {failed_count} nicht durchgeführt. {}{}.{}",
                        if is_move { "Verschoben:".to_owned() } else if is_merge { "Kopiert und geprüft:".to_owned() } else { format!("In Papierkorb verschoben ({}):", mode.label()) },
                        if stopped { "Abgebrochen. " } else { "" }, failed.join(" | "),
                        if is_move { format!(" {only_copied} nur kopiert, Quelle weiterhin vorhanden. Bitte Teilergebnisse prüfen.") } else if is_merge { "".to_owned() } else { " Papierkorbschritt kann nach Beginn nicht abgebrochen werden.".to_owned() }).into());
                });
            });
            return;
        }
        if action == "finder_folder_a" || action == "finder_folder_b" {
            let paths = SESSION.lock().ok().and_then(|session| session.as_ref().map(|s| (s.a.clone(), s.b.clone())));
            let result = paths.ok_or("Bitte zuerst vergleichen".to_owned()).and_then(|(a, b)| {
                checked_roots(&a, &b)?;
                show_file(if action == "finder_folder_a" { &a } else { &b }, false)
            });
            if let Err(error) = result { ui_message(&weak, error); }
            return;
        }
        if action == "prev" || action == "next" {
            if let Ok(mut guard) = SESSION.lock() {
                if let Some(session) = guard.as_mut() {
                    let max = visible_indices(session).len().max(1).div_ceil(PAGE).saturating_sub(1);
                    if action == "prev" { session.page = session.page.saturating_sub(1); }
                    else { session.page = (session.page + 1).min(max); }
                    let (rows, info) = page_rows(session);
                    if let Some(app) = weak.upgrade() {
                        app.set_folder_audit_rows(model(rows));
                        app.set_folder_audit_page_info(info.into());
                        app.set_folder_audit_selected(-1);
                    }
                }
            }
            return;
        }
        let (entry, a, b, global) = match selected(index) {
            Ok(value) => value,
            Err(error) => { ui_message(&weak, error); return; }
        };
        if action == "preview_a" || action == "preview_b" || action == "finder_a" || action == "finder_b" {
            let path = if action.ends_with("_a") { entry.a.as_deref() } else { entry.b.as_deref() };
            let root = if action.ends_with("_a") { &a } else { &b };
            let outcome = path.ok_or("Für diese Seite gibt es keine Datei".to_owned())
                .and_then(|path| checked_regular(path, root).map(|_| path))
                .and_then(|path| show_file(path, action.starts_with("preview")));
            if let Err(err) = outcome { ui_message(&weak, err); }
            return;
        }
        if !matches!(action.as_str(), "merge_one" | "trash_one_a") { ui_message(&weak, "Unbekannte Aktion".into()); return; }
        let Some(app) = weak.upgrade() else { return };
        if app.get_folder_compare_busy() { return; }
        // Note: confirmation of trash_one_a occurs in the Slint UI BEFORE calling us.
        let valid = match action.as_str() {
            "merge_one" => entry.kind == Kind::OnlyA && entry.a.is_some(),
            "trash_one_a" => entry.kind == Kind::Same && entry.a.is_some() && entry.b.is_some(),
            _ => false,
        };
        if !valid { app.set_folder_compare_status("Aktion für diese Dateizeile nicht erlaubt".into()); return; }
        app.set_folder_compare_busy(true);
        let weak = app.as_weak();
        let is_merge = action == "merge_one";
        thread::spawn(move || {
            let result: Result<(String, Option<PathBuf>), String> = if is_merge {
                copy_missing(&a, &b, entry.a.as_deref().expect("validated")).map(|(dest, metadata_ok)| {
                    let note = if metadata_ok { "Zeitstempel und Rechte übernommen" } else { "Zeitstempel oder Rechte konnten nicht übernommen werden" };
                    (format!("Kopiert und byteweise geprüft: {} ({note}; Finder-Tags und erweiterte Attribute werden nicht kopiert).", dest.display()), Some(dest))
                })
            } else {
                trash_identical_a(&a, &b, entry.a.as_deref().expect("validated"), entry.b.as_deref().expect("validated"))
                    .map(|()| ("Eine ausdrücklich ausgewählte Datei aus A in den Papierkorb verschoben.".to_owned(), None))
            };
            match result {
                Ok((message, destination)) => {
                    // Die Tabelle wird nur an dieser einen Zeile angepasst. Jede Aktion prüft beim Ausführen selbst
                    // erneut (Neuanlage ohne Überschreiben bzw. frischer Bytevergleich), daher ist kein Komplett-Scan nötig.
                    let change = match &destination {
                        Some(dest) => crate::folder_relations::ManualChange::Copied {
                            source: entry.a.as_ref().expect("valid source").clone(),
                            destination: dest.clone(),
                        },
                        None => crate::folder_relations::ManualChange::Trashed(
                            entry.a.as_ref().expect("valid source").clone(),
                        ),
                    };
                    let (rows, info) = update_session(global, destination);
                    // Reconcile just this known change; no full disk scan or hash pass.
                    crate::folder_relations::apply_manual_changes(&weak, vec![change]);
                    let _ = weak.upgrade_in_event_loop(move |app| {
                        if let Some(rows) = rows { app.set_folder_audit_rows(model(rows)); }
                        app.set_folder_audit_page_info(info.into());
                        app.set_folder_audit_selected(-1);
                        update_metrics(&app);
                        app.set_folder_compare_busy(false);
                        app.set_folder_compare_status(format!("{message} Die Tabelle wurde für diese Zeile angepasst. Der gespeicherte Bericht zeigt den Stand vor der Aktion.").into());
                    });
                }
                Err(err) => {
                    let _ = weak.upgrade_in_event_loop(move |app| {
                        app.set_folder_compare_busy(false);
                        app.set_folder_compare_status(format!("Aktion nicht durchgeführt: {err}").into());
                    });
                }
            }
        });
    });
}

/// Update just the copied row, not the entire paginated model for each file.
/// Direction is explicit and the source remains intact in both cases.
fn update_session_copied(global: usize, destination: PathBuf, from_b: bool) {
    if let Ok(mut guard) = SESSION.lock() {
        if let Some(session) = guard.as_mut() {
            if let Some(entry) = session.entries.get_mut(global) {
                if from_b && entry.kind == Kind::OnlyB && entry.b.is_some() {
                    entry.a = Some(destination);
                    entry.kind = Kind::Same;
                    entry.fast_proof = None;
                    session.selected.remove(&global);
                } else if !from_b && entry.kind == Kind::OnlyA && entry.a.is_some() {
                    entry.b = Some(destination);
                    entry.kind = Kind::Same;
                    entry.fast_proof = None;
                    session.selected.remove(&global);
                }
            }
        }
    }
}

/// On successful MOVE the source disappears and the target remains on the other side.
fn update_session_moved(index:usize, target:PathBuf, from_b:bool) {
    if let Ok(mut lock)=SESSION.lock() { if let Some(s)=lock.as_mut() {
        if let Some(e)=s.entries.get_mut(index) {
            if from_b && e.kind==Kind::OnlyB && e.b.is_some() { e.b=None; e.a=Some(target); e.kind=Kind::OnlyA; s.selected.remove(&index); }
            else if !from_b && e.kind==Kind::OnlyA && e.a.is_some() { e.a=None; e.b=Some(target); e.kind=Kind::OnlyB; s.selected.remove(&index); }
            e.fast_proof=None;
        }
    }}
}

/// Passt genau eine Zeile an: Merge macht aus "Nur in A" ein "Identisch", Papierkorb macht aus "Identisch" ein "Nur in B".
fn update_session(global: usize, destination: Option<PathBuf>) -> (Option<Vec<Vec<String>>>, String) {
    let Ok(mut guard) = SESSION.lock() else { return (None, "Tabelle nicht aktualisiert".to_owned()) };
    let Some(session) = guard.as_mut() else { return (None, "Tabelle nicht aktualisiert".to_owned()) };
    if let Some(entry) = session.entries.get_mut(global) {
        match destination {
            Some(dest) => { entry.b = Some(dest); entry.kind = Kind::Same; entry.fast_proof = None; }
            None => { entry.a = None; entry.kind = Kind::OnlyB; entry.fast_proof = None; }
        }
    }
    session.selected.remove(&global);
    let (rows, info) = page_rows(session);
    (Some(rows), info)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicU64, Ordering as AO};
    static NEXT: AtomicU64 = AtomicU64::new(0);
    struct Fixture { root: PathBuf, a: PathBuf, b: PathBuf }
    impl Fixture {
        fn new() -> Self {
            let root = std::env::temp_dir().join(format!("krokiet_merge_{}_{}", std::process::id(), NEXT.fetch_add(1, AO::SeqCst)));
            let a = root.join("A"); let b = root.join("B");
            fs::create_dir_all(&a).unwrap(); fs::create_dir_all(&b).unwrap();
            Self { root, a, b }
        }
    }
    impl Drop for Fixture { fn drop(&mut self) { let _ = fs::remove_dir_all(&self.root); } }
    #[cfg(unix)] #[test]
    fn v19_move_same_filesystem_removes_original_without_overwrite() {
        let f=Fixture::new(); let src=f.a.join("x"); fs::write(&src,b"important").unwrap();
        let before=fs::metadata(&src).unwrap();
        let MoveStage::Moved(dst)=stage_move(&f.a,&f.b,&src).unwrap() else { panic!("expected move") };
        assert!(!src.exists()); assert_eq!(fs::read(&dst).unwrap(),b"important");
        assert!(same_inode(&before,&fs::metadata(dst).unwrap()));
    }
    #[test]
    fn v19_move_rejects_existing_destination_both_directions() {
        let f=Fixture::new(); fs::write(f.a.join("x"),b"A").unwrap(); fs::write(f.b.join("x"),b"B").unwrap();
        assert!(stage_move(&f.a,&f.b,&f.a.join("x")).is_err());
        assert!(stage_move(&f.b,&f.a,&f.b.join("x")).is_err());
        assert_eq!(fs::read(f.a.join("x")).unwrap(),b"A"); assert_eq!(fs::read(f.b.join("x")).unwrap(),b"B");
    }
    #[test]
    fn v19_copy_fallback_keeps_source_until_trash() {
        let f=Fixture::new(); fs::write(f.a.join("x"),b"source").unwrap();
        let MoveStage::PendingTrash(dst)=stage_move_impl(&f.a,&f.b,&f.a.join("x"),true).unwrap() else {panic!("fallback")};
        assert_eq!(fs::read(dst).unwrap(),b"source"); assert!(f.a.join("x").exists());
    }
    #[test]
    fn merge_copies_missing_and_never_overwrites() {
        let f = Fixture::new(); let source = f.a.join("Photos/a.jpg");
        fs::create_dir_all(source.parent().unwrap()).unwrap(); fs::write(&source, b"one").unwrap();
        let target = copy_missing(&f.a, &f.b, &source).unwrap().0;
        assert_eq!(fs::read(&target).unwrap(), b"one");
        assert!(copy_missing(&f.a, &f.b, &source).is_err());
        assert_eq!(fs::read(&target).unwrap(), b"one");
    }
    #[test]
    fn v18_bidirectional_merge_copy_reuses_non_overwrite_checks() {
        let f = Fixture::new();
        let from_b = f.b.join("Sounds/sample.wav");
        fs::create_dir_all(from_b.parent().unwrap()).unwrap();
        fs::write(&from_b, b"sample only in B").unwrap();
        let in_a = copy_missing(&f.b, &f.a, &from_b).unwrap().0;
        assert_eq!(fs::read(&in_a).unwrap(), b"sample only in B");
        assert_eq!(fs::read(&from_b).unwrap(), b"sample only in B");
        assert!(copy_missing(&f.b, &f.a, &from_b).is_err());
        assert_eq!(fs::read(&in_a).unwrap(), b"sample only in B");
    }
    #[test]
    fn v18_reverse_merge_rejects_colliding_a_target() {
        let f = Fixture::new();
        fs::write(f.b.join("x"), b"B source").unwrap();
        fs::write(f.a.join("x"), b"A stays").unwrap();
        assert!(copy_missing(&f.b, &f.a, &f.b.join("x")).is_err());
        assert_eq!(fs::read(f.a.join("x")).unwrap(), b"A stays");
    }
    #[test]
    fn merge_rejects_existing_different_content() {
        let f=Fixture::new(); fs::write(f.a.join("x"), b"old").unwrap(); fs::write(f.b.join("x"), b"new").unwrap();
        assert!(copy_missing(&f.a, &f.b, &f.a.join("x")).is_err());
        assert_eq!(fs::read(f.b.join("x")).unwrap(), b"new");
    }
    #[test]
    fn manual_trash_refuses_files_with_different_contents() {
        let f=Fixture::new();
        let a_file=f.a.join("match.txt"); let b_file=f.b.join("match.txt");
        fs::write(&a_file, b"version A").unwrap();
        fs::write(&b_file, b"version B").unwrap();
        assert!(trash_identical_a(&f.a, &f.b, &a_file, &b_file).is_err());
        assert!(a_file.exists());
        assert!(b_file.exists());
    }
    #[cfg(unix)]
    #[test]
    fn manual_trash_refuses_dependency_in_b() {
        use std::os::unix::fs::symlink;
        let f=Fixture::new();
        let a_file=f.a.join("x.txt"); let b_file=f.b.join("x.txt");
        fs::write(&a_file, b"same").unwrap(); fs::write(&b_file, b"same").unwrap();
        symlink(&a_file, f.b.join("dependent-link")).unwrap();
        assert!(trash_identical_a(&f.a, &f.b, &a_file, &b_file).is_err());
        assert!(a_file.exists());
    }
    #[cfg(unix)]
    #[test]
    fn merge_refuses_symlink_destination_directory() {
        use std::os::unix::fs::symlink;
        let f=Fixture::new(); let out=f.root.join("outside"); fs::create_dir(&out).unwrap();
        symlink(&out, f.b.join("Photos")).unwrap();
        fs::create_dir_all(f.a.join("Photos")).unwrap(); fs::write(f.a.join("Photos/x"), b"x").unwrap();
        assert!(copy_missing(&f.a, &f.b, &f.a.join("Photos/x")).is_err());
        assert!(!out.join("x").exists());
    }
    #[test]
    fn filters_and_all_selection_cover_all_pages() {
        let mk = |kind| Entry { a: Some(PathBuf::from("/A/x")), b: None, kind, checked_conflict: false, fast_proof: None };
        let mut session = Session {
            a: PathBuf::from("/A"), b: PathBuf::from("/B"),
            patterns: vec![], page: 0, filter: "only_a".into(),
            selected: BTreeSet::new(), from_index: true,
            entries: (0..250).map(|i| mk(if i % 2 == 0 { Kind::OnlyA } else { Kind::Same })).collect(),
        };
        assert_eq!(visible_indices(&session).len(), 125);
        session.selected.extend(visible_indices(&session));
        session.page = 1;
        let (rows, _) = page_rows(&session);
        assert_eq!(rows.len(), 5);
        assert!(rows.iter().all(|r| r[4] == "1"));
        session.filter = "different".into();
        assert_eq!(visible_indices(&session).len(), 125);
        session.filter = "same".into();
        assert_eq!(visible_indices(&session).len(), 125);
    }
    struct OneByte<'a>(&'a [u8]);
    impl Read for OneByte<'_> {
        fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
            if self.0.is_empty() || buf.is_empty() { return Ok(0); }
            buf[0] = self.0[0];
            self.0 = &self.0[1..];
            Ok(1)
        }
    }
    #[test]
    fn byte_compare_survives_short_reads() {
        let data: Vec<u8> = (0..300_000u32).map(|i| (i % 251) as u8).collect();
        let mut other = data.clone();
        assert!(equal_streams(&mut OneByte(&data), &mut io::Cursor::new(&data)).unwrap());
        other[299_999] ^= 1;
        assert!(!equal_streams(&mut OneByte(&data), &mut io::Cursor::new(&other)).unwrap());
        assert!(!equal_streams(&mut io::Cursor::new(&data[..299_999]), &mut io::Cursor::new(&data)).unwrap());
    }
    #[test]
    fn merge_keeps_modification_time() {
        let f = Fixture::new();
        let source = f.a.join("x.txt");
        fs::write(&source, b"inhalt").unwrap();
        let old = SystemTime::UNIX_EPOCH + std::time::Duration::from_secs(1_500_000_000);
        OpenOptions::new().write(true).open(&source).unwrap().set_modified(old).unwrap();
        let (target, metadata_ok) = copy_missing(&f.a, &f.b, &source).unwrap();
        assert!(metadata_ok);
        assert_eq!(fs::metadata(&target).unwrap().modified().unwrap(), old);
    }
    #[test]
    fn session_row_is_updated_in_place() {
        let entry = |a: Option<&str>, b: Option<&str>, kind| Entry { a: a.map(PathBuf::from), b: b.map(PathBuf::from), kind, checked_conflict: false, fast_proof: None };
        *SESSION.lock().unwrap() = Some(Session {
            a: PathBuf::from("/A"), b: PathBuf::from("/B"), patterns: Vec::new(), page: 0,
            entries: vec![entry(Some("/A/x"), None, Kind::OnlyA), entry(Some("/A/y"), Some("/B/y"), Kind::Same)],
            filter: "all".into(), selected: BTreeSet::new(), from_index: false,
        });
        let (rows, _) = update_session(0, Some(PathBuf::from("/B/x")));
        assert_eq!(rows.unwrap()[0][2], "same");
        let (rows, _) = update_session(1, None);
        assert_eq!(rows.unwrap()[1][2], "only_b");
        *SESSION.lock().unwrap() = None;
    }
    #[test]
    fn verify_pair_reports_difference_without_changing_anything() {
        let f = Fixture::new();
        let (l, r) = (f.a.join("x"), f.b.join("y"));
        fs::write(&l, b"gleich").unwrap(); fs::write(&r, b"gleich").unwrap();
        assert_eq!(verify_pair(&f.a, &f.b, &l, &r), Ok(true));
        fs::write(&r, b"gleiCh").unwrap();
        assert_eq!(verify_pair(&f.a, &f.b, &l, &r), Ok(false));
        fs::write(&r, b"laenger!").unwrap();
        assert_eq!(verify_pair(&f.a, &f.b, &l, &r), Ok(false));
        assert!(l.exists() && r.exists());
    }
    #[cfg(unix)]
    #[test]
    fn preflight_refuses_links_into_a_and_passes_clean_trees() {
        use std::os::unix::fs::symlink;
        let f = Fixture::new();
        fs::write(f.a.join("x"), b"x").unwrap();
        assert!(link_preflight(&f.a, &f.b).is_ok());
        symlink(f.a.join("x"), f.b.join("link")).unwrap();
        assert!(link_preflight(&f.a, &f.b).is_err());
    }
    #[test]
    fn conflict_preview_is_not_claimed_to_be_byte_different() {
        let e = Entry { a: Some(PathBuf::from("/A/x")), b: Some(PathBuf::from("/B/x")),
            kind: Kind::Conflict, checked_conflict: false, fast_proof: None };
        let row = row_text(&e, Path::new("/A"), Path::new("/B"));
        assert_eq!(row[3], "Ungeprüft");
        assert!(row[5].contains("nicht aktuell byteweise geprüft"));
        let verified = Entry { checked_conflict: true, ..e };
        let row = row_text(&verified, Path::new("/A"), Path::new("/B"));
        assert_eq!(row[3], "Verschieden");
    }
    #[test]
    fn preflight_trash_is_non_mutating() {
        let f = Fixture::new();
        let a_file = f.a.join("x"); let b_file = f.b.join("x");
        fs::write(&a_file, b"same").unwrap(); fs::write(&b_file, b"same").unwrap();
        assert!(preflight_trash_pair(&f.a, &f.b, &a_file, &b_file).is_ok());
        assert!(a_file.exists() && b_file.exists());
        fs::write(&b_file, b"changed").unwrap();
        assert!(preflight_trash_pair(&f.a, &f.b, &a_file, &b_file).is_err());
        assert!(a_file.exists() && b_file.exists());
    }
    #[test]
    fn check_modes_deny_changed_content_and_fast_needs_evidence() {
        let f = Fixture::new();
        let (left, right) = (f.a.join("left"), f.b.join("right"));
        fs::write(&left, b"abc").unwrap();
        fs::write(&right, b"abc").unwrap();
        let ml = fs::metadata(&left).unwrap();
        let mr = fs::metadata(&right).unwrap();
        let proof = FastProof {
            size_a: ml.len(), size_b: mr.len(),
            modified_a: unix_seconds(ml.modified().unwrap()).unwrap(),
            modified_b: unix_seconds(mr.modified().unwrap()).unwrap(),
        };
        assert!(preflight_trash_pair_with_mode(&f.a, &f.b, &left, &right, TrashCheckMode::Fast, Some(proof)).is_ok());
        assert!(preflight_trash_pair_with_mode(&f.a, &f.b, &left, &right, TrashCheckMode::Fast, None).is_err());
        assert!(preflight_trash_pair_with_mode(&f.a, &f.b, &left, &right, TrashCheckMode::FreshHash, None).is_ok());
        assert!(preflight_trash_pair_with_mode(&f.a, &f.b, &left, &right, TrashCheckMode::Bytes, None).is_ok());
        fs::write(&right, b"different").unwrap();
        for mode in [TrashCheckMode::Fast, TrashCheckMode::FreshHash, TrashCheckMode::Bytes] {
            assert!(preflight_trash_pair_with_mode(&f.a, &f.b, &left, &right, mode, Some(proof)).is_err());
        }
        assert!(left.exists() && right.exists());
    }
    #[test]
    fn fast_mode_rejects_modified_time_change_with_same_length() {
        let f = Fixture::new();
        let (left, right) = (f.a.join("x"), f.b.join("x"));
        fs::write(&left, b"abc").unwrap(); fs::write(&right, b"abc").unwrap();
        let proof = FastProof {
            size_a: 3, size_b: 3,
            modified_a: unix_seconds(fs::metadata(&left).unwrap().modified().unwrap()).unwrap(),
            modified_b: unix_seconds(fs::metadata(&right).unwrap().modified().unwrap()).unwrap(),
        };
        fs::write(&right, b"xyz").unwrap();
        let later = SystemTime::UNIX_EPOCH + std::time::Duration::from_secs(proof.modified_b + 10);
        OpenOptions::new().write(true).open(&right).unwrap().set_modified(later).unwrap();
        assert!(preflight_trash_pair_with_mode(&f.a, &f.b, &left, &right, TrashCheckMode::Fast, Some(proof)).is_err());
        assert!(preflight_trash_pair_with_mode(&f.a, &f.b, &left, &right, TrashCheckMode::FreshHash, None).is_err());
    }
    #[test]
    fn trash_pair_refuses_changed_pair() {
        let f = Fixture::new();
        let (l, r) = (f.a.join("x"), f.b.join("x"));
        fs::write(&l, b"eins").unwrap(); fs::write(&r, b"zwei").unwrap();
        assert!(trash_pair(&f.a, &f.b, &l, &r).is_err());
        assert!(l.exists());
    }
}
