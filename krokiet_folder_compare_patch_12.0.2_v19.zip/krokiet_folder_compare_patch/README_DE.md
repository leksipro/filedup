# Krokiet Folder Compare v19 – macOS ARM64 (Test-Build)

Basis: Krokiet/Czkawka 12.0.2, Weiterentwicklung von v18. **Dies ist Quellcode, keine kompilierte App.**

## Neu in v19 – Verschieben und Kopieren getrennt

- Nach Wahl der Übertragungsrichtung stehen **Verschieben bestätigen** und **Nur kopieren** nebeneinander.
- **Verschieben** auf unterstützten Dateisystemen: mit `std::fs::hard_link` zuerst ein ausschließlich neu angelegtes Ziel erzeugen, anschließend Quellpfad entfernen. Bewahrt Inhalt und Dateimetadaten ohne erneutes Kopieren. Quelle liegt anschließend nicht im Papierkorb.
- **Verschieben über Dateisystemgrenzen oder auf Dateisystemen ohne Hardlinks:** Quelle metadatenschonend kopieren (`/bin/cp -pE` auf macOS), Inhalt byteweise vergleichen und dann alle Quellen gemeinsam über `trash::delete_all` in den Papierkorb verschieben. Bei Fehlern bleiben Quelldateien erhalten; die Anwendung meldet diesen Fall als **nur kopiert**.
- Bestehende Zieldateien werden niemals überschrieben. Bei Problemen ist ein Teilergebnis möglich, das einzeln im Finder kontrolliert werden sollte.
- Der Inhaltsindex aktualisiert nach erfolgreichen Verschiebungen den Dateipfad, statt ein zusätzliches Duplikat einzutragen. Kein vollständiger Neu-Scan nur wegen der eigenen Aktionen.
- Externe Projektverknüpfungen und jede Art von Metadaten auf inkompatiblen Ziel-Dateisystemen können nicht vollständig abgesichert werden. Für echte Archive zuerst mit Testdateien prüfen. Leere Quellverzeichnisse werden nicht automatisch entfernt.

## Wesentliche Änderungen

### Neu in v18: Merge in beiden Richtungen direkt sichtbar

- Im A/B-Vergleich stehen oberhalb der Dateiliste **A → B** und **B → A** mit der Anzahl der jeweils fehlenden Dateien. Eine Richtung wählen markiert automatisch nur die entsprechenden fehlenden Dateien; das Kopieren erfordert eine zweite ausdrückliche Bestätigung.
- Auch eine manuell zusammengestellte Auswahl kann über beide Richtungen kopiert werden. Die Auswahl kann über mehrere Seiten bestehen bleiben.
- V18 kann die fehlenden Dateien **direkt aus B nach A** kopieren; ein vorheriges A/B-Tauschen ist nicht mehr nötig.
- Es werden weder vorhandene Zieldateien überschrieben noch Dateien aus der Quelle entfernt. Nach dem Kopieren wird byteweise verifiziert und der bekannte Ordnerindex aktualisiert, ohne einen vollständigen Festplattenscan zu erzwingen.
- Bei vollständig gleichen Dateiinhalten ist ein Merge nicht erforderlich. Bestehen nur ungeklärte Pfadkonflikte, müssen diese separat untersucht werden; ein automatisches Überschreiben findet nicht statt.
- Hinweis: Die Anzeige beruht anfänglich auf dem **älteren Scan-Index**. Vor dem Kopieren kontrolliert `copy_missing` die Quelle und den Zielpfad; eine erfolgreiche Kopie wird direkt byteweise verifiziert. Metadaten wie Finder-Tags oder Resource Forks werden nicht vollständig übernommen.


### Neu in v17: Nach Lösch- und Kopieraktionen ohne vollständigen Neu-Scan weiterarbeiten

- Das bisherige globale `INDEX_DIRTY` nach **jeder** Dateiaktion war unnötig: Es blendete alle Ordnerbeziehungen aus. Jetzt wird nach nachweislich erfolgreichen Änderungen nur das **im Speicher vorhandene Inventar** korrigiert.
- In den Papierkorb verschobene Dateien werden aus dem Index entfernt. Erfolgreich und byteweise überprüfte Kopien werden ergänzt. Die Gruppenzähler und Ordnerbeziehungen werden aus diesen **gespeicherten Dateieinträgen** neu berechnet – ohne den Datenträger erneut zu durchsuchen oder unberührte Dateien zu hashen.
- Der aktuelle Ordnerfilter, die Sortierung und Seite werden nach Möglichkeit erhalten. Weil sich Zeilenpositionen ändern können, wird die alte Zeilenauswahl zurückgesetzt; die aktualisierte Trefferliste bleibt sichtbar.
- Für ältere unveränderte Dateien ist dies weiterhin der **Stand des letzten Scans**, keine Echtzeitüberwachung der Festplatte. Der Schnellmodus beim Papierkorb bleibt eine bewusste Vertrauensentscheidung.
- Kann eine Kopie nicht mit dem Inventar abgeglichen werden (beispielsweise Quelle außerhalb des ursprünglich gescannten Bereichs), wird der alte Index **ausdrücklich als unverifiziert** angezeigt statt fälschlich sichere Treffer zu melden.
- Der neue Index wird für den nächsten Start als **Cache-Snapshot** gespeichert, der nach Neustart weiterhin als unverifiziert gekennzeichnet wird. Bei sehr großen Inventaren entfällt das Caching, nicht die Aktualisierung im Arbeitsspeicher.


- Symmetrisch identische Zwillingsordner werden in der Trefferliste zu einem repräsentativen Treffer zusammengefasst. Bei mehr als zwei identischen Ordnern wird weiterhin die Gruppengröße angezeigt.
- Bei einem konkreten A/B-Paar steht die **Dateiabdeckung in beide Richtungen**: „A in B“ und „B in A“ mit Dateizahlen. Diese Zahl ist nicht die globale Abdeckung über verstreute Archive.
- In der Vergleichstabelle gibt es eine zusätzliche Aktion **Konflikte prüfen**. Sie vergleicht alle bislang unklaren Pfadpaare A/B frisch byteweise. Danach steht „Identisch“ oder „Verschieden“; „Ungeprüft“ ist bewusst keine Behauptung unterschiedlicher Inhalte.
- „A/B tauschen“ wechselt über die vorhandenen Indexdaten die Richtung des Paares. Die Aktion „Kopieren nach B“ kann so für beide Richtungen verwendet werden. Sind eigene, nicht indexierte Pfade ausgewählt, ist gegebenenfalls „Neu prüfen“ nötig.
- **Keine starre Grenze von 200 Dateien** bei ausdrücklichen Mehrfachaktionen. Dateien werden vor dem Papierkorb einzeln geprüft, danach mit einem **einzigen `trash::delete_all`** an das Betriebssystem übergeben. Die Aktion selbst ist nach dem Start nicht abbrechbar; ein Fehler kann eine teilweise Ausführung bedeuten. Die Ergebnisse werden anhand der verbleibenden Originalpfade abgeglichen.
- Das Kopieren verwendet weiterhin `create_new(true)` und überschreibt keine Dateien. Kopien werden byteweise überprüft.
- Der beim Papierkorb verwendete Prüfmodus wird ausdrücklich in der Bestätigung gewählt. Kein neuer Vollscan der Platte; der aktuelle Hashmodus liest nur die ausgewählten A/B-Dateien.
- **Schnell kann Datenverlust ermöglichen:** Größe und Änderungszeit sind kein Beweis für unveränderte Inhalte, auch nicht bei gleichzeitiger Aktualisierung der Uhrzeiten. Wähle bei wichtigen Daten „Aktueller Hash“ oder „Bytevergleich“.

## Bedienung

1. **Einmal** den regulären Duplikatscan mit Hash-Prüfung starten und **Ordner vergleichen** öffnen.
2. Links ein Ordnerpaar auswählen. Rechts erscheint die **unverifizierte Index-Vorschau**, ohne erneuten gesamten Datenträger-Scan.
3. Für problematische Fälle **Konflikte prüfen** wählen, um gleichnamige Dateien aktuell byteweise nachzuprüfen. Über **Neu prüfen** ist weiterhin ein vollständiger Audit möglich.
4. Oberhalb der Dateiliste steht **Merge A → B / B → A** mit der Zahl fehlender Dateien. Richtung wählen, Auswahl in der Vorschau kontrollieren und Kopieren ausdrücklich bestätigen. Die manuelle Auswahl unter „Nur A“ oder „Nur B“ bleibt möglich.
5. Für identische Dateipaare ist „Optional: Byteprüfung“ weiterhin eine zusätzliche Vorabprüfung. Vor der Papierkorb-Bestätigung einen von drei Modi wählen: **Schnell (Index)** prüft nur Scan-Nachweis, Größe und Änderungszeit (kein neues Lesen der Inhalte, höheres Risiko); **Aktueller Hash** berechnet BLAKE3 für A und B neu (**Voreinstellung**); **Bytevergleich** vergleicht alle Bytes direkt. Ohne qualifizierten Scan-Nachweis wird Schnell für betroffene Dateien gesperrt, nicht still auf einen anderen Modus gewechselt.
6. Nach Merge/Papierkorb wird die Ordnerliste ohne erneuten Scan aktualisiert. Die A/B-Tabelle wird zeilenweise fortgeschrieben; bei externen Änderungen oder unklaren Scan-Daten kann ein erneuter Scan nötig sein.
7. Bei Dateien in externen Projekten, Ressourcen-Forks und Dateien mit AppleDouble-`._`-Metadaten manuell kontrollieren. Die Anwendung kennt keine externen Projektverweise.

## Datenschutz und Sicherheitsgrenzen

- Kein automatisches Entfernen ganzer Ordner, keine permanente Löschung.
- Dateifilter können Inhalte verdecken. Für Archiventscheidungen Filter deaktivieren und den gesamten A/B-Bestand ansehen.
- Die Papierkorb-API macht auf macOS nach Möglichkeit einen einzigen Systemaufruf. **Ob macOS tatsächlich nur eine Freigabe abfragt, kann nicht garantiert werden**: Zugriffsrechte, TCC und externe Volumes können weitere Dialoge auslösen. Niemals Rechte pauschal auf allen Dateien ändern, um Dialoge zu umgehen.
- Auch ein erfolgreiches `cargo test` ist keine Zertifizierung gegen alle Datenverlustfälle. Erst auf Testordnern und mit wiederherstellbaren Kopien prüfen.

## GitHub-Build

ZIP ins Repo-Hauptverzeichnis hochladen: `krokiet_folder_compare_patch_12.0.2_v19.zip`.
Workflow: `.github/workflows/build-krokiet-v19.yml` mit der beigefügten YAML erstellen.

Der Workflow klont Krokiet 12.0.2, wendet `apply_patch.py` an (einschließlich einer **direkten, auf die vorhandene Cargo.lock-Version festgelegten `trash`- und `blake3`-Abhängigkeiten**), führt die Tests mit `--locked` aus und erstellt das ad-hoc signierte ARM64-App-Bundle.

**Vor dem Build:** Der Patch wurde hier statisch geprüft und mit Python-Tests getestet. Rust-/Slint- und macOS-Dateisystem-Tests müssen in GitHub Actions bzw. auf dem Mac erfolgen.
