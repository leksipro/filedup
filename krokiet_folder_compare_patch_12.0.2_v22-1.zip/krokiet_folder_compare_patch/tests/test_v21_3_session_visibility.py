"""Guard against a regression in the A-centred session-row Rust test."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]

class TestSessionVisibility(unittest.TestCase):
    def test_test_asserts_filtered_row_and_retained_b_entry(self):
        src = (ROOT / "krokiet/src/folder_audit_actions.rs").read_text()
        body = src.split("fn session_row_is_updated_in_place()", 1)[1].split("#[test]", 1)[0]
        self.assertIn('assert_eq!(rows.len(), 1)', body)
        self.assertIn('assert_eq!(removed_from_a.kind, Kind::OnlyB)', body)
        self.assertIn('session.filter = "only_b".into()', body)
        self.assertIn('assert_eq!(b_rows[0][2], "only_b")', body)
        self.assertNotIn('rows.unwrap()[1]', body)

    def test_default_filter_intentionally_hides_only_b(self):
        src = (ROOT / "krokiet/src/folder_audit_actions.rs").read_text()
        self.assertIn('"all_pairs" => true', src)
        self.assertIn('_ => e.kind != Kind::OnlyB', src)

if __name__ == "__main__": unittest.main()
