import Foundation
import Darwin

// Never requests elevation and never permanently deletes. Only a regular file.
func report(_ error: NSError, depth: Int = 0) {
    guard depth < 8 else { return }
    let prefix = String(repeating: "  ", count: depth)
    fputs("\(prefix)NSError domain=\(error.domain) code=\(error.code) description=\(error.localizedDescription)\n", stderr)
    if let reason = error.localizedFailureReason { fputs("\(prefix)reason=\(reason)\n", stderr) }
    if let underlying = error.userInfo[NSUnderlyingErrorKey] as? NSError { report(underlying, depth: depth + 1) }
}
guard CommandLine.arguments.count == 2 else { fputs("Expected one absolute file path\n", stderr); exit(64) }
let path = CommandLine.arguments[1]
guard path.hasPrefix("/"), !path.hasSuffix("/") else { exit(64) }
var st = stat()
guard lstat(path, &st) == 0 else {
    let code = errno
    report(NSError(domain: NSPOSIXErrorDomain, code: Int(code)))
    exit(1)
}
guard (st.st_mode & mode_t(S_IFMT)) == mode_t(S_IFREG) else { fputs("Not a regular file\n", stderr); exit(65) }
do {
    var result: NSURL?
    try FileManager.default.trashItem(at: URL(fileURLWithPath: path), resultingItemURL: &result)
    exit(0)
} catch {
    report(error as NSError)
    exit(1)
}
